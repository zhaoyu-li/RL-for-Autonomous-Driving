import re
import uuid
import random
import itertools
import collections
from dataclasses import dataclass, field
from typing import Sequence, Tuple, Dict, Any

from yattag import Doc, indent

from smarts.core.waypoints import Waypoint, Waypoints
from smarts.core.sumo_road_network import SumoRoadNetwork

# TODO: May want to move this to a separate module.
class _SumoParams(collections.Mapping):
    """For some Sumo params (e.x. LaneChangingModel) the arguments are in title case
    with a given prefix. Subclassing this class allows for an automatic way to map
    between PEP8-compatible naming and Sumo's.
    """

    def __init__(self, prefix, whitelist=[], **kwargs):
        def snake_to_title(word):
            return "".join(x.capitalize() or "_" for x in word.split("_"))

        # XXX: On rare occasions sumo doesn't respect their own conventions
        #      (e.x. junction model's impatience).
        self._params = {key: kwargs.pop(key) for key in whitelist if key in kwargs}

        for key, value in kwargs.items():
            self._params[f"{prefix}{snake_to_title(key)}"] = value

    def __iter__(self):
        return iter(self._params)

    def __getitem__(self, key):
        return self._params[key]

    def __len__(self):
        return len(self._params)

    def __hash__(self):
        return hash(frozenset(self._params.items()))

    def __eq__(self, other):
        return self.__class__ == other.__class__ and hash(self) == hash(other)


class LaneChangingModel(_SumoParams):
    """ Models how the actor acts with respect to lane changes
    """

    def __init__(self, **kwargs):
        super().__init__("lc", **kwargs)


class JunctionModel(_SumoParams):
    """ Models how the actor acts with respect to waiting at junctions
    """

    def __init__(self, **kwargs):
        super().__init__("jm", whitelist=["impatience"], **kwargs)


@dataclass(frozen=True)
class Distribution:
    """The `mean` is the factor (1 = max,  0.5 = half).
       `sigma` is the deviation of the mean.
    """

    ## the factor (1 = max,  0.5 = half, 0 = min)
    mean: float
    ## the deviation of the mean.
    sigma: float

    def sample(self):
        """ The next sample from the distribution
        """

        return random.gauss(self.mean, self.sigma)


@dataclass(frozen=True, unsafe_hash=True)
class TrafficActor:
    """Used as a description/spec for traffic actors (e.x. Vehicles, Pedestrians,
    etc). The defaults provided are for a car, but the name is not set to make it
    explicit that you actually want a car.
    """

    ## ::name The name of the traffic actor (make it unique)
    name: str
    ## the acceleration allowed for the traffic actor
    accel: float = 2.6
    ## the deceleration allowed for the traffic actor
    decel: float = 4.5
    ## Speed Distribution
    speed: Distribution = Distribution(mean=1.0, sigma=0.1)
    ## Distribution that models how imperfectly the vehicle drives
    imperfection: Distribution = Distribution(mean=0.5, sigma=0)
    ## Distribution that models how much space the vehicle wants
    min_gap: Distribution = Distribution(mean=2.5, sigma=0)
    ## How the actor acts with respect to changing lanes
    lane_changing_model: LaneChangingModel = field(
        default_factory=LaneChangingModel, hash=False
    )
    ## How the actor acts with respect to junctions
    junction_model: JunctionModel = field(default_factory=JunctionModel, hash=False)

    @property
    def id(self) -> str:
        """ The identifier tag of the traffic actor
        """

        return "actor-{}-{}".format(self.name, hash(self))


@dataclass(frozen=True)
class SocialAgentActor:
    """Used as a description/spec for zoo traffic actors. These actors use a 
    pre-trained model to understand how to act in the environment.
    """

    ## The name of the agent
    name: str
    ## A pre-registered zoo identifying tag you provide to help SMARTS identify the prefab of a social agent
    agent_locator: str

    def as_traffic_actor(self):
        """ Utility method for conversion to a traffic actor
        """

        return TrafficActor(name=f"social_agent-`{self.agent_locator}`-{self.name}",)


@dataclass(frozen=True)
class Route:
    """A route is represented by begin and end edge IDs, with an optional list of
    itermediary edge IDs. When an intermediary is not specified the router will
    decide what it should be.
    """

    ## edge, lane index, offset
    begin: Tuple[str, int, Any]
    ## edge, lane index, offset
    end: Tuple[str, int, Any]

    # Edges we want to make sure this route includes
    intermediaries: Tuple[str, ...] = field(default_factory=tuple)

    @property
    def id(self) -> str:
        return "route-{}-{}-{}".format(
            "_".join(map(str, self.begin)), "_".join(map(str, self.end)), hash(self),
        )

    @property
    def edges(self):
        return (self.begin[0],) + self.intermediaries + (self.end[0],)


@dataclass(frozen=True)
class RandomRoute:
    """ An alternative to types.Route which specifies to sstudio to generate a random route
    """

    id: str = field(default_factory=lambda: f"random-route-{uuid.uuid4()}")


@dataclass(frozen=True)
class Flow:
    """A route with an actor type emitted at a given rate."""

    route: Route
    rate: float  # vehicles/hour
    begin: float = 0
    # XXX: Defaults to 1 hour of traffic. We may want to change this to be "continual
    #      traffic", effectively an infinite end.
    end: float = 1 * 60 * 60  # seconds
    actors: Dict[TrafficActor, float] = field(default_factory=dict)

    @property
    def id(self) -> str:
        return "flow-{}-{}".format(
            self.route.id, str(hash(frozenset(self.actors.items()))),
        )

    def __hash__(self):
        # Custom hash since self.actors is not hashable, here we first convert to a
        # frozenset.
        return hash((self.route, self.rate, frozenset(self.actors.items())))

    def __eq__(self, other):
        return self.__class__ == other.__class__ and hash(self) == hash(other)


@dataclass(frozen=True)
class Traffic:
    """ A sequence of flows
    """

    flows: Sequence[Flow]


@dataclass(frozen=True)
class Mission:
    """ The directive of an agent
    """

    route: Route
