import logging

import numpy as np
from collections import namedtuple

from .vehicle import Vehicle
from .utils.math import degrees_to_vec

Events = namedtuple(
    "Events", ["collisions", "off_road", "reached_goal", "reached_max_episode_steps"]
)

Observation = namedtuple(
    "Observation",
    [
        "events",
        "ego_vehicle_state",
        "neighborhood_vehicle_states",
        "waypoint_paths",
        "distance_travelled",
        "lidar_point_cloud",
        "occupancy_grid_map",
        "top_down_rgb",
    ],
)


class Sensors:
    _log = logging.getLogger("Sensors")

    @staticmethod
    def observe(sim, agent_id, agent_state, vehicle: Vehicle):
        ego = vehicle.state()
        neighborhood_vehicles = None
        if agent_state.neighborhood_vehicles_subscribed:
            neighborhood_vehicles = sim.neighborhood_vehicles_around_agent(
                agent_id, agent_state.neighborhood_vehicles_subscription.radius
            )

        if agent_state.waypoints_subscribed:
            waypoint_paths = sim.mission_planner(agent_id).waypoint_paths_at(
                vehicle.position,
                lookahead=agent_state.waypoints_subscription.lookahead,
            )
        else:
            waypoint_paths = sim.traffic_sim.waypoints.waypoint_paths_at(
                vehicle.position, lookahead=1,  # For calculating distance travelled
            )
        agent_state.sensor_state.append_waypoint_if_new(waypoint_paths[0][0])

        if not agent_state.waypoints_subscribed:
            waypoint_paths = None

        rgb = vehicle.calc_observation_rgb() if agent_state.rgb_subscribed else None
        ogm = vehicle.calc_observation_ogm() if agent_state.ogm_subscribed else None
        lidar = (
            vehicle.calc_observation_lidar() if agent_state.lidar_subscribed else None
        )

        done, events = Sensors._is_done_with_events(sim, agent_id, agent_state)

        return (
            Observation(
                events=events,
                ego_vehicle_state=ego,
                neighborhood_vehicle_states=neighborhood_vehicles,
                waypoint_paths=waypoint_paths,
                distance_travelled=agent_state.sensor_state.distance_travelled,
                top_down_rgb=rgb,
                occupancy_grid_map=ogm,
                lidar_point_cloud=lidar,
            ),
            done,
        )

    @staticmethod
    def step(sim, agent_state):
        return agent_state.sensor_state.step()

    @staticmethod
    def score_increment(sim, agent_state):
        return agent_state.sensor_state.score_increment

    @staticmethod
    def _is_done_with_events(sim, agent_id, agent_state):
        collided = sim.agent_did_collide(agent_id)
        is_off_road = sim.agent_is_off_road(agent_id)
        reached_goal = sim.agent_reached_goal(agent_id)
        reached_max_episode_steps = agent_state.sensor_state.reached_max_episode_steps

        if collided:
            Sensors._log.debug(f"Agent {agent_id} collided")

        if is_off_road:
            Sensors._log.debug(f"Agent {agent_id} is off road")

        if reached_goal:
            Sensors._log.debug(f"Agent {agent_id} reached the end goal")

        if reached_max_episode_steps:
            Sensors._log.debug(f"Agent {agent_id} reached max episode steps")

        done = is_off_road or collided or reached_goal or reached_max_episode_steps
        events = Events(
            collisions=sim.agent_collisions(agent_id),
            off_road=is_off_road,
            reached_goal=reached_goal,
            reached_max_episode_steps=reached_max_episode_steps,
        )
        return done, events


class SensorState:
    def __init__(self, max_episode_steps, starting_wp):
        self._max_episode_steps = max_episode_steps
        self._wps_for_distance = [starting_wp]
        self._dist_travelled = 0.0
        self._last_dist_travelled = 0.0
        self._step = 0

    def append_waypoint_if_new(self, new_wp):
        # Distance calculation. Intention is the shortest trip travelled at the lane
        # level the agent has travelled. This is to prevent lateral movement from
        # increasing the total distance travelled.
        most_recent_wp = self._wps_for_distance[-1]
        self._last_dist_travelled = self._dist_travelled
        if most_recent_wp.id != new_wp.id:
            self._dist_travelled += SensorState._compute_additional_dist_travelled(
                most_recent_wp, new_wp
            )
            self._wps_for_distance.append(new_wp)

    @property
    def score_increment(self):
        return self._dist_travelled - self._last_dist_travelled

    @property
    def distance_travelled(self):
        return self._dist_travelled

    @property
    def reached_max_episode_steps(self):
        if self._max_episode_steps is None:
            return False

        return self._step >= self._max_episode_steps

    def step(self):
        self._step += 1

    @staticmethod
    def _compute_additional_dist_travelled(recent_wp, waypoint):
        heading_vec = degrees_to_vec(recent_wp.heading)
        disp_vec = waypoint.pos - recent_wp.pos
        direction = np.sign(np.dot(heading_vec, disp_vec))
        distance = np.linalg.norm(disp_vec)
        return direction * distance
