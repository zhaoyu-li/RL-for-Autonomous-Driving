import itertools

import ray
from ray.rllib.env.multi_agent_env import MultiAgentEnv

import smarts
from smarts.core.smarts import SMARTS
from smarts.core.sumo_traffic_simulation import SumoTrafficSimulation
from smarts.core.scenario import Scenario
from smarts.zoo.registry import make as make_social_agent
from .agent import Agent


@ray.remote
class RemoteAgent:
    def __init__(self, agent: Agent):
        self._agent = agent

    def setup(self):
        self._agent.setup()

    def act(self, obs):
        return self._agent.act_with_adaptation(obs)


class RLlibHiWayEnv(MultiAgentEnv):
    def __init__(self, config):
        seed = int(config.get("seed", 42))
        smarts.core.seed(seed)

        self._agents = config["agents"]
        social_agent_infos = Scenario.discover_social_agents(config["scenarios"][0])
        self._scenarios_iterator = Scenario.scenario_variations(
            config["scenarios"], list(self._agents.keys()),
        )
        self._social_agents = {
            agent_id: make_social_agent(
                locator=locator,
                ## Overload the prefab here
            )
            for d in social_agent_infos
            for agent_id, (_, locator) in d.items()
        }
        self._remote_social_agents = None
        self._pending_social_agent_actions = None

        self._headless = config.get("headless", False)
        self._smarts = None

    def step(self, agent_actions):
        agent_actions = {
            agent_id: self._agents[agent_id].action_adapter(action)
            for agent_id, action in agent_actions.items()
        }
        social_agent_actions = {
            agent_id: ray.get(pending_action)
            for agent_id, pending_action in self._pending_social_agent_actions.items()
        }
        all_agent_actions = {**agent_actions, **social_agent_actions}

        observations, rewards, scores, agent_dones = self._smarts.step(
            all_agent_actions
        )

        self._pending_social_agent_actions = {
            agent_id: remote_agent.act.remote(observations[agent_id])
            for agent_id, remote_agent in self._remote_social_agents.items()
        }

        self._remove_social_agents_from_env_output(observations)
        self._remove_social_agents_from_env_output(rewards)
        self._remove_social_agents_from_env_output(agent_dones)  # unnecessary?
        self._remove_social_agents_from_env_output(scores)

        # Important to teardown done agents after we've filtered out the
        # social agents from dones. We do not want to teardown social agents
        # because we are prioritizing simulation cohesion over social agent
        # behaviour stability.
        self._teardown_done_agent_vehicles(agent_dones)

        # Agent termination: Rllib expects that we return a "last observation"
        # on the step that an agent transitions to "done". All subsequent calls
        # to env.step(..) will no longer contain actions from the "done" agent.
        #
        # The way we implement this behaviour here is to rely on the presence of
        # agent actions to filter out all environment observations/rewards/infos
        # to only agents who are actively sending in actions.
        observations = {
            agent_id: obs
            for agent_id, obs in observations.items()
            if agent_id in agent_actions
        }
        rewards = {
            agent_id: reward
            for agent_id, reward in rewards.items()
            if agent_id in agent_actions
        }
        scores = {
            agent_id: score
            for agent_id, score in scores.items()
            if agent_id in agent_actions
        }
        infos = {key: {"score": value} for key, value in scores.items()}

        # Ensure all contain the same agent_ids as keys
        assert (
            agent_actions.keys()
            == observations.keys()
            == rewards.keys()
            == infos.keys()
        )
        for agent_id in agent_actions:
            agent = self._agents[agent_id]
            observation = observations[agent_id]
            reward = rewards[agent_id]

            rewards[agent_id] = agent.reward_adapter(observation, reward)
            observations[agent_id] = agent.observation_adapter(observation)

        agent_dones["__all__"] = all(agent_dones.values())

        return observations, rewards, agent_dones, infos

    def reset(self):
        scenario = next(self._scenarios_iterator)
        # Defer expensive environment creation to prevent the driver process
        # from creating its own SMARTS instance.
        # https://ray.readthedocs.io/en/latest/rllib-env.html#expensive-environments
        self._remote_social_agents = {
            # Ray will take care of cleaning up any old RemoteAgents
            agent_id: RemoteAgent.remote(social_agent["agent"])
            for agent_id, social_agent in self._social_agents.items()
        }

        # Setup each agent in parallel
        ray.wait(
            [
                remote_agent.setup.remote()
                for remote_agent in self._remote_social_agents.values()
            ]
        )

        if self._smarts is None:
            self._smarts = self._build_smarts()
            self._smarts.setup(scenario)

        env_observations = self._smarts.reset(scenario)

        self._pending_social_agent_actions = {
            agent_id: remote_agent.act.remote(env_observations[agent_id])
            for agent_id, remote_agent in self._remote_social_agents.items()
        }

        self._remove_social_agents_from_env_output(env_observations)

        observations = {
            agent_id: self._agents[agent_id].observation_adapter(obs)
            for agent_id, obs in env_observations.items()
        }

        return observations

    def close(self):
        if self._smarts is not None:
            self._smarts.destroy()

    def _build_smarts(self):
        agent_interfaces = {
            agent_id: agent.interface for agent_id, agent in self._agents.items()
        }
        social_agent_interfaces = {
            agent_id: agent.interface for agent_id, agent in self._social_agents.items()
        }

        # XXX: This should be configurable!
        timestep_sec = 0.1

        smarts = SMARTS(
            agent_interfaces=agent_interfaces,
            social_agent_interfaces=social_agent_interfaces,
            traffic_sim=SumoTrafficSimulation(
                headless=True, time_resolution=timestep_sec,
            ),
            headless=self._headless,
            timestep_sec=timestep_sec,
        )
        return smarts

    def _remove_social_agents_from_env_output(self, output):
        # TODO: we need a more robust way of making sure social agents don't leak out of the env
        for social_agent_id in self._remote_social_agents:
            del output[social_agent_id]

    def _teardown_done_agent_vehicles(self, agent_dones):
        for agent_id, is_done in agent_dones.items():
            if is_done:
                self._smarts.teardown_agent_vehicle(agent_id)
