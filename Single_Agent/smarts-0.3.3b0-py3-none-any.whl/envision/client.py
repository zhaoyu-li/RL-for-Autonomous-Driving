import uuid
import json
import logging
import threading
from queue import Queue

import websocket
import numpy as np

from smarts.core.utils import unpack
from . import types


class JSONEncoder(json.JSONEncoder):
    """This custom encoder is to support serializing more complex data from SMARTS
    including numpy arrays, NaNs, and Infinity which don't have standarized handling
    according to the JSON spec.
    """

    def default(self, obj):
        if isinstance(obj, float):
            if np.isposinf(obj):
                obj = "Infinity"
            elif np.isneginf(obj):
                obj = "-Infinity"
            elif np.isnan(obj):
                obj = "NaN"
            return obj
        elif isinstance(obj, list):
            return [self.default(x) for x in obj]
        elif isinstance(obj, np.bool_):
            return super().encode(bool(obj))
        elif isinstance(obj, np.ndarray):
            return self.default(obj.tolist())

        return super().default(obj)


class QueueDone:
    pass


class Client:
    """Used to push state from SMARTS to Envision server while the simulation is
    running.
    """

    def __init__(self, port=8081):
        self._log = logging.getLogger(self.__class__.__name__)
        self._client_id = str(uuid.uuid4())[:8]
        self._ws_endpoint = f"ws://localhost:{port}"
        self._state_queue = Queue()
        self._ws = None
        self._thread = None

        self._connect()

    def _connect(self):
        def on_close(ws):
            self._log.debug("Connection to Envision closed")

        def on_error(ws, error):
            self._log.info("Unable to connect to Envision")

        def on_open(ws):
            self._log.debug("Connection to Envision opened")

            while True:
                state = self._state_queue.get()
                if type(state) is QueueDone:
                    break

                state = unpack(state)
                state = json.dumps(state, cls=JSONEncoder)
                ws.send(state)

        def run_socket(ws):
            ws.run_forever()

        url = f"{self._ws_endpoint}/simulations/{self._client_id}/broadcast"
        self._ws = websocket.WebSocketApp(
            url, on_error=on_error, on_close=on_close, on_open=on_open
        )
        self._thread = threading.Thread(
            target=run_socket,
            name="Envision-Broadcast-Socket",
            args=(self._ws,),
            daemon=True,  # If False, the proc will not terminate until this thread stops
        )

        self._thread.start()

    def send_state(self, state: types.State):
        self._state_queue.put(state)

    def teardown(self):
        with self._state_queue.mutex:
            self._state_queue.queue.clear()

        self._state_queue.put(QueueDone())

        if self._ws:
            self._ws.close()

        if self._thread:
            self._thread.join()
