from dataclasses import dataclass
from collections import namedtuple
from typing import Union, Callable

import gym

from smarts.core.agent_interface import AgentInterface


class AgentPolicy:
    def setup(self):
        pass

    def teardown(self):
        pass

    def act(self, obs):
        raise NotImplementedError


@dataclass
class Adapter:
    space: gym.Space
    transform: Callable


def default_obs_adapter(obs):
    return obs


def default_reward_adapter(obs, reward):
    return reward


def default_action_adapter(action):
    return action


def default_info_adapter(obs, reward, info):
    return info


@dataclass
class Agent:
    interface: AgentInterface
    policy: Union[AgentPolicy, Callable] = None
    observation_space: gym.Space = None
    action_space: gym.Space = None
    observation_adapter: Callable = default_obs_adapter
    reward_adapter: Callable = default_reward_adapter
    action_adapter: Callable = default_action_adapter
    info_adapter: Callable = default_info_adapter

    def reset(self):
        self.teardown()
        self.setup()

    def setup(self):
        if isinstance(self.policy, AgentPolicy):
            self.policy.setup()

    def teardown(self):
        if isinstance(self.policy, AgentPolicy):
            self.policy.teardown()

    # XXX: expects adapted observation and returns unadapted action
    def act(self, observation):
        assert self.policy, "Unable to call Agent.act(...) without a policy"

        if isinstance(self.policy, AgentPolicy):
            policy_action = self.policy.act(observation)
        else:  # assume Callable
            policy_action = self.policy(observation)
        return policy_action

    # XXX: This method should only be used by social agents, not by ego agents.
    def act_with_adaptation(self, env_observation):
        observation = self.observation_adapter(env_observation)
        policy_action = self.act(observation)
        action = self.action_adapter(policy_action)
        return action
