import itertools

from ray.rllib.env.multi_agent_env import MultiAgentEnv

import smarts
from smarts.core.smarts import SMARTS
from smarts.core.sumo_traffic_simulation import SumoTrafficSimulation
from smarts.core.scenario import Scenario
from smarts.zoo.registry import make as make_social_agent
from .agent import Agent


class RLlibHiWayEnv(MultiAgentEnv):
    def __init__(self, config):
        seed = int(config.get("seed", 42))
        smarts.core.seed(seed)

        self._agents = config["agents"]
        self._scenarios_iterator = Scenario.scenario_variations(
            config["scenarios"], list(self._agents.keys()),
        )

        self._headless = config.get("headless", False)
        self._smarts = None

    def step(self, agent_actions):
        agent_actions = {
            agent_id: self._agents[agent_id].action_adapter(action)
            for agent_id, action in agent_actions.items()
        }

        observations, rewards, scores, dones = self._smarts.step(agent_actions)

        # Agent termination: RLlib expects that we return a "last observation"
        # on the step that an agent transitions to "done". All subsequent calls
        # to env.step(..) will no longer contain actions from the "done" agent.
        #
        # The way we implement this behaviour here is to rely on the presence of
        # agent actions to filter out all environment observations/rewards/infos
        # to only agents who are actively sending in actions.
        observations = {
            agent_id: obs
            for agent_id, obs in observations.items()
            if agent_id in agent_actions
        }
        rewards = {
            agent_id: reward
            for agent_id, reward in rewards.items()
            if agent_id in agent_actions
        }
        scores = {
            agent_id: score
            for agent_id, score in scores.items()
            if agent_id in agent_actions
        }

        infos = {key: {"score": value} for key, value in scores.items()}

        # Ensure all contain the same agent_ids as keys
        assert (
            agent_actions.keys()
            == observations.keys()
            == rewards.keys()
            == infos.keys()
        )
        for agent_id in agent_actions:
            agent = self._agents[agent_id]
            observation = observations[agent_id]
            reward = rewards[agent_id]
            info = infos[agent_id]

            observations[agent_id] = agent.observation_adapter(observation)
            rewards[agent_id] = agent.reward_adapter(observation, reward)
            infos[agent_id] = agent.info_adapter(observation, reward, info)

        dones["__all__"] = all(dones.values())

        return observations, rewards, dones, infos

    def reset(self):
        scenario = next(self._scenarios_iterator)

        if self._smarts is None:
            self._smarts = self._build_smarts()
            self._smarts.setup(scenario)

        env_observations = self._smarts.reset(scenario)

        observations = {
            agent_id: self._agents[agent_id].observation_adapter(obs)
            for agent_id, obs in env_observations.items()
        }

        return observations

    def close(self):
        if self._smarts is not None:
            self._smarts.destroy()

    def _build_smarts(self):
        agent_interfaces = {
            agent_id: agent.interface for agent_id, agent in self._agents.items()
        }

        # XXX: This should be configurable!
        timestep_sec = 0.1

        smarts = SMARTS(
            agent_interfaces=agent_interfaces,
            traffic_sim=SumoTrafficSimulation(
                headless=True, time_resolution=timestep_sec,
            ),
            headless=self._headless,
            timestep_sec=timestep_sec,
        )
        return smarts
