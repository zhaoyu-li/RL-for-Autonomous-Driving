from .sumo_road_network import SumoRoadNetwork
from .waypoints import Waypoints
from .scenario import Mission, Start, EndlessGoal


class PlanningError(Exception):
    pass


class MissionPlanner:
    def __init__(self, waypoints: Waypoints, road_network: SumoRoadNetwork):
        self._waypoints = waypoints
        self._road_network = road_network

        self._did_plan = False

    def _random_endless_mission(self):
        start_wp = self._waypoints.random_waypoint()
        mission = Mission(
            start=Start(tuple(start_wp.pos), start_wp.heading), goal=EndlessGoal(),
        )

        return mission

    def plan(self, mission: Mission):
        if not mission:
            mission = self._random_endless_mission()

        self._mission = mission

        if self._mission.is_endless:
            self._route = []
        else:
            start_wp, end_wp = self._waypoints.closest_waypoint_batched(
                [self._mission.start.position, self._mission.goal.position]
            )

            start_edge = self._road_network.lane_by_id(start_wp.lane_id).getEdge()
            end_edge = self._road_network.lane_by_id(end_wp.lane_id).getEdge()
            self._route = self._road_network.shortest_route(start_edge, end_edge)

            if not self._route:
                raise PlanningError(
                    "Unable to find a route between start={} and end={}. If either of "
                    "these are junctions (not well supported today) please switch to "
                    "edges and ensure there is a > 0 offset into the edge if it's "
                    "after a junction.".format(start_edge.getID(), end_edge.getID())
                )

        self._did_plan = True
        return mission

    @property
    def route(self):
        return self._route

    @property
    def mission(self):
        return self._mission

    def waypoint_paths_at(self, position, lookahead):
        """Call assumes you're on the correct route already. We do not presently
        "replan" in case the route has changed.
        """
        assert (
            self._did_plan
        ), "Must call plan(...) before being able to invoke the mission planner."

        if self._mission.is_endless:
            return self._waypoints.waypoint_paths_at(position, lookahead)
        else:
            edge_ids = [edge.getID() for edge in self._route]
            return self._waypoints.waypoint_paths_along_route(
                position, lookahead, edge_ids
            )

    def waypoint_paths_on_lane_at(self, position, lane_id, lookahead):
        """Call assumes you're on the correct route already. We do not presently
        "replan" in case the route has changed.
        """
        assert (
            self._did_plan
        ), "Must call plan(...) before being able to invoke the mission planner."

        if self._mission.is_endless:
            return self._waypoints.waypoint_paths_at(position, lookahead)
        else:
            edge_ids = [edge.getID() for edge in self._route]
            return self._waypoints.waypoint_paths_on_lane_at(
                position, lane_id, lookahead, edge_ids
            )
