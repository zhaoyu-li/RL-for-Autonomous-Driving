import os
import math
import logging
from typing import Sequence
import importlib.resources as pkg_resources
from collections import defaultdict, namedtuple

import numpy
from direct.showbase.ShowBase import ShowBase
from panda3d.core import (
    ClockObject,
    loadPrcFileData,
    NodePath,
    AmbientLight,
)

import gltf
import pybullet
import pybullet_utils.bullet_client as bc
from sklearn.metrics.pairwise import euclidean_distances

from smarts.zoo.registry import make as make_social_agent
from smarts.sstudio.types import SocialAgentActor
from envision import Client as Envision
from envision import types as envision_types

from . import models
from .agent_state import AgentState
from .agent_interface import AgentInterface
from .remote_agent import RemoteAgent
from .vehicle import Vehicle
from .social_vehicle import SocialVehicle
from .masks import RenderMasks
from .sensors import Sensors
from .scenario import Scenario
from .controllers import Controllers
from .units import Heading
from .mission_planner import MissionPlanner, Mission, Start, EndlessGoal
from .bubble_manager import BubbleManager

# disable vsync otherwise we are limited to refresh-rate of screen
loadPrcFileData("", "sync-video false")
loadPrcFileData("", "model-path %s" % os.getcwd())
loadPrcFileData("", "audio-library-name null")

# https://www.panda3d.org/manual/?title=Multithreaded_Render_Pipeline
# loadPrcFileData('', 'threading-model Cull/Draw')

# have makeTextureBuffer create a visible window
# loadPrcFileData('', 'show-buffers true')

# TODO: consider moving collision detection to sensors.py
"""
If the collision was with another agent then the ID is the agent ID, otherwise
it's a SocialVehicle ID.
"""
Collision = namedtuple("Collision", ["collided_with_agent", "collidee_id"])


class SMARTSNotSetupError(Exception):
    pass


class SMARTS(ShowBase):
    def __init__(
        self,
        agent_interfaces,
        traffic_sim,
        headless=True,
        timestep_sec=0.1,
        reset_agents_only=False,
    ):
        super().__init__(self, windowType="offscreen")
        gltf.patch_loader(self.loader)

        self._log = logging.getLogger(self.__class__.__name__)

        self._is_setup = False
        self._scenario = None
        self._envision = Envision() if not headless else None
        self._timestep_sec = timestep_sec
        self._traffic_sim = traffic_sim
        self._reset_agents_only = reset_agents_only  # a.k.a "teleportation"

        # Global clock always proceeds by a fixed dt on each tick
        self.taskMgr.clock.setMode(ClockObject.M_non_real_time)
        self.taskMgr.clock.setDt(timestep_sec)

        self.setBackgroundColor(0, 0, 0, 1)

        # Displayed framerate is misleading since we are not using a realtime clock
        self.setFrameRateMeter(False)

        # For macOS GUI. See our `BulletClient` docstring for details.
        # from .utils.bullet_client import BulletClient
        # self._bullet_client = BulletClient(pybullet.GUI)
        self._bullet_client = bc.BulletClient(pybullet.DIRECT)

        # Agent-related setup
        self._ego_agent_ids = set()
        self._social_agent_ids = set()
        self._agent_states = {}
        self._initial_agent_interfaces = agent_interfaces
        self._remote_social_agents = {}
        self._active_agent_vehicles = {}
        self._social_vehicles = {}
        self._mission_planners = {}
        self._agent_collisions = defaultdict(list)  # list of `Collision` instances
        self._bubble_manager = None

        # SceneGraph-related setup
        self._root_np = None
        self._traffic_lights_np = None
        self._vehicles_np = None  # TODO: Rename to `agent_vehicles_np`?
        self._traffic_np = None
        self._road_network_np = None
        self._ground_bullet_id = None

    def step(self, agent_actions):
        if not self._is_setup:
            raise SMARTSNotSetupError("Must call reset() or setup() before stepping")

        try:
            return self._step(agent_actions)
        except (KeyboardInterrupt, SystemExit):
            # ensure we clean-up if the user exits the simulation
            self._log.info("Simulation was interrupted by the user")
            self.destroy()
            raise  # re-raise the KeyboardInterrupt
        except Exception as e:
            self._log.error(
                "Simulation crashed with exception. Attempting to cleanly shutdown."
            )
            self._log.exception(e)
            self.destroy()
            raise  # re-raise

    def _step(self, agent_actions):
        """Steps through the simulation while applying the given agent actions.
        Returns the observations, rewards, and done signals.
        """

        # Due to a limitation of our traffic simulator(SUMO) interface(TRACI), we can
        # only observe traffic state of the previous simulation step.
        #
        # To compensate for this, we:
        #
        # 1. Step the traffic simulation
        # 2. Run rendering pipeline
        # 3. Perform (ego and social) agent actions
        # 4. Calculate resulting reward/observations
        # 5. Send observations to social agents
        # 6. Clear "done" agents
        # 7. Step the physics simulation
        # 8. Perform visualization
        # 9. Step bubble manager
        #
        # In this way, observations and reward are computed with data that is
        # consistently with one step of latencey and the agent will observe consistent
        # data.
        dt = self.taskMgr.clock.get_dt()

        # 1. Step traffic simulation
        self._step_traffic(dt)

        # 2. Render and the other panda internal stuff.
        # It's important we call this here because we rely on the the render pipeline
        # for some of the observation/reward calculations.
        self.taskMgr.mgr.poll()

        # 3. Perform (ego and social) agent actions
        self._perform_agent_actions(agent_actions)
        self._fetch_and_perform_social_agent_actions()
        self._increment_agent_step()

        # 4. Calculate observation and reward
        observations, dones = self._observation()
        rewards = self._reward()
        scores = self._score()

        # Observations, rewards, etc. contain those for social agents; filter them out
        def filter_ego(dict_):
            return {id_: dict_[id_] for id_ in self._ego_agent_ids}

        ego_response = tuple(map(filter_ego, (observations, rewards, scores, dones)))

        # 5. Send observations to social agents
        self._send_observations_to_social_agents(observations)

        # 6. Clear "done" agents
        self._teardown_done_ego_agents(dones)

        # 7. Step the physics simulation
        self._step_physics()

        # 8. Perform visualization
        self._try_emit_envision_state(observations)

        # 9. Step bubble manager
        self._step_bubble_manager()

        return ego_response

    def reset(self, scenario: Scenario):
        if scenario == self._scenario and self._reset_agents_only:
            self._teardown_ego_agents()
            self._setup_ego_agents(scenario)
        else:
            self.teardown()
            self.setup(scenario)

        observations, _ = self._observation()

        # TODO: Too low-level to put here.
        for agent_id, remote_agent in self._remote_social_agents.items():
            remote_agent.send_reset()
            obs = observations[agent_id]
            remote_agent.send_observation(obs)

        # Observations contain those for social agents; filter them out
        def filter_ego(dict_):
            return {id_: dict_[id_] for id_ in self._ego_agent_ids}

        return filter_ego(observations)

    def setup(self, scenario: Scenario):
        self._root_np = NodePath("sim")
        self._root_np.reparentTo(self.render)

        self._scenario = scenario
        self._setup_bullet_client(self._bullet_client)

        self._vehicles_np = self._root_np.attachNewNode("vehicles")
        self._traffic_np = self._root_np.attachNewNode("traffic")

        self._setup_lighting()

        # Must be called after sim setup which adds our agents
        social_vehicle_state, _ = self._traffic_sim.setup(self._scenario)

        self._setup_scenario(self._scenario)

        self._traffic_sim.sync(
            managed_vehicles={
                agent_id: (agent_vehicle.position, agent_vehicle.heading)
                for agent_id, agent_vehicle in self._active_agent_vehicles.items()
            }
        )

        self._sync_traffic_vehicles(social_vehicle_state)

        # TODO: `Scenario.discover_bubbles(...)` should be a method
        bubbles = Scenario.discover_bubbles(scenario.root_filepath)
        self._bubble_manager = BubbleManager(bubbles, self._traffic_sim.road_network)

        self._is_setup = True

    def _setup_scenario(self, scenario: Scenario):
        self._add_road_network_from_egg(scenario.map_egg_filepath)
        self._setup_ego_agents(scenario)
        self._setup_social_agents(scenario)

    def _setup_ego_agents(self, scenario: Scenario):
        for agent_id, agent_interface in self._initial_agent_interfaces.items():
            self._agent_states[agent_id] = AgentState(agent_interface, trainable=True)
            self._add_agent(
                agent_id,
                agent_state=self._agent_states[agent_id],
                mission=scenario.mission(agent_id),
            )
            self._ego_agent_ids.add(agent_id)

    def _setup_social_agents(self, scenario: Scenario):
        # TODO: `Scenario.discover_social_agents(...)` should be a method
        social_agents = Scenario.discover_social_agents(scenario.root_filepath)

        self._remote_social_agents = {
            agent_id: RemoteAgent(social_agent)
            for agent_id, social_agent in social_agents.items()
        }

        for agent_id, social_agent in social_agents.items():
            self._agent_states[agent_id] = AgentState(
                social_agent.interface, trainable=False
            )
            self._add_agent(
                agent_id,
                agent_state=self._agent_states[agent_id],
                mission=scenario.mission(agent_id),
            )
            self._social_agent_ids.add(agent_id)

        for remote_social_agent in self._remote_social_agents.values():
            remote_social_agent.start()

    def _setup_bullet_client(self, client):
        client.resetSimulation()
        client.configureDebugVisualizer(pybullet.COV_ENABLE_GUI, 0)

        # PyBullet defaults the timestep to 240Hz. Several parameters are tuned with
        # this value in mind. For example the number of solver iterations and the error
        # reduction parameters (erp) for contact, friction and non-contact joints.
        # Attempting to get around this we set the number of substeps so that
        # timestep * substeps = 240Hz. Bullet (C++) does something to this effect as
        # well (https://git.io/Jvf0M), but PyBullet does not expose it.
        client.setPhysicsEngineParameter(
            fixedTimeStep=self._timestep_sec,
            numSubSteps=math.ceil(self._timestep_sec / (1 / 240)),
        )

        client.setGravity(0, 0, -9.8)

        plane_path = self._scenario.plane_filepath
        if not os.path.exists(plane_path):
            with pkg_resources.path(models, "plane.urdf") as path:
                plane_path = str(path.absolute())
        self._ground_bullet_id = client.loadURDF(plane_path, useFixedBase=True)

    def teardown(self):
        self._teardown_ego_agents()
        self._teardown_social_agents()
        self._social_vehicles = {}

        self._bullet_client.resetSimulation()
        self._traffic_sim.teardown()

        if self._root_np is not None:
            self._root_np.clearLight()
            self._root_np.removeNode()

        if self._bubble_manager is not None:
            self._bubble_manager.teardown()
            self._bubble_manager = None

        self._vehicles_np = None
        self._traffic_lights_np = None
        self._ground_bullet_id = None
        self._road_network_np = None
        self._is_setup = False

    def _teardown_ego_agents(self):
        self._teardown_agents(self._ego_agent_ids)
        self._ego_agent_ids.clear()

    def _teardown_social_agents(self):
        self._teardown_agents(self._social_agent_ids)
        self._social_agent_ids.clear()

        for remote_agent in self._remote_social_agents.values():
            remote_agent.terminate()

        self._remote_social_agents = {}

    def _teardown_agents(self, agent_ids: Sequence[str]):
        for agent_id in agent_ids:
            if agent_id in self._agent_states:
                self._agent_states[agent_id].teardown()

            if agent_id in self._active_agent_vehicles:
                self._active_agent_vehicles[agent_id].teardown()

            self._agent_states.pop(agent_id, None)
            self._active_agent_vehicles.pop(agent_id, None)
            self._mission_planners.pop(agent_id, None)
            self._agent_collisions.pop(agent_id, None)

    def destroy(self):
        self.teardown()

        if self._envision:
            self._envision.teardown()

        self._bullet_client.disconnect()

        super().destroy()

    def _step_traffic(self, dt):
        # We must calculate the state of the non-traffic vehicles *before* we step the
        # world so that the traffic simulation and the Bullet simulation remain in
        # lock step (otherwise, traffic sim will see state that is  one frame ahead)
        agent_vehicle_states = {
            agent_id: (agent_vehicle.position, agent_vehicle.heading)
            for agent_id, agent_vehicle in self._active_agent_vehicles.items()
        }

        # It's important that we sync managed vehicles before we step the SUMO
        # simulation because the `managed_vehicles` represents the state of these
        # vehicles at start of frame. If we were to sync after we step SUMO, sumo
        # would see these managed vehicles with a 1 step delay.
        self._traffic_sim.sync(agent_vehicle_states)
        social_vehicles, _ = self._traffic_sim.step(dt)

        self._sync_traffic_vehicles(social_vehicles)

    def _sync_traffic_vehicles(self, social_vehicles):
        previous_vehicle_ids = set(self._social_vehicles.keys())
        current_vehicle_ids = set(social_vehicles.keys())

        exited_vehicles = previous_vehicle_ids - current_vehicle_ids
        new_vehicles = current_vehicle_ids - previous_vehicle_ids

        for v_id in exited_vehicles:
            social_vehicle = self._social_vehicles[v_id]
            social_vehicle.teardown()
            del self._social_vehicles[v_id]

        for v_id in new_vehicles:
            vehicle_type = social_vehicles[v_id].vehicle_type
            social_vehicle = SocialVehicle(
                v_id, self, self._bullet_client, vehicle_type=vehicle_type
            )
            self._social_vehicles[v_id] = social_vehicle
            social_vehicle.np.reparentTo(self._root_np)

        for v in social_vehicles.values():
            assert v.vehicle_id in self._social_vehicles
            self._social_vehicles[v.vehicle_id].update_from_traffic_sim(v)

    def _step_physics(self):
        self._bullet_client.stepSimulation()

        for _, agent_vehicle in self._active_agent_vehicles.items():
            # This is inspired by Panda3D's `doPhysics` which has a `sync_p2b` and
            # `sync_b2p` (for Panda3D <--> Bullet3 syncing). We'll likely want to
            # move this code to a seperate BulletPhysicsSim-type class.
            agent_vehicle.sync_physics()

        self._process_collisions()

    def _step_bubble_manager(self):
        state_change = self._bubble_manager.step(self._social_vehicles.values())

        for sv_id, actor in state_change.to_hijack:
            social_vehicle = self._social_vehicles[sv_id]
            agent_id = self._hijack_social_vehicle_with_social_agent(sv_id, actor)
            social_agent_vehicle = self._active_agent_vehicles[agent_id]
            self._bubble_manager.vehicle_swap_complete(
                from_=(sv_id, social_vehicle), to=(agent_id, social_agent_vehicle)
            )

        for agent_id in state_change.to_relinquish:
            social_agent_vehicle = self._active_agent_vehicles[agent_id]
            sv_id = self._relinquish_social_agent_to_traffic_sim(agent_id)
            social_vehicle = self._social_vehicles[sv_id]
            self._bubble_manager.vehicle_swap_complete(
                from_=(agent_id, social_agent_vehicle), to=(sv_id, social_vehicle),
            )

    @property
    def scenario(self):
        return self._scenario

    @property
    def traffic_sim(self):
        return self._traffic_sim

    @property
    def waypoints(self):
        """Convenience property to access the `Waypoints` object."""
        return self._traffic_sim.waypoints

    @property
    def np(self):
        return self._root_np

    @property
    def timestep_sec(self):
        return self._timestep_sec

    def neighborhood_vehicles_around_agent(self, agent_id, radius=None):
        other_states = [v for v in self._vehicle_states if v.id != agent_id]
        if radius is None:
            return other_states

        agent_position = self._active_agent_vehicles[agent_id].position
        other_positions = [state.position for state in other_states]
        if not other_positions:
            return []

        distances = euclidean_distances(other_positions, [agent_position]).reshape(-1,)
        indices = numpy.argwhere(distances <= radius).flatten()
        return [other_states[i] for i in indices]

    def _reward(self):
        # TODO: eliminate reward; we should instead return only score.
        agent_rewards = {}
        for agent_id in self._active_agent_vehicles:
            agent_state = self._agent_states[agent_id]
            agent_rewards[agent_id] = Sensors.score_increment(self, agent_state)

        return agent_rewards

    def _score(self):
        agent_scores = {}
        for agent_id in self._active_agent_vehicles:
            agent_state = self._agent_states[agent_id]
            agent_scores[agent_id] = agent_state.sensor_state.distance_travelled

        return agent_scores

    def _observation(self):
        # We pre-compute vehicle_states here because we *think* the users will
        # want these during their observation/reward computations.
        # This is a hack to give us some short term perf wins. Longer term we
        # need to expose better support for batched computations
        self._vehicle_states = self._compute_vehicle_states()

        observations = {}

        # On setup, we create a corresponding vehicle for each agent interface.
        # If the vehicle that corresponds to an agent_interface is removed at
        # runtime, then that agent is considered done.
        dones = {
            agent_id: True
            for agent_id in self._agent_states
            if agent_id not in self._active_agent_vehicles
        }

        for agent_id in self._active_agent_vehicles:
            agent_state = self._agent_states[agent_id]
            vehicle = self._active_agent_vehicles[agent_id]
            observations[agent_id], dones[agent_id] = Sensors.observe(
                self, agent_id, agent_state, vehicle
            )

        return observations, dones

    def _add_road_network_from_egg(self, egg_path):
        if self._road_network_np:
            self._log.debug(
                "road_network={} already exists. Removing and adding a new "
                "one from egg_path={}".format(self._road_network_np, egg_path)
            )

        np = self._root_np.attachNewNode("road_network")
        model_np = self.loader.loadModel(egg_path)
        model_np.reparent_to(np)
        np.hide(RenderMasks.OCCUPANCY_HIDE)
        self._road_network_np = np
        return np

    def _add_agent(self, agent_id, agent_state: AgentState, mission: Mission):
        assert agent_id not in self._active_agent_vehicles
        assert isinstance(agent_id, str)  # SUMO expects strings identifiers

        planner = MissionPlanner(
            self._traffic_sim.waypoints, self._traffic_sim.road_network
        )
        planned_mission = planner.plan(mission)

        # HACK: Somehow our hiway.units.Heading float wrapper is getting removed by rllib
        #       when it serializes the environment config and comunicates via IPC as a
        #       temporary workaround, we just add the Heading wrapper if it's missing here
        if isinstance(planned_mission.start.heading, Heading):
            heading = planned_mission.start.heading
        else:
            heading = Heading(planned_mission.start.heading)

        agent_vehicle = self._build_vehicle(
            (*planned_mission.start.position, 0.0), heading, agent_state
        )

        agent_state.setup(self, agent_id, agent_vehicle)
        self._active_agent_vehicles[agent_id] = agent_vehicle
        self._mission_planners[agent_id] = planner

    def agent_reached_goal(self, agent_id):
        agent_vehicle = self._active_agent_vehicles[agent_id]

        goal = self._mission_planners[agent_id].mission.goal
        return goal.did_reach(agent_vehicle)

    def agent_is_off_road(self, agent_id):
        agent_vehicle = self._active_agent_vehicles[agent_id]
        vehicle_pos = agent_vehicle.position

        dist_to_nearest_wp = self._traffic_sim.waypoints.closest_waypoint(
            vehicle_pos
        ).dist_to(vehicle_pos)

        is_off_road = dist_to_nearest_wp > 3.0
        return is_off_road

    def agent_did_collide(self, agent_id):
        return len(self._agent_collisions[agent_id]) > 0

    def agent_collisions(self, agent_id):
        return self._agent_collisions[agent_id]

    def _hijack_social_vehicle_with_social_agent(
        self, social_vehicle_id: str, social_agent_actor: SocialAgentActor,
    ) -> str:
        self._log.debug(
            f"Hijack social_vehicle={social_vehicle_id} with "
            f"actor={social_agent_actor}"
        )
        social_agent = make_social_agent(locator=social_agent_actor.agent_locator)
        agent_state = AgentState(social_agent.interface, trainable=False)
        agent_id = self._hijack_social_vehicle(social_vehicle_id, agent_state)
        self._social_agent_ids.add(agent_id)

        remote_agent = RemoteAgent(social_agent)
        self._remote_social_agents[agent_id] = remote_agent
        remote_agent.start()

        return agent_id

    def _hijack_social_vehicle_with_ego_agent(
        self, social_vehicle_id: str, agent_interface: AgentInterface
    ) -> str:
        self._log.debug(
            f"Hijack social_vehicle={social_vehicle_id} with "
            f"agent_interface={agent_interface}"
        )

        agent_state = AgentState(agent_interface, trainable=True)
        agent_id = self._hijack_social_vehicle(social_vehicle_id, agent_interface)
        self._ego_agent_ids.add(agent_id)
        return agent_id

    def _hijack_social_vehicle(
        self, social_vehicle_id: str, agent_state: AgentState
    ) -> str:
        social_vehicle = self._social_vehicles[social_vehicle_id]

        agent_id = f"hijacked-{social_vehicle_id}"
        self._agent_states[agent_id] = agent_state

        # TODO: What do we want the mission to be?
        mission = Mission(
            start=Start(social_vehicle.position[:2], social_vehicle.heading),
            goal=EndlessGoal(),
        )
        self._add_agent(agent_id, agent_state, mission)

        # Removing the social vehicle from the traffic sim will go in effect
        # next step where our internal `self._social_vehicles` gets synced
        self._traffic_sim.remove_vehicle(social_vehicle_id)

        return agent_id

    def _relinquish_social_agent_to_traffic_sim(self, agent_id: str) -> str:
        self._log.debug(f"Relinquish social_agent={agent_id} to traffic simulation")
        vehicle = self._active_agent_vehicles[agent_id]
        position = vehicle.position

        self._teardown_agents([agent_id])
        self._social_agent_ids.remove(agent_id)

        self._remote_social_agents[agent_id].terminate()
        del self._remote_social_agents[agent_id]

        sv_id = self._traffic_sim.emit_vehicle_from_position(position)
        social_vehicle = SocialVehicle(sv_id, self, self._bullet_client)
        social_vehicle.np.reparentTo(self._root_np)
        self._social_vehicles[sv_id] = social_vehicle
        return sv_id

    def relinquish_ego_agent_to_traffic_sim(self, agent_id: str) -> str:
        raise NotImplementedError

    def mission_planner(self, agent_id):
        return self._mission_planners[agent_id]

    def _increment_agent_step(self):
        # XXX: not sure we should be tracking the steps per agent at all.
        for agent_id in self._active_agent_vehicles:
            agent_state = self._agent_states[agent_id]
            Sensors.step(self, agent_state)

    def _send_observations_to_social_agents(self, observations):
        # Only send observations to active agent vehicles. This is because we don't
        # remove social agents when they are "done".
        active_social_agent_ids = set(self._active_agent_vehicles.keys()).intersection(
            self._social_agent_ids
        )

        for agent_id in active_social_agent_ids:
            remote_agent = self._remote_social_agents[agent_id]
            obs = observations[agent_id]
            remote_agent.send_observation(obs)

    def _fetch_and_perform_social_agent_actions(self):
        social_agent_actions = {
            agent_id: remote_agent.recv_action(timeout=5)
            for agent_id, remote_agent in self._remote_social_agents.items()
        }

        agents_without_actions = [
            agent_id
            for (agent_id, action) in social_agent_actions.items()
            if action is None
        ]

        if len(agents_without_actions) > 0:
            self._log.info(
                f"social_agents=({', '.join(agents_without_actions)}) returned no action, skipping"
            )

        for agent_id in agents_without_actions:
            del social_agent_actions[agent_id]

        self._perform_agent_actions(social_agent_actions)

    def _perform_agent_actions(self, agent_actions):
        for agent_id, action in agent_actions.items():
            if agent_id not in self._active_agent_vehicles:
                self._log.warning(
                    f"{agent_id} doesn't have a vehicle, is the agent done? (dropping action)"
                )
            else:
                agent_state = self._agent_states[agent_id]
                agent_vehicle = self._active_agent_vehicles[agent_id]
                Controllers.perform_action(
                    self, agent_id, agent_state, agent_vehicle, action
                )

    def _teardown_done_ego_agents(self, dones):
        # We do not want to teardown social agents as we are prioritizing
        # simulation cohesion over social agent behaviour stability.
        done_agent_ids = set(filter(lambda id_: dones[id_], self._ego_agent_ids))
        self._teardown_agents(done_agent_ids)
        self._ego_agent_ids -= done_agent_ids

    def _build_vehicle(self, pos, heading: Heading, agent_state: AgentState):
        assert isinstance(heading, Heading)

        vehicle_color = (1.0, 0.2, 0.2, 1) if agent_state.trainable else (1, 0.6, 0, 1)
        vehicle = Vehicle(
            pos,
            heading,
            self._root_np,
            self,
            self._bullet_client,
            track_path=bool(self._envision),
            color=vehicle_color,
            vehicle_filepath=self._scenario.vehicle_filepath,
        )
        vehicle.np.reparentTo(self._vehicles_np)

        if agent_state.ogm_subscribed:
            vehicle.init_observation_ogm(
                agent_state.ogm_subscription.width,
                agent_state.ogm_subscription.height,
                agent_state.ogm_subscription.resolution,
            )
        if agent_state.rgb_subscribed:
            vehicle.init_observation_rgb(
                agent_state.rgb_subscription.width,
                agent_state.rgb_subscription.height,
                agent_state.rgb_subscription.resolution,
            )
        if agent_state.lidar_subscribed:
            vehicle.init_observation_lidar(agent_state.lidar_subscription.sensor_params)

        return vehicle

    def _compute_vehicle_states(self):
        vehicles = []
        for vehicle in self._social_vehicles.values():
            vehicles.append(vehicle)

        for agent_id, vehicle in self._active_agent_vehicles.items():
            vehicles.append(
                SocialVehicle(
                    agent_id,
                    self,
                    self._bullet_client,
                    speed=vehicle.speed,
                    np=vehicle.np,
                    bullet_body=vehicle.bullet_vehicle,
                )
            )

        if len(vehicles) == 0:
            return []

        wps = self._traffic_sim.waypoints.closest_waypoint_batched(
            [v.position for v in vehicles]
        )

        vehicle_states = [
            v.state(wp.lane_id, wp.lane_index) for v, wp in zip(vehicles, wps)
        ]

        return vehicle_states

    def _process_collisions(self):
        self._agent_collisions = defaultdict(list)  # list of `Collision` instances

        for agent_id, vehicle in self._active_agent_vehicles.items():
            # We are only concerned with vehicle-vehicle collisions
            collidee_bullet_ids = set([p.bullet_id for p in vehicle.contact_points])
            collidee_bullet_ids.discard(self._ground_bullet_id)

            if not collidee_bullet_ids:
                continue

            for bullet_id in collidee_bullet_ids:
                collidee = self._bullet_id_to_vehicle(bullet_id)
                collision = self._node_to_collision(collidee.np.node())
                self._agent_collisions[agent_id].append(collision)

    def _bullet_id_to_vehicle(self, bullet_id):
        # TODO: Temporary solution, implement something less blind/invasive.
        for agent_vehicle in self._active_agent_vehicles.values():
            if bullet_id == agent_vehicle.bullet_id:
                return agent_vehicle

        for social_vehicle in self._social_vehicles.values():
            if bullet_id == social_vehicle.bullet_id:
                return social_vehicle

        assert False, "Only collisions with agent or social vehicles is supported"

    def _node_to_collision(self, node):
        for agent_id, agent_vehicle in self._active_agent_vehicles.items():
            if node == agent_vehicle.np.node():
                return Collision(collided_with_agent=True, collidee_id=agent_id)

        # Collidee wasn't an agent, must be a social vehicle
        for social_id, social_vehicle in self._social_vehicles.items():
            if node == social_vehicle.np.node():
                return Collision(collided_with_agent=False, collidee_id=social_id)

        assert False, "Only collisions with agent or social vehicles is supported"

    def _try_emit_envision_state(self, obs):
        if not self._envision:
            return

        traffic = {}
        for agent_id, vehicle in self._active_agent_vehicles.items():
            actor_type = envision_types.TrafficActorType.SocialAgent
            if self._agent_states[agent_id].trainable:
                actor_type = envision_types.TrafficActorType.Agent

            point_cloud = obs[agent_id].lidar_point_cloud or []
            # TODO: Convert to `namedtuple` or only return point cloud
            if len(point_cloud) == 3:  # points, hits, rays
                point_cloud = point_cloud[0]

            traffic[agent_id] = envision_types.TrafficActorState(
                actor_type=actor_type,
                vehicle_type=envision_types.VehicleType.Car,
                position=list(vehicle.position),
                heading=vehicle.heading,
                waypoint_paths=obs[agent_id].waypoint_paths,
                point_cloud=point_cloud,
                driven_path=vehicle.driven_path,
            )

        for sv_id, vehicle in self._social_vehicles.items():
            traffic[sv_id] = envision_types.TrafficActorState(
                actor_type=envision_types.TrafficActorType.SocialVehicle,
                vehicle_type=vehicle.vehicle_type,
                position=list(vehicle.position),
                heading=vehicle.heading,
            )

        bubble_geometry = [
            list(bubble.geometry.exterior.coords)
            for bubble in self._bubble_manager.bubbles
        ]
        state = envision_types.State(
            traffic=traffic, geom_road_id=self._scenario.name, bubbles=bubble_geometry
        )
        self._envision.send_state(state)

    def _setup_lighting(self):
        alight = AmbientLight("ambient_light")
        alight.setColor((1, 1, 1, 1))
        alight_np = self._root_np.attachNewNode(alight)
        self._root_np.setLight(alight_np)
