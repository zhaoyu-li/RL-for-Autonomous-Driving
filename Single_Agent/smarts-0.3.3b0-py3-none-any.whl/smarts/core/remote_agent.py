import queue
import multiprocessing


class QueueDone:
    pass


class RemoteAgent:
    def __init__(self, agent):
        self._agent = agent
        self._agent_proc = None

    def send_reset(self):
        self._input_queue.put({"type": "control", "payload": "reset"})

    def send_observation(self, obs):
        self._input_queue.put({"type": "obs", "payload": obs})

    def recv_action(self, timeout=None):
        if self._action_queue.empty():
            return None

        try:
            return self._action_queue.get(timeout=timeout)
        except queue.Empty:
            return None

    def start(self):
        if self._agent_proc:
            return

        self._input_queue = multiprocessing.Manager().Queue()
        self._action_queue = multiprocessing.Manager().Queue()

        def agent_event_loop():
            self._agent.setup()
            while True:
                msg = self._input_queue.get()
                if type(msg) is QueueDone:
                    break

                if msg["type"] == "control" and msg["payload"] == "reset":
                    self._agent.reset()
                elif msg["type"] == "obs":
                    obs = msg["payload"]
                    action = self._agent.act_with_adaptation(obs)
                    self._action_queue.put(action)
                else:
                    raise NotImplementedError(
                        f'RemoteAgent doesn\'t understand "{msg}"'
                    )

        self._agent_proc = multiprocessing.Process(target=agent_event_loop)
        self._agent_proc.start()

    def terminate(self):
        if self._agent_proc:
            self._input_queue.put(QueueDone())
            self._agent_proc.terminate()
            self._agent_proc = None
