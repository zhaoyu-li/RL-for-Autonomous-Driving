import logging
from enum import Enum
from dataclasses import dataclass, field
from typing import Sequence, Dict, Tuple, Union

from shapely.geometry import Polygon, Point

from smarts.sstudio.types import Bubble as SSBubble
from smarts.sstudio.types import SocialAgentActor
from smarts.core.social_vehicle import SocialVehicle
from smarts.core.vehicle import Vehicle
from smarts.core.sumo_road_network import SumoRoadNetwork


class BubbleState(Enum):
    # --> [  AirlockEntered  [  Entered  ]  Exited  ]  AirlockExited -->
    AirlockEntered = 0  #  --> (Airlock)
    Entered = 1  #  Airlock --> (Bubble)
    Exited = 2  #  Bubble --> (Airlock)
    AirlockExited = 3  #  Airlock -->


class Bubble:
    """Adhears to the same interface as `sstudio.types.Bubble` but caches the bubble
    geometry.
    """

    def __init__(self, bubble: SSBubble, sumo_road_network: SumoRoadNetwork):
        self._bubble = bubble
        geometry = self._bubble.zone.to_geometry(sumo_road_network)
        self._cached_inner_geometry = geometry
        self._cached_airlock_geometry = geometry.buffer(bubble.margin)

    @property
    def zone(self):
        return self._bubble.zone

    @property
    def actor(self) -> SocialAgentActor:
        return self._bubble.actor

    @property
    def geometry(self) -> Polygon:
        return self._cached_inner_geometry

    @property
    def airlock_geometry(self) -> Polygon:
        return self._cached_airlock_geometry


@dataclass
class Cursor:
    """Tracks a vehicle through an airlock or a bubble."""

    # We would always want to have the vehicle go through the airlock zone. This may
    # not be the case if we spawn a vehicle in a bubble, but that wouldn't be ideal.
    vehicle: Union[Vehicle, SocialVehicle]
    state: BubbleState = None
    bubble: Bubble = None
    tracking_id: str = field(init=False)

    def __post_init__(self):
        assert isinstance(self.vehicle, SocialVehicle), (
            "Cursors can presently only be instantiated with type(vehicle) == "
            "SocialVehicle. Though the vehicle type can change mid-flight to Vehicle "
            "during hijacking."
        )

        self.tracking_id = self.vehicle.id

    def update(self) -> bool:
        """
        Going through an airlock transitions a vehicle between traffic control and
        agent control (into bubble; vice-versa out of bubble).

        Returns `True` on transition (entered or exited zone)
        """
        pos = Point(self.vehicle.position)

        state = self.state
        if pos.within(self.bubble.geometry):
            state = BubbleState.Entered
        elif state is None and pos.within(self.bubble.airlock_geometry):
            state = BubbleState.AirlockEntered
        elif state == BubbleState.Entered and not pos.within(self.bubble.geometry):
            state = BubbleState.Exited
        elif state == BubbleState.Exited and not pos.within(
            self.bubble.airlock_geometry
        ):
            state = BubbleState.AirlockExited

        state_changed = state != self.state
        self.state = state
        return state_changed


@dataclass(frozen=True)
class BubbleStateChange:
    # [(<social_vehicle_id>, <social_agent_actor>), ...]
    to_hijack: Sequence[Tuple[str, SocialAgentActor, Sequence]]

    # [<agent_id>, ...]
    to_relinquish: Sequence[str]


class BubbleManager:
    def __init__(self, bubbles: Sequence[SSBubble], road_network: SumoRoadNetwork):
        self._log = logging.getLogger(self.__class__.__name__)
        self._cursors = []
        self._bubbles = [Bubble(b, road_network) for b in bubbles]

    @property
    def bubbles(self) -> Sequence[Bubble]:
        return self._bubbles

    def step(self, social_vehicles: Sequence[SocialVehicle]) -> BubbleStateChange:
        # Detect vehicles entering bubbles (and airlocks)
        for sv in social_vehicles:
            cursor = self._find_cursor(sv.id)
            if cursor is not None:
                # Already tracking this vehicle
                continue

            # We didn't have a cursor for this vehicle yet
            cursor = self._obtain_cursor_if_entered_airlock(sv)
            if cursor is not None:
                self._cursors.append(cursor)

        to_hijack, to_relinquish, kept_cursors = [], [], []
        for cursor in self._cursors:
            if not cursor.update():
                kept_cursors.append(cursor)
                continue

            if cursor.state == BubbleState.AirlockExited:
                self._log.debug(
                    f"vehicle={cursor.tracking_id} exited bubble and airlock"
                )
                continue
            elif cursor.state == BubbleState.AirlockEntered:
                self._log.debug(f"vehicle={cursor.tracking_id} entered airlock")
            elif cursor.state == BubbleState.Entered:
                to_hijack.append((cursor.tracking_id, cursor.bubble.actor))
                self._log.debug(f"vehicle={cursor.tracking_id} entered bubble")
            elif cursor.state == BubbleState.Exited:
                to_relinquish.append((cursor.tracking_id))
                self._log.debug(f"vehicle={cursor.tracking_id} exited bubble")

            kept_cursors.append(cursor)

        self._cursors = kept_cursors
        return BubbleStateChange(to_hijack=to_hijack, to_relinquish=to_relinquish)

    def _obtain_cursor_if_entered_airlock(self, social_vehicle: SocialVehicle):
        """If a vehicle entered an airlock we return a corresponding cursor. We do not
        handle overlapping airlocks/bubbles, but only return a cursor for the first
        according to the provided order.
        """
        pos = Point(social_vehicle.position)
        for bubble in self._bubbles:
            if pos.within(bubble.airlock_geometry):
                return Cursor(vehicle=social_vehicle, bubble=bubble)

        return None  # not in bubble

    def _find_cursor(self, tracking_id: str):
        for cursor in self._cursors:
            if cursor.tracking_id == tracking_id:
                return cursor

        return None  # not found

    # TODO: This method is a temporary hack. We don't want to actually be swapping
    #       vehicles. Once swapping is removed, tracking IDs will go unchanged post
    #       hijacking so our self._cursors can be a dictionary of { id: cursor } w/
    #       the cursor.tracking_id pulled out as the key.
    def vehicle_swap_complete(
        self,
        from_: Tuple[str, Union[Vehicle, SocialVehicle]],
        to: Tuple[str, Union[Vehicle, SocialVehicle]],
    ):
        cursor = self._find_cursor(from_[0])
        cursor.tracking_id, cursor.vehicle = to

    def teardown(self):
        self._cursors = []
        self._bubbles = []
