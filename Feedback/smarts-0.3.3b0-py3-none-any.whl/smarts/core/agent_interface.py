from enum import IntEnum
from dataclasses import dataclass

from .controllers import ActionSpaceType
from .lidar_sensor_params import SensorParams as LidarSensorParams
from .lidar_sensor_params import BasicLidar


@dataclass
class OGM:
    """The width and height are in "pixels" and the resolution is the "size of a
    pixel". E.g. if you wanted 100m x 100m OGM but a 64x64 image representation
    you would do OGM(width=64, height=64, resolution=100/64)
    """

    width: int = 256
    height: int = 256
    resolution: float = 50 / 256


@dataclass
class RGB:
    """The width and height are in "pixels" and the resolution is the "size of a
    pixel". E.g. if you wanted 100m x 100m RGB but a 256x256 image representation
    you would do RGB(width=256, height=256, resolution=100/256)
    """

    width: int = 256
    height: int = 256
    resolution: float = 50 / 256


@dataclass
class Lidar:
    """ Lidar point cloud observations
    """

    sensor_params: LidarSensorParams = BasicLidar


@dataclass
class Waypoints:
    # The number of waypoints we want to look ahead by. The "distance" of this depends
    # on the waypoint spacing set. The project default for that is one meter.
    lookahead: int = 50


@dataclass
class NeighborhoodVehicles:
    # `None` means no radius filtering
    radius: float = None


class AgentType(IntEnum):
    ## Sees nothing, does nothing
    Buddha = 0
    ## All observations and continuous action space
    Full = 1
    ## Minimal observations for dealing with waypoints and other vehicles
    Standard = 2
    ## Focused on the lane to the exclusion of everything else
    Laner = 3
    ## Focused on learning to follow the lane
    Loner = 4
    ## Intended for a game of Tag with two vehicles
    Tagger = 5
    StandardWithAbsoluteSteering = 6


class AgentInterface:
    """ An adaptor used to wrap and enable agent observation and action flow.
    """

    @staticmethod
    def from_type(requested_type, max_episode_steps=None, debug=True):
        """ Instantiates from a selection of agent_interface presets

        Buddha: Agent sees nothing and does nothing
        Full: Agent sees waypoints, ogm, rgb, lidar, neighbor vehicles; and performs continuous action
        Standard: Agent sees waypoints, neighbor vehicles; and performs continuous action
        with throttle, brake and steering rate
        StandardWithAbsoluteSteering: Agent sees waypoints, neighbor vehicles; and performs continuous action
        with throttle, brake and wheel angle.
        Laner: Agent sees waypoints and performs lane actions
        Loner: Agent sees waypoints and performs continuous actions
        Tag: Agent sees waypoints and performs continuous actions
        """
        if requested_type == AgentType.Buddha:  # The enlightened one.
            return AgentInterface()
        elif requested_type == AgentType.Full:  # Uses everything.
            return AgentInterface(
                max_episode_steps=max_episode_steps,
                neighborhood_vehicles=True,
                waypoints=True,
                ogm=True,
                rgb=True,
                lidar=True,
                action=ActionSpaceType.Continuous,
                debug=debug,
            )
        elif (
            requested_type == AgentType.StandardWithAbsoluteSteering
        ):  # Uses low dimensional observations.
            return AgentInterface(
                max_episode_steps=max_episode_steps,
                waypoints=True,
                neighborhood_vehicles=True,
                action=ActionSpaceType.Continuous,
                debug=debug,
            )
        elif requested_type == AgentType.Standard:
            return AgentInterface(
                max_episode_steps=max_episode_steps,
                waypoints=True,
                neighborhood_vehicles=True,
                action=ActionSpaceType.ActuatorDynamic,
                debug=debug,
            )
        elif requested_type == AgentType.Laner:  # The lane-following agent
            return AgentInterface(
                max_episode_steps=max_episode_steps,
                waypoints=True,
                action=ActionSpaceType.Lane,
                debug=debug,
            )
        elif (
            requested_type == AgentType.Loner
        ):  # For empty environment, good for testing control.
            return AgentInterface(
                max_episode_steps=max_episode_steps,
                waypoints=True,
                action=ActionSpaceType.Continuous,
                debug=debug,
            )
        elif (
            requested_type == AgentType.Tagger
        ):  # Plays tag -- two vehicles in the env only.
            return AgentInterface(
                max_episode_steps=max_episode_steps,
                waypoints=True,
                action=ActionSpaceType.Continuous,
                debug=debug,
            )
        else:
            raise Exception("Unsupported agent type %s" % requested_type)

    @staticmethod
    def _resolve_config(config, type_):
        if config is True:
            return type_()
        elif isinstance(config, type_):
            return config
        else:
            return None

    def __init__(
        self,
        max_episode_steps: int = None,
        neighborhood_vehicles: NeighborhoodVehicles = None,
        waypoints: Waypoints = None,
        ogm: OGM = None,
        rgb: RGB = None,
        lidar: Lidar = None,
        action: ActionSpaceType = None,
        debug: bool = False,
    ):
        """
        max_episode_steps: The maximum number of steps the agent will try to perform before terminating.
        neighborhood_vehicles[T|F|obj]: If the agent can see neighborhood vehicles
        waypoints[T|F|obj]: If the agent can see waypoints
        ogm[T|F|obj]: If the agent generates and uses an Occupancy Grid Map
        rgb[T|F|obj]: If the agent has access to image based observation
        lidar[T|F|obj]: If the agent generates and uses a LIDAR point cloud
        action: If Continuous agent will act with throttle, break, and steering separately
        debug: If debugging the agent observations is enabled
        """
        self.max_episode_steps = max_episode_steps

        self.neighborhood_vehicles = AgentInterface._resolve_config(
            neighborhood_vehicles, NeighborhoodVehicles
        )
        self.waypoints = AgentInterface._resolve_config(waypoints, Waypoints)
        self.ogm = AgentInterface._resolve_config(ogm, OGM)
        self.rgb = AgentInterface._resolve_config(rgb, RGB)
        self.lidar = AgentInterface._resolve_config(lidar, Lidar)
        self.action_space = action

        self.debug = debug
