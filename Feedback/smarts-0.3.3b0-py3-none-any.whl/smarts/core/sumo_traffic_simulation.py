import numpy
import os
import sys
import logging
import math
import time
import subprocess
import random
from typing import NamedTuple, Tuple
from collections import defaultdict

from .sumo_road_network import SumoRoadNetwork
from .units import Heading
from .utils.sumo import sumolib, traci, SUMO_PATH
from .waypoints import Waypoints


# We need to import .utils.sumo before we can use traci
import traci.constants as tc
from traci.exceptions import TraCIException, FatalTraCIError


class TrafficSimVehicle(NamedTuple):
    vehicle_id: str
    vehicle_type: str
    position: Tuple
    heading: float
    speed: float


class SumoTrafficSimulation:
    def __init__(self, headless=False, time_resolution=0.1, debug=True):
        """
        Args:
            net_file: path to sumo .net.xml file
            headless: (default: False)
              False to run with `sumo-gui`. True to run with `sumo`
            time_resolution: (default: 0.016)
              The SUMO simulation is descretized into steps of `time_resolution` seconds
              WARNING:
                Since our interface(TRACI) to SUMO is delayed by one simulation step, setting
                a higher time resolution may lead to unexpected artifacts.
        """
        self._log = logging.getLogger(self.__class__.__name__)

        self._debug = debug
        self._scenario = None
        self._time_resolution = time_resolution
        self._headless = headless
        self._cumulative_sim_seconds = 0
        self._non_sumo_vehicle_ids = set()
        self._is_setup = False
        self._road_network = None
        self._waypoints = None
        self._last_trigger_time = -1000000
        self._num_dynamic_routes_added = 0
        self._traci_conn = None

    def __repr__(self):
        return f"""SumoTrafficSim(
  _scenario={repr(self._scenario)},
  _time_resolution={self._time_resolution},
  _headless={self._headless},
  _cumulative_sim_seconds={self._cumulative_sim_seconds},
  _non_sumo_vehicle_ids={self._non_sumo_vehicle_ids},
  _is_setup={self._is_setup},
  _road_network={repr(self._road_network)},
  _last_trigger_time={self._last_trigger_time},
  _num_dynamic_routes_added={self._num_dynamic_routes_added},
  _traci_conn={repr(self._traci_conn)}
)"""

    def __str__(self):
        return repr(self)

    def _initialize_traci_conn(self, num_retries=5):
        # TODO: inline sumo or process pool
        # the retries are to deal with port collisions
        #   since the way we start sumo here has a race condition on
        #   each spawned process claiming a port
        for i in range(num_retries):
            if self._traci_conn:
                self._traci_conn.close()
                self._traci_conn = None

            sumo_port = sumolib.miscutils.getFreeSocketPort()
            sumo_binary = "sumo" if self._headless else "sumo-gui"
            sumo_cmd = [
                os.path.join(SUMO_PATH, "bin", sumo_binary),
                "--remote-port=%s" % sumo_port,
                *self._base_sumo_load_params(),
            ]

            self._log.debug("Starting sumo process:\n\t %s", sumo_cmd)
            sumo_proc = subprocess.Popen(
                sumo_cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            time.sleep(0.05)  # give SUMO time to start
            self._traci_conn = traci.connect(
                sumo_port, numRetries=100, proc=sumo_proc, waitBetweenRetries=0.01
            )  # SUMO must be ready within 1 second.

            try:
                assert (
                    self._traci_conn.getVersion()[0] >= 20
                ), "TraCI API version must be >= 20 (SUMO 1.5.0)"
            # We will retry since this is our first sumo command
            except FatalTraCIError:
                logging.debug("Connection closed. Retrying...")
                continue
            except ConnectionRefusedError:
                logging.debug(
                    "Connection refused. Tried to connect to unpaired TraCI client."
                )
                continue
            break

        # if this fails it is because of competing for ports
        self._traci_conn.getVersion()

        self._log.debug("Finished starting sumo process")

    def _base_sumo_load_params(self):
        load_params = [
            "--net-file=%s" % self._scenario.net_filepath,
            "--start",
            "--quit-on-end",
            "--log=%s" % self._scenario.sumo_log_dir,
            "--error-log=%s" % self._scenario.sumo_log_dir,
            "--no-step-log",
            "--no-warnings=1",
            "--seed=%s" % random.randint(0, 2147483648),
        ]

        if self._scenario.route_files_enabled:
            load_params.append("--route-files={}".format(self._scenario.route_filepath))

        return load_params

    def setup(self, scenario):
        self._log.debug("Setting up SumoTrafficSim %s" % self)
        assert not self._is_setup, (
            "Can't setup twice, %s, see teardown()" % self._is_setup
        )

        self._scenario = scenario

        # We force reinitialization of TRACI and the underlying SUMO process.
        # This incurs ~50ms of overhead on an i9 Ubuntu desktop. But it prevents
        # the simulation from freezing at a call to self._traci_conn.simulationStep()
        # after dozens of scenario swapping. Issue #353.
        self._initialize_traci_conn()

        assert self._traci_conn is not None, "No active traci conn"

        self._road_network = SumoRoadNetwork.from_file(self._scenario.net_filepath)
        self._waypoints = Waypoints(self._road_network, spacing=1.0, debug=self._debug)
        # XXX: Can likely move more params into `_base_sumo...`
        load_params = [
            "--lanechange.duration=3.0",  # smooth lane changes
            "--step-length=%f" % self._time_resolution,
            "--begin=0",  # start simulation at time=0
            "--end=3153600",  # keep the simulation running for a year
            *self._base_sumo_load_params(),
        ]

        self._traci_conn.load(load_params)

        self._traci_conn.simulation.subscribe(
            [tc.VAR_DEPARTED_VEHICLES_IDS, tc.VAR_ARRIVED_VEHICLES_IDS]
        )

        for tls_id in self._traci_conn.trafficlight.getIDList():
            self._traci_conn.trafficlight.subscribe(
                tls_id, [tc.TL_RED_YELLOW_GREEN_STATE, tc.TL_CONTROLLED_LINKS]
            )

        # XXX: SUMO caches the previous subscription results. Calling `simulationStep`
        #      effectively flushes the results. We need to use epsilon instead of zero
        #      as zero will step according to a default (non-zero) step-size.
        self.step(1e-6)

        self._is_setup = True

        return self._compute_traffic_vehicles(), self._compute_traffic_lights()

    def teardown(self):
        self._log.debug("Tearing down SUMO traffic sim %s" % self)
        if not self._is_setup:
            self._log.warning("Nothing to teardown")
            return

        assert self._is_setup
        if self._traci_conn:
            self._traci_conn.close()
            self._traci_conn = None
        self._cumulative_sim_seconds = 0
        self._non_sumo_vehicle_ids = set()
        self._is_setup = False
        self._last_trigger_time = -1000000
        self._num_dynamic_routes_added = 0

    def remove_vehicle(self, vehicle_id):
        self._traci_conn.vehicle.remove(vehicle_id)

    @property
    def road_network(self):
        return self._road_network

    @property
    def waypoints(self):
        return self._waypoints

    def step(self, dt):
        """
        Args:
            dt: time (in seconds) to simulate during this simulation step
            managed_vehicles: dict of {vehicle_id: (x, y, heading)}
                !! The vehicle state should represent the state of the
                !! vehicles at the start of the current simulation step
        Returns:
            list[TrafficSimVehicle] representing state of all SUMO-managed vehicles
            in the traffic simulation
        """
        # we tell SUMO to step through dt more seconds of the simulation
        self._cumulative_sim_seconds += dt
        self._traci_conn.simulationStep(self._cumulative_sim_seconds)

        return self._compute_traffic_vehicles(), self._compute_traffic_lights()

    def sync(self, managed_vehicles):
        self._sync_managed_vehicles_with_sumo(managed_vehicles)

        # TODO: This should likely be moved to `step()`
        self._compute_social_vehicle_triggers(managed_vehicles)

    def _sync_managed_vehicles_with_sumo(self, managed_vehicles):
        managed_vehicles_that_have_left_sim = [
            v for v in self._non_sumo_vehicle_ids if v not in managed_vehicles
        ]

        for vehicle_id in managed_vehicles_that_have_left_sim:
            self._log.debug("Non SUMO vehicle %s left simulation", vehicle_id)
            self._non_sumo_vehicle_ids.remove(vehicle_id)
            self._traci_conn.vehicle.remove(vehicle_id)

        managed_vehicles_that_have_just_joined_sim = (
            v for v in managed_vehicles if v not in self._non_sumo_vehicle_ids
        )

        for vehicle_id in managed_vehicles_that_have_just_joined_sim:
            assert type(vehicle_id) == str

            self._log.debug("Non SUMO vehicle %s joined simulation", vehicle_id)
            self._non_sumo_vehicle_ids.add(vehicle_id)
            self._traci_conn.vehicle.add(
                vehID=vehicle_id,
                routeID="",  # we don't care which route this vehicle is on
            )

            # Configure this non-SUMO managed vehicle
            self._traci_conn.vehicle.setColor(
                vehicle_id, (255, 0, 0)
            )  # red in sumo-gui

            # these configuration options helps sumo avoid doing extra work for
            # these managed vehicles
            self._traci_conn.vehicle.setTau(vehicle_id, 0.0)
            self._traci_conn.vehicle.setDecel(
                vehicle_id, 0.0001
            )  # XXX: 0 causes a SUMO assert
            self._traci_conn.vehicle.setApparentDecel(vehicle_id, 0.0)
            self._traci_conn.vehicle.setEmergencyDecel(vehicle_id, 0.0)

        # update the state of all current managed vehicles
        for (vehicle_id, vehicle_state) in managed_vehicles.items():
            pos, smarts_heading = vehicle_state
            assert isinstance(smarts_heading, Heading)
            x, y, _ = pos

            sumo_heading = smarts_heading.as_sumo
            self._traci_conn.vehicle.moveToXY(
                vehID=vehicle_id,
                edgeID="",  # let sumo choose the edge
                lane=-1,  # let sumo choose the lane
                x=x,
                y=y,
                angle=sumo_heading,  # only used for visualizing in sumo-gui
                keepRoute=2,  # gives vehicle freedom to move off road
            )

    def _compute_traffic_vehicles(self):
        sub_results = self._traci_conn.simulation.getSubscriptionResults()

        if sub_results is None:
            return {}

        # New social vehicles that have entered the map
        newly_departed_sumo_traffic = [
            vehicle_id
            for vehicle_id in sub_results[tc.VAR_DEPARTED_VEHICLES_IDS]
            if vehicle_id not in self._non_sumo_vehicle_ids
        ]

        for vehicle_id in newly_departed_sumo_traffic:
            self._log.debug("SUMO vehicle %s entered simulation", vehicle_id)
            self._traci_conn.vehicle.subscribe(
                vehicle_id,
                [
                    tc.VAR_POSITION,
                    tc.VAR_ANGLE,
                    tc.VAR_SPEED,
                    tc.VAR_ROUTE_INDEX,
                    tc.VAR_EDGES,
                    tc.VAR_ROAD_ID,
                    tc.VAR_VEHICLECLASS,
                ],
            )

        # Social vehicles that have left the map
        exited_sumo_traffic = [
            vehicle_id
            for vehicle_id in sub_results[tc.VAR_ARRIVED_VEHICLES_IDS]
            if vehicle_id not in self._non_sumo_vehicle_ids
        ]

        for vehicle_id in exited_sumo_traffic:
            self._log.debug("SUMO vehicle %s left simulation", vehicle_id)

        sumo_vehicle_state = self._traci_conn.vehicle.getAllSubscriptionResults()
        traffic_vehicles = {}
        for sumo_id, sumo_vehicle in sumo_vehicle_state.items():
            position = sumo_vehicle[tc.VAR_POSITION]
            heading = Heading.from_sumo(sumo_vehicle[tc.VAR_ANGLE])
            speed = sumo_vehicle[tc.VAR_SPEED] * 3.6  # m/s -> km/h
            vehicle_type = sumo_vehicle[tc.VAR_VEHICLECLASS]

            traffic_vehicles[sumo_id] = TrafficSimVehicle(
                vehicle_id=sumo_id,
                vehicle_type=vehicle_type,
                position=position,
                heading=heading,
                speed=speed,
            )

        return traffic_vehicles

    def _compute_traffic_lights(self):
        # XXX: TraCI will automatically generate TLS programs if none was
        #      specified according to the net/program. To support this we opt
        #      to use TraCI instead of the sumolib interface for TLS support.
        sub_results = self._traci_conn.trafficlight.getSubscriptionResults(None)

        if not sub_results:
            return {}

        result = defaultdict(list)
        for tls_id in sub_results:
            light_states = sub_results[tls_id][tc.TL_RED_YELLOW_GREEN_STATE]
            links = sub_results[tls_id][tc.TL_CONTROLLED_LINKS]
            assert len(links) == len(
                light_states
            ), "TLS light states must be 1:1 with links"

            for link, state in zip(links, light_states):
                lane_start, lane_end, lane_via = [
                    self._road_network.lane_by_id(lane) for lane in link[0]
                ]
                result[tls_id].append((lane_start, lane_via, lane_end, state))

        return result

    def _compute_social_vehicle_triggers(self, managed_vehicles):
        time_since_last = self._cumulative_sim_seconds - self._last_trigger_time
        if time_since_last < 5:
            return

        trigger_nodes = self._road_network.road_nodes_with_triggers()
        for trigger_node, spawn_nodes in trigger_nodes:
            for _, v_pose in managed_vehicles.items():
                pos, _heading = v_pose
                x, y, _ = pos
                t_x, t_y = trigger_node.getCoord()
                d = math.sqrt((t_x - x) ** 2 + (t_y - y) ** 2)
                if d < 150:
                    self._last_trigger_time = self._cumulative_sim_seconds
                    for s in spawn_nodes:
                        self._emit_vehicle_from_node(s)

    def _unique_route_id(self):
        route_id = "hiway_route_%s" % self._num_dynamic_routes_added
        self._num_dynamic_routes_added += 1
        return route_id

    def _emit_vehicle_from_node(self, node, route=None, lane_index=None):
        """If no route or lane_index are provided, then random ones will be used."""

        if not route:
            route = self._road_network.random_route_starting_at_node(node)

        if not route:
            self._log.warning(
                "Attempting to emit a vehicle without an available route. "
                "Skipping spawning."
            )
            return False

        if not lane_index:
            spawn_edge = self._road_network.graph.getEdge(route[0])
            lane_index = random.randint(0, len(spawn_edge.getLanes()) - 1)

        lane_offset = 0
        return self._emit_vehicle(node.getCoord(), lane_offset, lane_index, route)

    def _emit_vehicle(self, pos, lane_offset, lane_index, route):
        route_id = self._unique_route_id()
        vehicle_id = "sv_started_on_%s" % route_id

        self._traci_conn.route.add(route_id, route)
        self._traci_conn.vehicle.add(
            vehicle_id, route_id, departPos=lane_offset, departLane=lane_index,
        )

        # Force sumo to add vehicles immediately.
        # https://sumo.dlr.de/docs/TraCI/Change_Vehicle_State.html#vehicle_insertion
        self._traci_conn.vehicle.moveToXY(
            vehID=vehicle_id,
            edgeID="",  # let sumo choose the edge
            lane=-1,  # let sumo choose the lane
            x=pos[0],
            y=pos[1],
            angle=tc.INVALID_DOUBLE_VALUE,  # only used for visualizing in sumo-gui; sumo will calculate
            keepRoute=2,  # gives vehicle freedom to move off road
        )

        return True
