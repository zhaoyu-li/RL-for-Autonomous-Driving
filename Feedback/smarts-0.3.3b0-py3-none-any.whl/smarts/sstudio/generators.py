import os
import sys
import random
import logging
import tempfile
from sys import maxsize

import sh

from smarts.core.waypoints import Waypoints
from smarts.core.sumo_road_network import SumoRoadNetwork
from smarts.core.utils.sumo import sumolib
from yattag import Doc, indent

from . import types


class InvalidRoute(Exception):
    """An exception given if a route cannot be successfully plotted."""

    pass


class RandomRouteGenerator:
    """Generates a random route out of the routes available given waypoints and a
    road network.
    """

    def __init__(self, waypoints: Waypoints, road_network: SumoRoadNetwork):
        """
        waypoints: Linked waypoints which are generally subdivisions of a road network's routes
        road_network: A network of routes defined for vehicles of different kinds to travel on.
        """
        self._log = logging.getLogger(self.__class__.__name__)
        self._waypoints = waypoints
        self._road_network = road_network

    @classmethod
    def from_file(cls, net_file: str):
        """Constructs a route generator from the given file

        net_file: the path to a '*.net.xml' file (generally 'map.net.xml')
        """
        road_network = SumoRoadNetwork.from_file(net_file)
        # XXX: Spacing is crudely "large enough" so we less likely overlap vehicles
        waypoints = Waypoints(road_network, spacing=2.0)
        return cls(waypoints, road_network)

    def __iter__(self):
        return self

    def __next__(self):
        """Provides the next random route."""

        def random_lane_index(edge_id):
            lanes = self._road_network.edge_by_id(edge_id).getLanes()
            return random.randint(0, len(lanes) - 1)

        def random_lane_offset(edge_id, lane_idx):
            lane = self._road_network.edge_by_id(edge_id).getLanes()[lane_idx]
            return random.uniform(0, lane.getLength())

        # HACK: loop + continue is a temporary solution so we more likely return a valid
        #       route. In future we need to be able to handle random routes that are just
        #       a single edge long.
        for _ in range(100):
            edges = self._road_network.random_route(max_route_len=10)
            if len(edges) < 2:
                continue

            start_edge_id = edges[0]
            start_lane_index = random_lane_index(start_edge_id)
            start_lane_offset = random_lane_offset(start_edge_id, start_lane_index)

            end_edge_id = edges[-1]
            end_lane_index = random_lane_index(end_edge_id)
            end_lane_offset = random_lane_offset(end_edge_id, end_lane_index)

            return types.Route(
                begin=(start_edge_id, start_lane_index, start_lane_offset),
                intermediaries=tuple(edges[1:-1]),
                end=(end_edge_id, end_lane_index, end_lane_offset),
            )

        raise InvalidRoute(
            "Unable to generate a valid random route that contains \
            at least two edges."
        )


class TrafficGenerator:
    def __init__(self, scenario_dir: str, overwrite: bool = False):
        """
        scenario: The path to the scenario directory
        """
        self._log = logging.getLogger(self.__class__.__name__)
        self._scenario = scenario_dir
        self._overwrite = overwrite
        self._duarouter = sh.Command(sumolib.checkBinary("duarouter"))
        self._road_network_path = os.path.join(self._scenario, "map.net.xml")
        self._random_route_generator = None

    def plan_and_save(
        self, traffic: types.Traffic, name: str, output_dir: str = None, seed: int = 42
    ):
        """Writes a traffic spec to a route file in the given output_dir.

        traffic: The traffic to write out
        name: The name of the traffic resource file
        output_dir: The output directory of the traffic file
        seed: The seed used for deterministic random calls
        """
        random.seed(seed)

        route_path = os.path.join(output_dir, "{}.rou.xml".format(name))
        route_alt_path = os.path.join(output_dir, "{}.rou.alt.xml".format(name))

        if os.path.exists(route_path):
            if self._overwrite:
                self._log.info(
                    f"Routes at routes={route_path} already exist, overwriting"
                )
            else:
                self._log.info(f"Routes at routes={route_path} already exist, skipping")
                return

        with tempfile.TemporaryDirectory() as temp_dir:
            trips_path = os.path.join(temp_dir, "trips.trips.xml")
            self._writexml(traffic, trips_path)

            # Validates, and runs route planner
            self._duarouter(
                net_file=self._road_network_path,
                route_files=trips_path,
                output_file=route_path,
                seed=seed,
                ignore_errors=False,
                no_step_log=True,
            )

            # Remove the rou.alt.xml file
            if os.path.exists(route_alt_path):
                os.remove(route_alt_path)

    def _writexml(self, traffic: types.Traffic, route_path: str):
        """Writes a traffic spec into a route file. Typically this would be the source
        data to Sumo's DUAROUTER.
        """
        doc = Doc()
        doc.asis('<?xml version="1.0" encoding="UTF-8"?>')
        with doc.tag(
            "routes",
            ("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance"),
            ("xsi:noNamespaceSchemaLocation", "http://sumo.sf.net/xsd/routes_file.xsd"),
        ):
            # Actors and routes may be declared once then reused. To prevent creating
            # duplicates we unique them here.
            for actor in {
                actor for flow in traffic.flows for actor in flow.actors.keys()
            }:

                doc.stag(
                    "vType",
                    id=actor.id,
                    accel=actor.accel,
                    decel=actor.decel,
                    vClass=actor.vClass,
                    speedFactor=actor.speed.mean,
                    speedDev=actor.speed.sigma,
                    sigma=actor.imperfection.sample(),
                    minGap=actor.min_gap.sample(),
                    **actor.lane_changing_model,
                    **actor.junction_model,
                )

            # Make sure all routes are "resolved" (e.g. `RandomRoute` are converted to
            # `Route`) so that we can write them all to file.
            resolved_routes = {}
            for route in {flow.route for flow in traffic.flows}:
                resolved_routes[route] = self._resolve_route(route)

            for route in set(resolved_routes.values()):
                doc.stag("route", id=route.id, edges=" ".join(route.edges))

            # We don't de-dup flows since defining the same flow multiple times should
            # create multiple traffic flows. Since IDs can't be reused, we also unique
            # them here.
            for flow in traffic.flows:
                total_weight = sum(flow.actors.values())
                route = resolved_routes[flow.route]
                for idx, (actor, weight) in enumerate(flow.actors.items()):
                    doc.stag(
                        "flow",
                        id="-{}-{}".format(flow.id, idx),
                        type=actor.id,
                        route=route.id,
                        vehsPerHour=flow.rate * (weight / total_weight),
                        departLane=route.begin[1],
                        departPos=route.begin[2],
                        departSpeed="max",
                        arrivalLane=route.end[1],
                        arrivalPos=route.end[2],
                        begin=flow.begin,
                        end=flow.end,
                    )

        with open(route_path, "w") as f:
            f.write(
                indent(
                    doc.getvalue(), indentation="    ", newline="\r\n", indent_text=True
                )
            )

    def _resolve_route(self, route):
        if not isinstance(route, types.RandomRoute):
            return route

        if not self._random_route_generator:
            # Lazy-load to improve performance when not using random route generation.
            self._random_route_generator = RandomRouteGenerator.from_file(
                self._road_network_path
            )

        return next(self._random_route_generator)
