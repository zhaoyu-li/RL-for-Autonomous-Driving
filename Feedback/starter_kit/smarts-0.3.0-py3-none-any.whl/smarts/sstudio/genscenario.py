"""
This script provides a Python interface to generate vehicle route files. Today that
means Python --> *.rou.xml (Sumo).
"""

import os
import logging
from typing import Sequence, Tuple

import sh

from . import types
from .generators import TrafficGenerator, RandomRouteGenerator
from smarts.sstudio.types import Mission, SocialAgentActor


def gen_traffic(
    scenario: str,
    traffic: types.Traffic,
    name: str = None,
    output_dir: str = None,
    seed: int = 42,
):
    """
    Generates the traffic routes for the given scenario. If the output directory is not
    provided, the scenario directory is used. If name is not provided the default is
    "routes".
    """
    assert name != "missions", "The name 'missions' is reserved for missions!"

    output_dir = os.path.join(output_dir or scenario, "traffic")
    os.makedirs(output_dir, exist_ok=True)

    generator = TrafficGenerator(scenario)
    generator.plan_and_save(traffic, name, output_dir, seed=seed)


def gen_social_agent_missions(
    scenario: str,
    social_agent_actor: SocialAgentActor,
    name: str,
    missions: Sequence[Mission] = None,
    output_dir: str = None,
    seed: int = 42,
):
    """
    Generates the social agent missions for the given scenario. If the output directory
    is not provided, the scenario directory is used.
    """

    traffic = types.Traffic(
        flows=[
            types.Flow(
                route=mission.route,
                rate=1,
                begin=0,
                end=1,
                actors={social_agent_actor.as_traffic_actor(): 1.0},
            )
            for mission in missions
        ]
    )

    output_dir = os.path.join(output_dir or scenario, "social_agent")
    os.makedirs(output_dir, exist_ok=True)

    generator = TrafficGenerator(scenario)
    generator.plan_and_save(traffic, name, output_dir, seed=seed)


def gen_missions(
    scenario: str,
    missions: Sequence[types.Mission],
    output_dir: str = None,
    seed: int = 42,
):
    """
    Generates route files to represent missions (a route per mission stored in a
    "missions.rou.xml" file).
    """
    # XXX: We use the `Traffic` type w/ a single `Flow` as a "container" for routes
    #      that missions make use of.
    traffic = types.Traffic(
        flows=[
            types.Flow(
                route=mission.route,
                # a single vehicle
                rate=1,
                begin=0,
                end=1,
                actors={types.TrafficActor(name="car"): 1.0},
            )
            for mission in missions
        ]
    )

    output_dir = output_dir or scenario
    os.makedirs(output_dir, exist_ok=True)

    generator = TrafficGenerator(scenario)
    generator.plan_and_save(traffic, "missions", output_dir, seed=seed)
