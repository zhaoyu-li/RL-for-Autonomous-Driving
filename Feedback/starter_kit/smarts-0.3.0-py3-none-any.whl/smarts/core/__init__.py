import random

import numpy as np


def seed(a):
    random.seed(a)
    np.random.seed(a)
