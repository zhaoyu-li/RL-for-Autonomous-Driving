import random
import psutil
import itertools

import numpy as np
from panda3d.core import (
    NodePath,
    Quat,
    CS_zup_right,
    LineSegs,
    Geom,
    GeomNode,
    GeomPoints,
    GeomVertexData,
    GeomVertexFormat,
    GeomVertexWriter,
)

import pybullet
import pybullet_utils.bullet_client as bc

from .lidar_sensor_params import SensorParams
from .masks import RenderMasks
from .utils import batches


class Lidar:
    def __init__(
        self, origin, sensor_params: SensorParams, bullet_client: bc.BulletClient
    ):
        self._origin = origin
        self._sensor_params = sensor_params
        self._bullet_client = bullet_client
        self._n_threads = psutil.cpu_count(logical=False)

        # As an optimization we compute a set of "base rays" once and shift translate
        # them to follow the user, and then trace for collisions.
        self._base_rays = None
        self._static_lidar_noise = self._compute_static_lidar_noise()

    @property
    def origin(self):
        return self._origin

    @origin.setter
    def origin(self, value):
        self._origin = value

    def _compute_static_lidar_noise(self):
        n_rays = int(
            (self._sensor_params.end_angle - self._sensor_params.start_angle)
            / self._sensor_params.angle_resolution
        )
        n_points = n_rays * len(self._sensor_params.laser_angles)

        static_lidar_noise = []
        for _ in range(n_points):
            static_lidar_noise.append(
                random.gauss(
                    self._sensor_params.noise_mu, self._sensor_params.noise_sigma
                )
            )
        return np.array(static_lidar_noise, dtype=np.float)

    def compute_point_cloud(self):
        rays = self._compute_rays()
        point_cloud, hits = self._trace_rays(rays)
        # point_cloud = self._apply_noise(point_cloud)
        assert (
            len(point_cloud) == len(hits) == len(rays) == len(self._static_lidar_noise)
        )
        return point_cloud, hits, rays

    def _compute_rays(self):
        if self._base_rays is None:
            self._base_rays = []
            n_rays = int(
                (self._sensor_params.end_angle - self._sensor_params.start_angle)
                / self._sensor_params.angle_resolution
            )

            yaws = -np.radians(self._sensor_params.laser_angles)
            rolls = np.radians(np.arange(n_rays) * self._sensor_params.angle_resolution)
            for yaw, roll in itertools.product(yaws, rolls):
                rot = pybullet.getQuaternionFromEuler((roll, 0, yaw))
                origin = np.array([0, 0, 0])
                direction = np.array(
                    Quat(rot).xform((0, self._sensor_params.max_distance, 0))
                )
                self._base_rays.append((origin, direction))

        rays = [
            (origin + self._origin, direction + self._origin)
            for origin, direction in self._base_rays
        ]
        return rays

    def _trace_rays(self, rays):
        results = []
        for batched_rays in batches(
            rays, int(pybullet.MAX_RAY_INTERSECTION_BATCH_SIZE - 1)
        ):
            origins, directions = zip(*batched_rays)
            results.extend(
                self._bullet_client.rayTestBatch(origins, directions, self._n_threads)
            )

        hit_ids, _, _, positions, _ = zip(*results)
        positions = list(positions)
        hits = []
        for i, position in enumerate(positions):
            hit = hit_ids[i] != -1
            hits.append(hit)
            positions[i] = (
                np.array(position) if hit else np.array([np.inf, np.inf, np.inf])
            )
        return positions, hits

    def _apply_noise(self, point_cloud):
        dynamic_noise = np.random.normal(
            self._sensor_params.noise_mu,
            self._sensor_params.noise_sigma,
            size=len(point_cloud),
        )

        local_pc = point_cloud - self._origin
        noise = self._static_lidar_noise + dynamic_noise
        return point_cloud + (
            local_pc
            / np.linalg.norm(local_pc, axis=1)[:, np.newaxis]
            * noise[:, np.newaxis]
        )


class LidarRenderer:
    """A debugging class that renders point cloud output from a `Lidar` instance.
    """

    def __init__(self, parent_np, hits_only=True, draw_rays=False):
        self._parent_np = parent_np
        self._hits_only = hits_only
        self._draw_rays = draw_rays

        self._viz_np = None
        self._clear_viz_np()

    def render(self, point_cloud, hits, rays, reset=True):
        if reset:
            self._clear_viz_np()

        if self._hits_only:
            point_cloud, hits, rays = self._filter_by_hits(point_cloud, hits, rays)

        if self._draw_rays:
            self._draw_ray_lines(point_cloud, hits, rays)

        self._draw_point_cloud(point_cloud, hits, rays)

    def _filter_by_hits(self, point_cloud, hits, rays):
        if not any(hits):
            return [], [], []

        return zip(*[(p, h, r) for (p, h, r) in zip(point_cloud, hits, rays) if h])

    def _draw_ray_lines(self, point_cloud, hits, rays):
        lines = LineSegs()
        lines.setColor(1, 1, 1, 0.1)
        lines.setThickness(0.1)

        for point, hit, ray in zip(point_cloud, hits, rays):
            origin, direction = ray
            lines.moveTo(*origin)
            lines.drawTo(*(point if hit else direction))

        lines_np = NodePath(lines.create())
        lines_np.reparentTo(self._viz_np)

    def _draw_point_cloud(self, point_cloud, hits, rays):
        n_points = len(rays) * 2  # 2x for origin and directions
        vdata = GeomVertexData("point_cloud", GeomVertexFormat.getV3c4(), Geom.UHStatic)
        vdata.setNumRows(n_points)

        vwriter = GeomVertexWriter(vdata, "vertex")
        cwriter = GeomVertexWriter(vdata, "color")

        for point, hit, ray in zip(point_cloud, hits, rays):
            origin, direction = ray
            vwriter.addData3f(*origin)
            cwriter.addData4f(1, 1, 0, 1)

            if hit:
                vwriter.addData3f(*point)
                cwriter.addData4f(0, 1, 0, 1)
            else:
                vwriter.addData3f(*direction)
                cwriter.addData4f(1, 0, 0, 1)

        prim = GeomPoints(Geom.UHStatic)
        for i in range(n_points):
            prim.addVertex(i)
        prim.closePrimitive()

        geom = Geom(vdata)
        geom.addPrimitive(prim)

        node = GeomNode("gnode")
        node.addGeom(geom)

        node_path = self._viz_np.attachNewNode(node)
        node_path.setRenderModeThickness(3)

    def _clear_viz_np(self):
        if self._viz_np is not None:
            self._viz_np.removeNode()

        self._viz_np = self._parent_np.attachNewNode("lidar_render")
