import logging
from typing import Sequence

from panda3d.core import (
    Geom,
    GeomNode,
    GeomPoints,
    GeomTristrips,
    GeomVertexData,
    GeomVertexFormat,
    GeomVertexWriter,
    LineSegs,
    NodePath,
    TransparencyAttrib,
)
from .utils.sumo import sumolib
from sumolib.net.edge import Edge

from .sumo_road_network import SumoRoadNetwork
from .masks import RenderMasks
from .scenario import Goal
from .lidar import LidarRenderer


class Panda3DVizLayer:
    """
    This class provides a visualization layer on top of SMARTS Panda3D showbase view.
    This layer does not get visualized in image-based observations. When running in
    headless mode we should not use this class to conserve compute.

    XXX: When we move over our web-based visualizer, this will be one of the first
         "self-contained" classes to be ported over and removed from SMARTS.
    """

    def __init__(self, root_np: NodePath):
        self._log = logging.getLogger(self.__class__.__name__)
        self._parent_np = root_np
        self._viz_np = self._build_viz_np(self._parent_np)

    @property
    def node_path(self):
        return self._node_path

    def reset_node_path(self):
        if self._viz_np is not None:
            self._viz_np.removeNode()

        self._viz_np = self._build_viz_np(self._parent_np)

    def _build_viz_np(self, root_np: NodePath):
        viz_np = root_np.attachNewNode("viz_layer")
        viz_np.hide(RenderMasks.RGB_HIDE)
        viz_np.hide(RenderMasks.OCCUPANCY_HIDE)
        return viz_np

    def render_path(self, path: Sequence, h_offset=1.0, color=(1.0, 0.0, 1.0, 1.0)):
        if not path:
            return

        lines = LineSegs()
        lines.setColor(*color)
        lines.setThickness(3)
        lines.moveTo(*path[0], h_offset)

        for pos in path[1:]:
            lines.drawTo(*pos, h_offset)
            lines.moveTo(*pos, h_offset)

        waypoint_np = NodePath(lines.create())
        waypoint_np.reparentTo(self._viz_np)

    def render_mission_goal(self, goal: Goal, color=(0.4, 0.6, 0.0, 0.7)):
        vdata = GeomVertexData("end_goal", GeomVertexFormat.getV3c4(), Geom.UHStatic)
        vdata.setNumRows(1)

        vwriter = GeomVertexWriter(vdata, "vertex")
        cwriter = GeomVertexWriter(vdata, "color")

        vwriter.addData3f(*goal.position, 1.01)  # put slightly above waypoint paths
        cwriter.addData4f(*color)

        prim = GeomPoints(Geom.UHStatic)
        prim.addVertex(0)
        prim.closePrimitive()

        geom = Geom(vdata)
        geom.addPrimitive(prim)

        node = GeomNode("end_goal")
        node.addGeom(geom)

        node_path = self._viz_np.attachNewNode(node)
        node_path.setTransparency(TransparencyAttrib.MAlpha)
        node_path.setRenderModeThickness(goal.radius)
        node_path.setRenderModePerspective(True)

    def render_mission_route(self, route: Sequence[Edge], color=(0.4, 0.6, 0.0, 0.4)):
        def p3d_to_sumo_idx(idx, shape_length):
            # Convert from a Panda3D Tristrip index to a sumo shape coordinate index.
            if idx <= 1:
                return idx
            elif idx % 2 == 0:
                return shape_length - idx // 2
            else:
                return idx // 2 + 1

        def shape(edge):
            lane_width = 3
            return SumoRoadNetwork.buffered_lane_or_edge(
                edge, width=len(edge.getLanes()) * lane_width
            )

        vdata = GeomVertexData(
            "mission_route", GeomVertexFormat.getV3c4(), Geom.UHStatic
        )

        shapes = [shape(e) for e in route]

        n_vertices = sum(len(shape) for shape in shapes)
        vdata.setNumRows(n_vertices)

        vwriter = GeomVertexWriter(vdata, "vertex")
        cwriter = GeomVertexWriter(vdata, "color")

        for shape in shapes:
            for i in range(len(shape)):
                idx = p3d_to_sumo_idx(i, len(shape))
                vwriter.addData3f(
                    *shape[idx], 0.99
                )  # put slightly below waypoint paths
                cwriter.addData4f(*color)

        prim = GeomTristrips(Geom.UHStatic)
        prim.addConsecutiveVertices(0, n_vertices)
        prim.closePrimitive()

        geom = Geom(vdata)
        geom.addPrimitive(prim)

        node = GeomNode("mission_route")
        node.addGeom(geom)

        node_path = self._viz_np.attachNewNode(node)
        node_path.setTransparency(TransparencyAttrib.MAlpha)

    def render_lidar(self, point_cloud, hits, rays):
        LidarRenderer(self._viz_np).render(point_cloud, hits, rays, reset=False)

    def render_traffic_lights(self, traffic_lights_state):
        # TODO: We are leaking SUMO lane objects here. SMARTS should not be exposed
        #       to SUMO internals. This API is going to change very soon when we deal
        #       w/ TLS observations next, so we will deal w/ sep. of concerns at that
        #       time.
        for _, _light_states in traffic_lights_state.items():
            for lane_start, lane_via, lane_end, light_state in _light_states:
                color = (0, 0, 0, 0)
                color = dict(
                    G=(0, 1, 0, 0.2),
                    Y=(1, 1, 0, 0.2),
                    R=(1, 0, 0, 0.2),
                    S=(0, 0, 1, 0.2),  # used e.x. for right on red
                ).get(light_state.upper(), color)
                line = LineSegs()
                line.setColor(*color)
                line.setThickness(3)
                line.moveTo(*lane_start.getShape()[-1], 1)
                for pos in lane_via.getShape():
                    line.drawTo(pos[0], pos[1], 1)
                line.drawTo(*lane_end.getShape()[0], 1)
                line_np = NodePath(line.create())
                line_np.setTransparency(TransparencyAttrib.MAlpha)
                line_np.reparentTo(self._viz_np)
