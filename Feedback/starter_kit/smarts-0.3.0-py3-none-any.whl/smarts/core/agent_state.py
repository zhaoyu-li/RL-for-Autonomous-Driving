from .agent_interface import AgentInterface
from .controllers import (
    ActionSpaceType,
    LaneFollowingControllerState,
    ActuatorDynamicControllerState,
)
from .sensors import SensorState


class AgentState:
    def __init__(self, agent_interface: AgentInterface, trainable=True):
        self._agent_interface = agent_interface
        self._trainable = trainable
        self.controller_state = None  # This is exposed for controllers to use.
        self.sensor_state = None  # This is exposed for sensors to use

    def setup(self, sim, agent_id, vehicle):
        waypoint_paths = sim.traffic_sim.waypoints.waypoint_paths_at(
            vehicle.position, lookahead=1
        )
        self.sensor_state = SensorState(
            self.max_episode_steps, starting_wp=waypoint_paths[0][0]
        )

        if self.action_space == ActionSpaceType.Lane:
            target_lane_id = sim.traffic_sim.waypoints.closest_waypoint(
                vehicle.position
            ).lane_id
            self.controller_state = LaneFollowingControllerState(target_lane_id)
        if self.action_space == ActionSpaceType.ActuatorDynamic:
            self.controller_state = ActuatorDynamicControllerState()

    def teardown(self):
        self.sensor_state = None
        self.controller_state = None

    @property
    def max_episode_steps(self):
        return self._agent_interface.max_episode_steps

    @property
    def neighborhood_vehicles_subscribed(self):
        return bool(self._agent_interface.neighborhood_vehicles)

    @property
    def neighborhood_vehicles_subscription(self):
        return self._agent_interface.neighborhood_vehicles

    @property
    def waypoints_subscribed(self):
        return bool(self._agent_interface.waypoints)

    @property
    def waypoints_subscription(self):
        return self._agent_interface.waypoints

    @property
    def ogm_subscribed(self):
        return bool(self._agent_interface.ogm)

    @property
    def ogm_subscription(self):
        return self._agent_interface.ogm

    @property
    def rgb_subscribed(self):
        return bool(self._agent_interface.rgb)

    @property
    def rgb_subscription(self):
        return self._agent_interface.rgb

    @property
    def lidar_subscribed(self):
        return bool(self._agent_interface.lidar)

    @property
    def lidar_subscription(self):
        return self._agent_interface.lidar

    @property
    def action_space(self):
        return self._agent_interface.action_space

    @property
    def debug(self):
        return self._agent_interface.debug

    @property
    def trainable(self):
        return self._trainable
