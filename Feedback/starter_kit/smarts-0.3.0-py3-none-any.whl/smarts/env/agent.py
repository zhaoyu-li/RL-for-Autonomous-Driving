from dataclasses import dataclass
from typing import Callable
from multiprocessing import Process, Queue

import gym
import ray

from smarts.core.agent_interface import AgentInterface


class AgentPolicy:
    def setup(self):
        pass

    def teardown(self):
        pass

    def act(self, obs):
        raise NotImplementedError


def default_obs_adapter(obs):
    return obs


def default_reward_adapter(obs, reward):
    return reward


def default_action_adapter(action):
    return action


@dataclass
class Agent:
    interface: AgentInterface
    policy: AgentPolicy = None
    observation_space: gym.Space = None
    action_space: gym.Space = None
    observation_adapter: Callable = default_obs_adapter
    reward_adapter: Callable = default_reward_adapter
    action_adapter: Callable = default_action_adapter

    def reset(self):
        self.teardown()
        self.setup()

    def setup(self):
        if self.policy:
            self.policy.setup()

    def teardown(self):
        if self.policy:
            self.policy.teardown()

    def act(self, env_observation):
        observation = self.observation_adapter(env_observation)
        policy_action = self.policy.act(observation)
        action = self.action_adapter(policy_action)
        return action


class AsyncAgent:
    def __init__(self, agent: Agent):
        self._agent = agent
        self._agent_proc = None

    def send_reset(self):
        self._input_queue.put({"type": "control", "payload": "reset"})

    def send_observation(self, obs):
        self._input_queue.put({"type": "obs", "payload": obs})

    def recv_action(self, timeout=None):
        return self._action_queue.get(timeout=timeout)

    def start(self):
        if self._agent_proc:
            return

        self._input_queue = Queue()
        self._action_queue = Queue()

        def agent_event_loop():
            self._agent.setup()
            while True:
                msg = self._input_queue.get()
                if msg["type"] == "control" and msg["payload"] == "reset":
                    self._agent.reset()
                elif msg["type"] == "obs":
                    obs = msg["payload"]
                    action = self._agent.act(obs)
                    self._action_queue.put(action)
                else:
                    raise NotImplementedError(f'AsyncAgent doesn\'t understand "{msg}"')

        self._agent_proc = Process(target=agent_event_loop)
        self._agent_proc.daemon = True
        self._agent_proc.start()

    def terminate(self):
        if self._agent_proc:
            self._agent_proc.terminate()
            self._agent_proc = None


@ray.remote
class RemoteAgent:
    def __init__(self, agent: Agent):
        self._agent = agent

    def setup(self):
        self._agent.setup()

    def act(self, obs):
        return self._agent.act(obs)
