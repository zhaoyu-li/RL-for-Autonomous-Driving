import math

import numpy as np

from smarts.core.vehicle import Vehicle
from smarts.core.utils.math import vec_2d


def ttc_by_path(ego, waypoint_paths, neighborhood_vehicle_states):
    # first sum up the distance between waypoints along a path
    # ie. [(wp1, path1, 0),
    #      (wp2, path1, 0 + dist(wp1, wp2)),
    #      (wp3, path1, 0 + dist(wp1, wp2) + dist(wp2, wp3))]

    wps_with_lane_dist = []
    for path_idx, path in enumerate(waypoint_paths):
        lane_dist = 0.0
        for w1, w2 in zip(path, path[1:]):
            wps_with_lane_dist.append((w1, path_idx, lane_dist))
            lane_dist += np.linalg.norm(w2.pos - w1.pos)
        wps_with_lane_dist.append((path[-1], path_idx, lane_dist))

    # next we compute the TTC along each of the paths
    ttc_by_path_index = [1000] * len(waypoint_paths)
    lane_dist_by_path_index = [1] * len(waypoint_paths)

    for v in neighborhood_vehicle_states:
        # find all waypoints that are on the same lane as this vehicle
        wps_on_lane = [
            (wp, path_idx, dist)
            for wp, path_idx, dist in wps_with_lane_dist
            if wp.lane_id == v.lane_id
        ]

        if not wps_on_lane:
            # this vehicle is not on a nearby lane
            continue

        # find the closest waypoint on this lane to this vehicle
        nearest_wp, path_idx, lane_dist = min(
            wps_on_lane, key=lambda tup: np.linalg.norm(tup[0].pos - vec_2d(v.position))
        )

        if np.linalg.norm(nearest_wp.pos - vec_2d(v.position)) > 2:
            # this vehicle is not close enough to the path, this can happen
            # if the vehicle is behind the ego, or ahead past the end of
            # the waypoints
            continue

        relative_speed_m_per_s = (ego.speed - v.speed) * 1000 / 3600
        if abs(relative_speed_m_per_s) < 1e-5:
            relative_speed_m_per_s = 1e-5

        ttc = lane_dist / relative_speed_m_per_s
        ttc /= 10
        if ttc <= 0:
            # discard collisions that would have happened in the past
            continue

        lane_dist /= 100
        lane_dist_by_path_index[path_idx] = min(
            lane_dist_by_path_index[path_idx], lane_dist
        )
        ttc_by_path_index[path_idx] = min(ttc_by_path_index[path_idx], ttc)

    return ttc_by_path_index, lane_dist_by_path_index


def ttc_grid(
    smarts, agent_id: str, ego: Vehicle, time_quantization: float, time_horizon: float,
) -> np.ndarray:
    """
    Compute time to collide assuming vehicles don't change lanes or velocities
    e.g. if the ego is in the right most lane on a 3 lane road with settings:
        time_quantization=1 (second)
        time_horizon=7 (seconds)
    we receive:
        [[0, 0, 0, 0, 1, 0, 0],
         [0, 0, 0, 0, 0, 0, 0],
         [0, 0, 0, 0, 0, 0, 0]]
    which tells us a collision is predicted in 5 seconds
    """

    road_network = smarts.traffic_sim.road_network
    x, y, _ = ego.position
    ego_lane = road_network.nearest_lane((x, y), radius=1)

    if ego_lane is None:
        # ego is off road
        return None

    ego_offset = road_network.offset_into_lane(ego_lane, (x, y))

    social_vehicles = smarts.neighborhood_vehicles_around_agent(agent_id)

    ego_lane_idx = [
        lane_idx
        for lane_idx, lane in enumerate(ego_lane.getEdge().getLanes())
        if lane == ego_lane
    ][0]

    number_of_lanes_on_edge = ego_lane.getEdge().getLaneNumber()
    look_ahead = int(time_horizon / time_quantization)
    grid = np.zeros((number_of_lanes_on_edge, look_ahead), dtype=np.uint8)
    for social_vehicle in social_vehicles:
        sv_x, sv_y, _ = social_vehicle.position
        sv_lane = road_network.nearest_lane((sv_x, sv_y), radius=1)

        if sv_lane is None:
            continue  # this vehicle is off road

        if sv_lane.getID() != ego_lane.getID():
            continue  # this vehicle is not on the same lane

        rel_speed_kmh = social_vehicle.speed - ego.speed
        rel_speed_meters_per_second = rel_speed_kmh * (1000 / (60 * 60))

        sv_offset = road_network.offset_into_lane(sv_lane, (sv_x, sv_y))
        distance_between_vehicles_meters = ego_offset - sv_offset

        if math.isclose(abs(rel_speed_meters_per_second), 0.0):
            # these vehicles are moving at the same speed
            # no collision possible
            continue

        ttc = distance_between_vehicles_meters / rel_speed_meters_per_second
        if ttc > 0 and ttc < time_horizon:
            ttc_quantized = int(ttc / time_quantization)
            grid[ego_lane_idx, ttc_quantized] = 1
        else:
            # either collision is predicted to have happened in the past
            # or the collision is beyond our time horizon
            pass

    return grid
