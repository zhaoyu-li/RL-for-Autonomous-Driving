import gym
import pytest

from smarts.core.agent_interface import AgentInterface, AgentType
from smarts.core.controllers import ActionSpaceType

from smarts.env.agent import Agent


@pytest.fixture(params=[1, 10])
def agent_ids(request):
    return ["AGENT-{}".format(i) for i in range(request.param)]


@pytest.fixture(params=["laner", "rgb", "lidar"])
def agent_interface(request):
    if request.param == "laner":
        return AgentInterface.from_type(AgentType.Laner)
    if request.param == "rgb":
        return AgentInterface(rgb=True, action=ActionSpaceType.Lane)
    if request.param == "lidar":
        return AgentInterface(lidar=True, action=ActionSpaceType.Lane)


@pytest.fixture
def agents(agent_ids, agent_interface):
    return {id_: Agent(interface=agent_interface) for id_ in agent_ids}


@pytest.fixture
def env(agents):
    env = gym.make(
        "smarts.env:hiway-v0",
        # TODO: Switch to a test scenario that has routes, and missions
        scenarios=["scenarios/loop"],
        agents=agents,
        headless=True,
        seed=2008,
        timestep_sec=0.01,
    )
    yield env
    env.close()


@pytest.mark.benchmark(group="env.step")
def test_benchmark_step(agent_ids, env, benchmark):
    env.reset()
    benchmark(env.step, {id_: "keep_lane" for id_ in agent_ids})
