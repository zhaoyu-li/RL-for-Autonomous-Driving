import json
import multiprocessing
import threading
from collections import defaultdict

import numpy as np

try:
    import visdom
except ImportError:
    raise ImportError("Visdom is required for visualizations.")


def build_visdom_watcher_queue():
    # Set queue size to 1 so that we don't hang on too old observations
    obs_queue = multiprocessing.Queue(1)

    queue_watcher = threading.Thread(
        target=_watcher_loop,
        args=(obs_queue,),
        daemon=True,  # If False, the proc will not terminate until this thread stops
    )

    queue_watcher.start()

    return obs_queue


def _watcher_loop(obs_queue):
    def _vis_sim_obs(sim_obs):
        vis_images = defaultdict(list)
        for agent_id, agent_obs in sim_obs.agent_observations.items():
            if agent_obs is None:
                continue

            ogm = getattr(agent_obs, "occupancy_grid_map", None)
            if ogm is not None:
                image = ogm.data
                image = image.reshape(image.shape[0], image.shape[1])
                image = np.expand_dims(image, axis=0)
                image = (image.astype(np.float32) / 100) * 255
                vis_images[f"{agent_id}-OGM"].append(image)

            image = getattr(agent_obs, "top_down_rgb", None)
            if image is not None:
                image = image.transpose(2, 0, 1)
                image = image.astype(np.float32)
                vis_images[f"{agent_id}-Top-Down RGB"].append(image)

        return vis_images

    vis = visdom.Visdom()

    while True:
        obs = obs_queue.get()

        for key, images in _vis_sim_obs(obs).items():
            title = json.dumps({"Type:": key})
            # images = np.stack(images, axis=0)
            # vis.images(images, win=key, opts={'title': title})
            vis.images(images[0], win=key, opts={"title": title})
