from . import centralized_a2c

MA_POLICIES = {"centralized_a2c": centralized_a2c}
