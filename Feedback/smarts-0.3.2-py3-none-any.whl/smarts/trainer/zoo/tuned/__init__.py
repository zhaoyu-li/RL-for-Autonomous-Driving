from smarts.trainer.zoo.tuned import simple_space, tuned_space

SPACES = {"simple": simple_space, "tuned": tuned_space}
