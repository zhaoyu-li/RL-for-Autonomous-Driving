"""
this file contain default network for rllib training,
and can be used for policy evaluation
"""
import pickle

from ray.rllib.models import ModelCatalog
from ray.rllib.models.tf.fcnet_v2 import FullyConnectedNetwork
from ray.rllib.utils import try_import_tf

from smarts.env.agent import AgentPolicy

tf = try_import_tf()


# actually, i think here define Model is useless since that the RLlib use fcnet_v2 as default
# #See: https://github.com/ray-project/ray/blob/b89cac976ae171d6d9b3245394e4932288fc6f11/rllib/models/tf/fcnet_v2.py#L14
class Model(FullyConnectedNetwork):
    NAME = "model"


ModelCatalog.register_custom_model(Model.NAME, Model)


class RLLibTFCheckpointPolicy(AgentPolicy):
    def __init__(
        self, load_path, algorithm, policy_name, observation_space, action_space
    ):
        self._load_path = load_path
        self._algorithm = algorithm
        self._policy_name = policy_name
        self._observation_space = observation_space
        self._action_space = action_space
        self._sess = None

    def setup(self):
        if self._sess:
            return

        if self._algorithm == "PPO":
            from ray.rllib.agents.ppo.ppo_tf_policy import PPOTFPolicy as LoadPolicy
        elif self._algorithm in ["A2C", "A3C"]:
            from ray.rllib.agents.a3c.a3c_tf_policy import A3CTFPolicy as LoadPolicy
        elif self._algorithm == "PG":
            from ray.rllib.agents.pg.pg_tf_policy import PGTFPolicy as LoadPolicy
        elif self._algorithm == "DQN":
            from ray.rllib.agents.dqn.dqn_policy import DQNTFPolicy as LoadPolicy
        else:
            raise TypeError("Unsupport algorithm")

        self._prep = ModelCatalog.get_preprocessor_for_space(self._observation_space)
        self._sess = tf.Session(graph=tf.Graph())
        self._sess.__enter__()

        with tf.name_scope(self._policy_name):
            # obs_space need to be flattened before passed to PPOTFPolicy
            flat_obs_space = self._prep.observation_space
            policy = LoadPolicy(flat_obs_space, self._action_space, {})
            objs = pickle.load(open(self._load_path, "rb"))
            objs = pickle.loads(objs["worker"])
            state = objs["state"]
            weights = state[self._policy_name]
            policy.set_weights(weights)

        graph = self._sess.graph
        # These tensor names were found by inspecting the trained model
        # We use Tensor("split") instead of Tensor("add") to force PPO to be deterministic, CRUCIAL FOR SAFETY
        if self._algorithm == "PPO":
            self._input_node = graph.get_tensor_by_name(
                self._policy_name + "/observation:0"
            )
            self._output_node = graph.get_tensor_by_name(self._policy_name + "/split:0")
        # todo: need to check
        elif self._algorithm == "DQN":
            self._input_node = graph.get_tensor_by_name(
                self._policy_name + "/observations:0"
            )
            self._output_node = tf.argmax(
                graph.get_tensor_by_name(self._policy_name + "/value_out/BiasAdd:0"),
                axis=1,
            )
        else:
            self._input_node = graph.get_tensor_by_name(
                self._policy_name + "/observations:0"
            )
            self._output_node = tf.argmax(
                graph.get_tensor_by_name(self._policy_name + "/fc_out/BiasAdd:0"),
                axis=1,
            )

    def teardown(self):
        # TODO: actually teardown the TF session
        pass

    def act(self, obs):
        obs = self._prep.transform(obs)
        res = self._sess.run(self._output_node, feed_dict={self._input_node: [obs]})
        action = res[0]
        return action


class RLLibTFSavedModelPolicy(AgentPolicy):
    def __init__(self, load_path, algorithm, policy_name, observation_space):
        self._load_path = load_path
        self._algorithm = algorithm
        self._policy_name = policy_name
        self._prep = ModelCatalog.get_preprocessor_for_space(observation_space)
        self._sess = None

    def setup(self):
        if self._sess:
            return

        self._sess = tf.Session(graph=tf.Graph())
        tf.saved_model.load(
            self._sess, export_dir=self._load_path, tags=["serve"], clear_devices=True,
        )
        graph = self._sess.graph
        # These tensor names were found by inspecting the trained model
        # We use Tensor("split") instead of Tensor("add") to force PPO to be deterministic, CRUCIAL FOR SAFETY
        if self._algorithm == "PPO":
            self._input_node = graph.get_tensor_by_name(
                self._policy_name + "/observation:0"
            )
            self._output_node = graph.get_tensor_by_name(self._policy_name + "/split:0")
        # todo: need to check
        elif self._algorithm == "DQN":
            self._input_node = graph.get_tensor_by_name(
                self._policy_name + "/observations:0"
            )
            self._output_node = tf.argmax(
                graph.get_tensor_by_name(self._policy_name + "/value_out/BiasAdd:0"),
                axis=1,
            )
        else:
            self._input_node = graph.get_tensor_by_name(
                self._policy_name + "/observations:0"
            )
            self._output_node = tf.argmax(
                graph.get_tensor_by_name(self._policy_name + "/fc_out/BiasAdd:0"),
                axis=1,
            )

    def act(self, obs):
        # XXX: We will vectorize across agents in the future, just the rest of the platform
        #      Needs to catch up first.
        obs = self._prep.transform(obs)
        res = self._sess.run(self._output_node, feed_dict={self._input_node: [obs]})
        action = res[0]
        return action


# this class is for evaluation used.
class BatchRLLibTFCheckpointPolicy(AgentPolicy):
    def __init__(
        self, load_path, algorithm, policy_name, observation_space, action_space
    ):
        self._load_path = load_path
        self._algorithm = algorithm
        self._policy_name = policy_name
        self._observation_space = observation_space
        self._action_space = action_space
        self._sess = None

    def setup(self):
        if self._sess:
            return

        if self._algorithm == "PPO":
            from ray.rllib.agents.ppo.ppo_tf_policy import PPOTFPolicy as LoadPolicy
        elif self._algorithm in ["A2C", "A3C"]:
            from ray.rllib.agents.a3c.a3c_tf_policy import A3CTFPolicy as LoadPolicy
        elif self._algorithm == "PG":
            from ray.rllib.agents.pg.pg_tf_policy import PGTFPolicy as LoadPolicy
        elif self._algorithm == "DQN":
            from ray.rllib.agents.dqn.dqn_policy import DQNTFPolicy as LoadPolicy
        else:
            raise TypeError("Unsupport algorithm")

        self._prep = ModelCatalog.get_preprocessor_for_space(self._observation_space)
        self._sess = tf.Session(graph=tf.Graph())
        self._sess.__enter__()

        with tf.name_scope(self._policy_name):
            # obs_space need to be flattened before passed to PPOTFPolicy
            flat_obs_space = self._prep.observation_space
            policy = LoadPolicy(flat_obs_space, self._action_space, {})
            objs = pickle.load(open(self._load_path, "rb"))
            objs = pickle.loads(objs["worker"])
            state = objs["state"]
            weights = state[self._policy_name]
            policy.set_weights(weights)

        graph = self._sess.graph
        # These tensor names were found by inspecting the trained model
        # We use Tensor("split") instead of Tensor("add") to force PPO to be deterministic, CRUCIAL FOR SAFETY
        if self._algorithm == "PPO":
            self._input_node = graph.get_tensor_by_name(
                self._policy_name + "/observation:0"
            )
            self._output_node = graph.get_tensor_by_name(self._policy_name + "/split:0")
        # todo: need to check
        elif self._algorithm == "DQN":
            self._input_node = graph.get_tensor_by_name(
                self._policy_name + "/observations:0"
            )
            self._output_node = tf.argmax(
                graph.get_tensor_by_name(self._policy_name + "/value_out/BiasAdd:0"),
                axis=1,
            )
        else:
            self._input_node = graph.get_tensor_by_name(
                self._policy_name + "/observations:0"
            )
            self._output_node = tf.argmax(
                graph.get_tensor_by_name(self._policy_name + "/fc_out/BiasAdd:0"),
                axis=1,
            )

    def teardown(self):
        # TODO: actually teardown the TF session
        pass

    def act(self, obs):
        agent_id = list(obs.keys())
        obs = list(obs.values())
        obs = [self._prep.transform(o) for o in obs]
        res = self._sess.run(self._output_node, feed_dict={self._input_node: obs})
        actions = res
        actions = dict(zip(agent_id, actions))
        return actions


# this class is for evaluation used.
class BatchRLLibTFSavedModelPolicy(AgentPolicy):
    def __init__(self, load_path, algorithm, policy_name, observation_space):
        self._load_path = load_path
        self._algorithm = algorithm
        self._policy_name = policy_name
        self._prep = ModelCatalog.get_preprocessor_for_space(observation_space)
        self._sess = None

    def setup(self):
        if self._sess:
            return

        self._sess = tf.Session(graph=tf.Graph())
        tf.saved_model.load(
            self._sess, export_dir=self._load_path, tags=["serve"], clear_devices=True,
        )
        graph = self._sess.graph
        # These tensor names were found by inspecting the trained model
        # We use Tensor("split") instead of Tensor("add") to force PPO to be deterministic, CRUCIAL FOR SAFETY
        if self._algorithm == "PPO":
            self._input_node = graph.get_tensor_by_name(
                self._policy_name + "/observation:0"
            )
            self._output_node = graph.get_tensor_by_name(self._policy_name + "/split:0")
        # todo: need to check
        elif self._algorithm == "DQN":
            self._input_node = graph.get_tensor_by_name(
                self._policy_name + "/observations:0"
            )
            self._output_node = tf.argmax(
                graph.get_tensor_by_name(self._policy_name + "/value_out/BiasAdd:0"),
                axis=1,
            )
        else:
            self._input_node = graph.get_tensor_by_name(
                self._policy_name + "/observations:0"
            )
            self._output_node = tf.argmax(
                graph.get_tensor_by_name(self._policy_name + "/fc_out/BiasAdd:0"),
                axis=1,
            )

    def act(self, obs):
        agent_id = list(obs.keys())
        obs = [self._prep.transform(o) for o in obs.values()]
        res = self._sess.run(self._output_node, feed_dict={self._input_node: obs})
        actions = res
        actions = dict(zip(agent_id, actions))
        return actions
