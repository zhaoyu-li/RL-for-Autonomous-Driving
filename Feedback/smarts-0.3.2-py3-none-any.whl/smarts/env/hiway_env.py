import logging
from typing import Sequence

import gym

import smarts
from smarts.core.smarts import SMARTS
from smarts.core.sumo_traffic_simulation import SumoTrafficSimulation
from smarts.core.scenario import Scenario
from smarts.core.agent_interface import AgentInterface, AgentType
from smarts.zoo.registry import make as make_social_agent

from .visualization import build_visdom_watcher_queue
from .agent import AsyncAgent


class HiWayEnv(gym.Env):
    metadata = {"render.modes": ["human"]}

    def __init__(
        self,
        scenarios: Sequence[str],
        agents,
        visdom=False,
        headless=True,  # This is to toggle Panda3D's visualization
        envision=True,  # This is to toggle our envision visualization
        timestep_sec=0.1,
        seed=42,
    ):
        self._log = logging.getLogger(self.__class__.__name__)
        smarts.core.seed(seed)

        self._visdom_obs_queue = None
        if visdom:
            self._log.info("Running with visdom")
            self._visdom_obs_queue = build_visdom_watcher_queue()

        social_agent_infos = Scenario.discover_social_agents(scenarios[0])
        social_agents = {
            agent_id: make_social_agent(
                locator=missions_and_locator[1],
                ## Overload the prefab here
            )
            for d in social_agent_infos
            for agent_id, missions_and_locator in d.items()
        }

        # social agents
        self._async_social_agents = {
            agent_id: AsyncAgent(social_agent)
            for agent_id, social_agent in social_agents.items()
        }

        for async_social_agent in self._async_social_agents.values():
            async_social_agent.start()

        self._scenarios_iterator = Scenario.scenario_variations(
            scenarios, list(agents.keys()),
        )

        agent_interfaces = {
            agent_id: agent.interface for agent_id, agent in agents.items()
        }

        social_agent_interfaces = {
            agent_id: agent.interface for agent_id, agent in social_agents.items()
        }

        self._smarts = SMARTS(
            agent_interfaces=agent_interfaces,
            social_agent_interfaces=social_agent_interfaces,
            traffic_sim=SumoTrafficSimulation(
                headless=True, time_resolution=timestep_sec
            ),
            headless=headless,
            envision=envision,
            timestep_sec=timestep_sec,
        )

    @property
    def scenario(self):
        return self._smarts.scenario

    @property
    def timestep_sec(self):
        return self._smarts.timestep_sec

    def step(self, agent_actions):
        social_agent_actions = {
            agent_id: async_agent.recv_action(timeout=5)
            for agent_id, async_agent in self._async_social_agents.items()
        }
        all_agent_actions = {**agent_actions, **social_agent_actions}

        observation, reward, _, agent_dones = self._smarts.step(all_agent_actions)

        for agent_id, async_agent in self._async_social_agents.items():
            obs = observation.agent_observations[agent_id]
            async_agent.send_observation(obs)

        self._remove_social_agents_from_env_output(observation.agent_observations)
        self._remove_social_agents_from_env_output(reward.agent_rewards)
        self._remove_social_agents_from_env_output(agent_dones)

        # Important to teardown done agents after we've filtered out the
        # social agents from dones. We do not want to teardown social agents
        # because we are prioritizing simulation cohesion over social agent
        # behaviour stability.
        self._teardown_done_agent_vehicles(agent_dones)

        self._try_emit_visdom_obs(observation)

        agent_dones["__all__"] = all(agent_dones[agent_id] for agent_id in agent_dones)
        return observation, reward, agent_dones, {}

    def reset(self):
        scenario = next(self._scenarios_iterator)
        observation = self._smarts.reset(scenario)

        for agent_id, async_agent in self._async_social_agents.items():
            async_agent.send_reset()

            obs = observation.agent_observations[agent_id]
            async_agent.send_observation(obs)

        self._remove_social_agents_from_env_output(observation.agent_observations)

        self._try_emit_visdom_obs(observation)
        return observation

    def render(self, mode="human"):
        pass

    def close(self):
        if self._smarts is not None:
            self._smarts.destroy()

        for async_agent in self._async_social_agents.values():
            async_agent.terminate()

    def _remove_social_agents_from_env_output(self, output):
        # TODO: we need a more robust way of making sure social agents don't leak out of the env
        for social_agent_id in self._async_social_agents:
            del output[social_agent_id]

    def _teardown_done_agent_vehicles(self, agent_dones):
        for agent_id, is_done in agent_dones.items():
            if is_done:
                self._smarts.teardown_agent_vehicle(agent_id)

    def _try_emit_visdom_obs(self, obs):
        try:
            if self._visdom_obs_queue:
                self._visdom_obs_queue.put(obs, block=False)
        except Exception:
            self._log.debug("Dropped visdom frame instead of blocking")
