import gym
import pytest
import logging

from smarts.core.utils.episodes import episodes
from smarts.core.agent_interface import AgentInterface, AgentType
from smarts.core.units import Heading
from smarts.core.scenario import Start, Mission, EndlessGoal, Goal, PositionalGoal
from smarts.env.agent import Agent, AgentPolicy

AGENT_ID = "Agent-007"
SOCIAL_AGENT_ID = "Alec Trevelyan"

MAX_EPISODES = 3


@pytest.fixture
def env():
    class Policy(AgentPolicy):
        def act(self, obs):
            return "keep_lane"

    env = gym.make(
        "smarts.env:hiway-v0",
        scenarios=["scenarios/zoo_intersection"],
        agents={
            AGENT_ID: Agent(
                interface=AgentInterface.from_type(
                    AgentType.Laner, max_episode_steps=100
                )
            )
        },
        headless=True,
        visdom=False,
        timestep_sec=0.01,
    )

    yield env
    env.close()


def test_social_agents(env):
    for episode in episodes(env, n=MAX_EPISODES):
        observations = env.reset()

        dones = {"__all__": False}
        while not dones["__all__"]:
            _ = observations.agent_observations[AGENT_ID]
            observations, rewards, dones, _ = env.step({AGENT_ID: "keep_lane",},)

            assert SOCIAL_AGENT_ID not in observations.agent_observations
            assert SOCIAL_AGENT_ID not in dones

            # reward is currently the delta in distance travelled by this agent.
            # We want to make sure that this is infact a delta and not total distance
            # travelled since this bug has appeared a few times.
            #
            # The way to verify this is by making sure the reward does not grow without bounds
            assert -3 < rewards.agent_rewards[AGENT_ID] < 3
            episode.record_iteration()

    assert episode.index == (
        MAX_EPISODES - 1
    ), "Simulation must cycle through to the final episode"
