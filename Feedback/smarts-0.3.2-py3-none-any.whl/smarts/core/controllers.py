from enum import Enum
import math
import numpy as np

from .vehicle import Vehicle
from .utils.math import lerp


class ActionSpaceType(Enum):
    Continuous = 0
    Lane = 1
    ActuatorDynamic = 2


class Controllers:
    @staticmethod
    def perform_action(sim, agent_id, agent_state, vehicle: Vehicle, action):
        if agent_state.action_space == ActionSpaceType.Continuous:
            vehicle.activate(
                throttle=np.clip(action[0], 0.0, 1.0),
                brake=np.clip(action[1], 0.0, 1.0),
                steering=np.clip(action[2], -1, 1),
            )
        elif agent_state.action_space == ActionSpaceType.ActuatorDynamic:
            ActuatorDynamicController.perform_action(
                vehicle, action, agent_state.controller_state, dt_sec=sim.timestep_sec
            )
        elif agent_state.action_space == ActionSpaceType.Lane:
            if action == "keep_lane":
                LaneFollowingController.perform_lane_following(
                    sim, agent_id, vehicle, agent_state.controller_state
                )

            elif action == "slow_down":
                LaneFollowingController.perform_lane_following(
                    sim, agent_id, vehicle, agent_state.controller_state
                )
                vehicle.activate(throttle=0, brake=0.3)

            elif action == "change_lane_left":
                LaneFollowingController.change_lane(
                    sim, agent_id, vehicle, agent_state.controller_state, -1
                )
                LaneFollowingController.perform_lane_following(
                    sim, agent_id, vehicle, agent_state.controller_state
                )

            elif action == "change_lane_right":
                LaneFollowingController.change_lane(
                    sim, agent_id, vehicle, agent_state.controller_state, 1
                )
                LaneFollowingController.perform_lane_following(
                    sim, agent_id, vehicle, agent_state.controller_state
                )
            else:
                raise Exception("Invalid action %s" % action)


class ActuatorDynamicControllerState:
    def __init__(self):
        self.last_steering_angle = 0


class ActuatorDynamicController:
    @staticmethod
    def perform_action(vehicle: Vehicle, action, state, dt_sec):
        max_steer_rate = 1.0  # TODO(Iman): can we find a better value here

        throttle, brake, steering_rate_degrees_per_second = action

        clipped_steering_rate_degrees_per_second = np.clip(
            steering_rate_degrees_per_second, -max_steer_rate, max_steer_rate
        )

        p = 0.001  # XXX: Theorized to improve stability, this has yet to be seen.
        steering = np.clip(
            (1 - p) * state.last_steering_angle
            + clipped_steering_rate_degrees_per_second * dt_sec,
            -1,
            1,
        )

        vehicle.activate(
            throttle=np.clip(throttle, 0.0, 1.0),
            brake=np.clip(brake, 0.0, 1.0),
            steering=steering,
        )

        state.last_steering_angle = steering


class LaneFollowingControllerState:
    # TODO: Consider making this immutable and making `LaneFollowingController`
    #       generate new state object.
    def __init__(self, target_lane_id):
        self.target_lane_id = target_lane_id
        self.throttle_ewma = 0.0
        self.steer_magnitude_ewma = 0.0


class LaneFollowingController:
    @staticmethod
    def change_lane(sim, agent_id, vehicle, state, lane_change_direction):
        paths = sim.mission_planner(agent_id).waypoint_paths_at(
            vehicle.position, lookahead=1
        )

        target_wp = None
        target_lateral_error = None
        for path in paths:
            wp = path[0]
            if wp.lane_id == state.target_lane_id:
                # we are intending to _switch_ lane, don't consider current lane
                continue

            lateral_error = wp.signed_lateral_error(vehicle.position)
            lateral_error *= lane_change_direction

            if lateral_error < 0:
                # this wp is not in the direction we want to change lane towards
                continue

            if target_lateral_error is None or lateral_error < target_lateral_error:
                target_wp = wp
                target_lateral_error = lateral_error

        if target_wp:
            state.target_lane_id = target_wp.lane_id

    @staticmethod
    def perform_lane_following(sim, agent_id, vehicle, state):
        # This lookahead value is coupled with a few calculations below, changing it
        # may affect stability of the controller.
        wp_paths = sim.mission_planner(agent_id).waypoint_paths_on_lane_at(
            vehicle.position, state.target_lane_id, lookahead=30
        )
        wp_path = wp_paths[0]

        steer_angle = LaneFollowingController._compute_steering_correction(
            sim, vehicle, wp_path
        )

        # We track how much we've been steering recently in this EWMA. Used to
        # slow down the car when we are swerving a bunch
        state.steer_magnitude_ewma = lerp(
            state.steer_magnitude_ewma, abs(steer_angle), 0.1,
        )

        # we compute a road "curviness" to inform our throttle activation.
        # We should move slowly when we are on curvy roads.
        ewma_road_curviness = 0.0
        for wp_a, wp_b in reversed(list(zip(wp_path, wp_path[1:]))):
            ewma_road_curviness = lerp(
                ewma_road_curviness, abs(wp_a.relative_heading(wp_b.heading)), 0.03,
            )

        road_curviness_normalization = 2.5
        road_curviness = np.clip(
            ewma_road_curviness / road_curviness_normalization, 0, 1
        )

        throttle_activation = 0
        brake_activation = 0
        speedcontroller = (
            0.4
            - 0.025 * (vehicle.speed - 55)
            - 0.3 * (1.0 - np.absolute(state.steer_magnitude_ewma))
            - 0.6 * road_curviness
        )
        if speedcontroller > 0:
            throttle_activation = (
                np.clip(
                    speedcontroller, 0, 1
                )  # max throttle we can maintain reliably control over vehicle
                # slow down when turning a lot
            )
        else:
            brake_activation = (
                np.clip(
                    -speedcontroller, 0, 1
                )  # max throttle we can maintain reliably control over vehicle
                # slow down when turning a lot
            )

        # To avoid jerky stop and go movements, we smooth the throttle activation with an ewma
        state.throttle_ewma = lerp(state.throttle_ewma, throttle_activation, 0.05)

        # Lateral changes are more impactful at high speeds. To account for this,
        # we want to scale down our steering when moving at high speeds.

        # TODO: We may not need to normalize the vehicle speed against it's max
        #       speed since the relationship between steering and speed grows
        #       independant of the max speed. There may be a better value we can
        #       normalize against here.
        normalized_speed = vehicle.speed / vehicle.approx_max_speed
        steer_angle_adjusted_for_speed = steer_angle * (1.0 - normalized_speed) ** 2.0
        vehicle.activate(
            throttle=state.throttle_ewma,
            brake=brake_activation,
            steering=steer_angle_adjusted_for_speed,
        )

        LaneFollowingController._update_target_lane_if_reached_end_of_lane(
            sim, agent_id, vehicle, state
        )

    @staticmethod
    def _compute_steering_correction(sim, vehicle, wp_path):
        v_pos = vehicle.position

        v_heading = vehicle.heading
        steer_corr_with_discounted_future = 0.0
        for wp in reversed(wp_path):
            next_correction = LaneFollowingController._compute_steering_correction_for_wp(
                v_pos, v_heading, wp
            )
            steer_corr_with_discounted_future = lerp(
                steer_corr_with_discounted_future, next_correction, 0.2,
            )

        return steer_corr_with_discounted_future

    @staticmethod
    def _compute_steering_correction_for_wp(vehicle_pos, vehicle_heading, wp):
        align_steering_to_lane_heading = wp.relative_heading(vehicle_heading)

        signed_lateral_error = wp.signed_lateral_error(vehicle_pos)
        steer_towards_lane_center = (
            math.sin(
                np.clip(-signed_lateral_error / (wp.lane_width * 0.5) ** 2, -1, 1)
                * math.pi
                / 2
            )
            * 35
        )

        steer_angle_unclipped = lerp(
            steer_towards_lane_center, align_steering_to_lane_heading, 0.6
        )
        steer_angle = np.clip(3 * steer_angle_unclipped / 35, -1, 1)

        return -steer_angle

    @staticmethod
    def _update_target_lane_if_reached_end_of_lane(sim, agent_id, vehicle, state):
        # When we reach the end of our target lane, we need to update it
        # to the next lane best lane along the path
        v_pos = vehicle.position
        v_head = vehicle.heading

        paths = sim.mission_planner(agent_id).waypoint_paths_on_lane_at(
            v_pos, state.target_lane_id, lookahead=2
        )

        candidate_next_wps = []
        for path in paths:
            wps_of_next_lanes_on_path = [
                wp for wp in path if wp.lane_id != state.target_lane_id
            ]

            if wps_of_next_lanes_on_path == []:
                continue

            next_wp = wps_of_next_lanes_on_path[0]
            candidate_next_wps.append(next_wp)

        if candidate_next_wps == []:
            return

        next_wp = min(
            candidate_next_wps,
            key=lambda wp: abs(wp.signed_lateral_error(v_pos))
            + abs(wp.relative_heading(v_head)),
        )

        state.target_lane_id = next_wp.lane_id
