import os
import sys
import math
import glob
import random
import logging

import numpy as np

from functools import lru_cache
from itertools import cycle, product
from dataclasses import dataclass
from typing import Dict, Sequence, Iterable, Tuple, Any

from .sumo_road_network import SumoRoadNetwork
from .sumo_traffic_simulation import VehicleFollowingModel
from .waypoints import Waypoints
from .units import Heading
from .utils import vec_to_degrees
from .utils.sumo import sumolib


@dataclass(frozen=True)
class Start:
    position: Tuple[int, int]
    heading: Heading


@dataclass(frozen=True)
class Goal:
    def is_endless(self):
        return True

    def did_reach(self, vehicle):
        return False


@dataclass(frozen=True)
class EndlessGoal(Goal):
    pass


@dataclass(frozen=True)
class PositionalGoal(Goal):
    position: Tuple[int, int]
    # target_heading: Heading
    radius: float

    def is_endless(self):
        return False

    def did_reach(self, vehicle):
        a = vehicle.position
        b = self.position
        dist = math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2)
        return dist <= self.radius


@dataclass(frozen=True)
class Mission:
    start: Start
    goal: Goal

    @property
    def is_endless(self):
        return self.goal.is_endless()


class Scenario:
    """
    The purpose of the Scenario is to provide an aggregate of all
    code/configuration/assets that is specialized to a scenario using SUMO.

    # Scenario is `pickle`able, this is important for use with frameworks like Ray/rllib
    >>> import pickle
    >>> scenario = Scenario("scenarios/loop")
    >>> unpickled_scenario = pickle.loads(pickle.dumps(scenario))
    >>> scenario.root_filepath == unpickled_scenario.root_filepath
    True
    """

    def __init__(
        self,
        scenario_root: str,
        route: str = None,
        missions: Dict[str, Mission] = None,
        log_dir: str = "./_run_logs",
    ):
        """
        scenario_root: The scenario asset folder ie. './scenarios/trigger'.
        route: The social vehicle traffic spec.
        missions: agent_id to mission mapping.
        """

        self._logger = logging.getLogger(self.__class__.__name__)
        self._root = scenario_root
        self._route = route
        self._missions = missions or {}
        self._log_dir = os.path.abspath(log_dir)

        self._validate_assets_exist()

    def __repr__(self):
        return f"""Scenario(
  _root={self._root},
  _route={self._route},
  _missions={self._missions},
)"""

    @staticmethod
    def scenario_variations(
        scenarios_or_scenarios_dirs: Sequence[str], agents_to_be_briefed: Sequence[str],
    ):
        """
        scenarios_or_scenarios_dirs:
            A sequence of either the scenario to run (see scenarios/ for some samples you
            can use) OR a directory of scenarios to sample from.
        agents_to_be_briefed:
            Agent IDs that will be assigned a mission ("briefed" on a mission).
        """
        scenario_roots = []
        for root in scenarios_or_scenarios_dirs:
            if Scenario.is_valid_scenario(root):
                # This is the single scenario mode, only training against a single scenario
                scenario_roots.append(root)
            else:
                scenario_roots.extend(Scenario.discover_scenarios(root))

        return cycle(
            Scenario.variations_for_all_scenario_roots(
                scenario_roots, agents_to_be_briefed
            )
        )

    @staticmethod
    def variations_for_all_scenario_roots(scenario_roots, agents_to_be_briefed):
        assert (
            len(agents_to_be_briefed) > 0
        ), "The agents to be briefed must be greater than 0."

        for scenario_root in scenario_roots:
            routes = Scenario.discover_routes(scenario_root) or [None]
            agent_missions = Scenario.discover_agent_missions(
                scenario_root, agents_to_be_briefed
            )
            social_missions = []
            social_agent_infos = Scenario.discover_social_agents(scenario_root)
            for social_agents_missions in social_agent_infos:
                social_missions.append(
                    {
                        agent_id: mission
                        for agent_id, (
                            mission,
                            agent_locator,
                        ) in social_agents_missions.items()
                    }
                )

            missions = [
                {**agent, **social}
                for agent, social in product(agent_missions, social_missions)
            ]

            if len(missions) < 1:
                missions = agent_missions

            roll_routes = random.randint(0, len(routes))
            roll_missions = random.randint(0, len(missions))

            for route, agent_missions_ in product(
                np.roll(routes, roll_routes, 0), np.roll(missions, roll_missions, 0)
            ):
                yield Scenario(
                    scenario_root, route=route, missions=agent_missions_,
                )

    @staticmethod
    def discover_agent_missions(scenario_root, agents_to_be_briefed):
        """
        Returns a sequence of {agent_id: mission} mappings by using `discover_mission`
        to fetch missions created via Scenario Studio.

        If no missions are discovered we generate random ones. If there is only one
        agent to be briefed we return a list of `{agent_id: mission}` cycling through
        each mission. If there are multiple agents to be briefed we assume that each
        one is intended to get its own mission and that `len(agents_to_be_briefed) ==
        len(missions)`. In this case a list of one dictionary is returned.
        """
        missions = Scenario.discover_missions(scenario_root)
        if not missions:
            missions = [None for _ in range(len(agents_to_be_briefed))]
        if len(agents_to_be_briefed) == 1:
            # single-agent, so we cycle through all missions individually.
            return [{agents_to_be_briefed[0]: mission} for mission in missions]
        else:
            # multi-agent, so we assume missions "drive" the agents (i.e. one
            # mission per agent) and we will not be cycling through missions.
            assert not missions or len(missions) == len(agents_to_be_briefed), (
                "You must either provide an equal number of missions ({}) to "
                "agents ({}) or provide no missions at all so they can be "
                "randomly generated.".format(len(missions), len(agents_to_be_briefed))
            )

        return [dict(zip(agents_to_be_briefed, missions))]

    @staticmethod
    @lru_cache(maxsize=10)
    def discover_social_agents(
        scenario,
    ) -> Sequence[Dict[str, Tuple[Mission, str]]]:  # id: (mission, locator)
        scenario_root = (
            scenario.root_filepath if isinstance(scenario, Scenario) else scenario
        )
        net_file = os.path.join(scenario_root, "map.net.xml")
        path = os.path.join(scenario_root, "social_agent")

        if not os.path.exists(path):
            return []

        file_match = os.path.join(path, "*.rou.xml")

        road_network = SumoRoadNetwork.from_file(net_file)

        agent_bucketer = []  # [ ( missions_file, agent_locator, Mission ) ]

        # like dict.setdefault
        def setdefault(l: Sequence[Any], index: int, default):
            while len(l) < index + 1:
                l.append([])
            return l[index]

        for missions_file_path in glob.glob(file_match):
            with open(missions_file_path) as missions_file:
                count = 0
                for vehicle in sumolib.output.parse(missions_file, "vehicle"):
                    if not vehicle.route:
                        continue
                    mission = Scenario._construct_mission(vehicle, road_network)

                    agent_locator = vehicle.type.split("`")[1]
                    setdefault(agent_bucketer, count, []).append(
                        (missions_file.name, agent_locator, mission)
                    )
                    count += 1

        output = []
        for l in agent_bucketer:
            output.append(
                {agent_id: (mission, locator) for agent_id, locator, mission in l}
            )
        return output

    @staticmethod
    def discover_scenarios(scenario_or_scenarios_dir):
        if Scenario.is_valid_scenario(scenario_or_scenarios_dir):
            # This is the single scenario mode, only training against a single scenario
            scenario = scenario_or_scenarios_dir
            discovered_scenarios = [scenario]
        else:
            # Find all valid scenarios in the given scenarios directory
            discovered_scenarios = []
            for scenario_file in os.listdir(scenario_or_scenarios_dir):
                scenario_root = os.path.join(scenario_or_scenarios_dir, scenario_file)
                if Scenario.is_valid_scenario(scenario_root):
                    discovered_scenarios.append(scenario_root)
        assert (
            len(discovered_scenarios) > 0
        ), f"No valid scenarios found in {scenario_or_scenarios_dir}"

        return discovered_scenarios

    @staticmethod
    def discover_routes(scenario_root):
        """
        >>> Scenario.discover_routes("scenarios/intersections/2lane")
        ['all.rou.xml', 'horizontal.rou.xml', 'turns.rou.xml', 'unprotected_left.rou.xml', 'vertical.rou.xml']
        >>> Scenario.discover_routes("scenarios/loop") # loop does not have any routes
        []
        """
        return sorted(
            [
                os.path.basename(r)
                for r in glob.glob(os.path.join(scenario_root, "traffic", "*.rou.xml"))
            ]
        )

    @staticmethod
    def discover_missions(scenario_root):
        net_file = os.path.join(scenario_root, "map.net.xml")
        road_network = SumoRoadNetwork.from_file(net_file)

        missions = []
        missions_file = os.path.join(scenario_root, "missions.rou.xml")
        if not os.path.exists(missions_file):
            return missions

        for vehicle in sumolib.output.parse(missions_file, "vehicle"):

            mission = Scenario._construct_mission(vehicle, road_network)
            missions.append(mission)

        return missions

    @staticmethod
    def _construct_mission(vehicle, road_network):
        def resolve_offset(offset, lane_length):
            if offset == "base":
                return 0
            elif offset == "max":
                return lane_length
            elif offset == "random":
                return random.uniform(0, lane_length)
            else:
                return float(offset)

        def to_position_and_heading(edge_id, lane_index, offset, road_network):
            edge = road_network.edge_by_id(edge_id)
            lane = edge.getLanes()[lane_index]
            offset = resolve_offset(offset, lane.getLength())
            position = road_network.world_coord_from_offset(lane, offset)
            lane_vector = road_network.lane_vector_at_offset(lane, offset)
            heading = vec_to_degrees(lane_vector)
            return tuple(position), Heading(heading)

        # For now we discard the route and just take the start and end to form our
        # missions.
        edges = vehicle.route[0].edges.split(" ")

        position, heading = to_position_and_heading(
            edges[0], int(vehicle.departLane), vehicle.departPos, road_network,
        )
        start = Start(position, heading)

        position, _ = to_position_and_heading(
            edges[-1], int(vehicle.arrivalLane), vehicle.arrivalPos, road_network,
        )
        goal = PositionalGoal(position, radius=2)
        return Mission(start=start, goal=goal)

    @staticmethod
    def is_valid_scenario(scenario_root):
        """Checks if the scenario_root directory matches our expected scenario structure

        >>> Scenario.is_valid_scenario("scenarios/loop")
        True
        >>> Scenario.is_valid_scenario("scenarios/non_existant")
        False
        """
        paths = [
            os.path.join(scenario_root, "map.net.xml"),
            os.path.join(scenario_root, "map.egg"),
        ]

        for f in paths:
            if not os.path.exists(f):
                return False

        # make sure we can load the sumo network
        net_file = os.path.join(scenario_root, "map.net.xml")
        net = SumoRoadNetwork.from_file(net_file)
        if net is None:
            return False

        return True

    @property
    def name(self):
        return os.path.basename(os.path.normpath(self._root))

    @property
    def root_filepath(self):
        return self._root

    @property
    def net_filepath(self):
        return os.path.join(self._root, "map.net.xml")

    @property
    def plane_filepath(self):
        return os.path.join(self._root, "plane.urdf")

    @property
    def route(self):
        return self._route

    @property
    def route_files_enabled(self):
        return bool(self._route)

    @property
    def route_filepath(self):
        return os.path.join(self._root, "traffic", self._route)

    @property
    def map_egg_filepath(self):
        return os.path.join(self._root, "map.egg")

    @property
    def sumo_log_dir(self):
        return os.path.join(self._log_dir, "sumo")

    @property
    def missions(self):
        return self._missions

    def mission(self, agent_id):
        return self._missions.get(agent_id, None)

    def _validate_assets_exist(self):
        assert Scenario.is_valid_scenario(self._root)

        if not os.path.exists(self._log_dir):
            os.makedirs(self._log_dir)
