import logging
from typing import Sequence
from multiprocessing import Process, Queue

import gym

import smarts
from smarts.core.smarts import SMARTS
from smarts.core.sumo_traffic_simulation import SumoTrafficSimulation
from smarts.core.scenario import Scenario
from smarts.core.agent_interface import AgentInterface, AgentType
from smarts.zoo.registry import make as make_social_agent

from .visualization import build_visdom_watcher_queue
from .agent import Agent


class RemoteAgent:
    def __init__(self, agent: Agent):
        self._agent = agent
        self._agent_proc = None

    def send_reset(self):
        self._input_queue.put({"type": "control", "payload": "reset"})

    def send_observation(self, obs):
        self._input_queue.put({"type": "obs", "payload": obs})

    def recv_action(self, timeout=None):
        return self._action_queue.get(timeout=timeout)

    def start(self):
        if self._agent_proc:
            return

        self._input_queue = Queue()
        self._action_queue = Queue()

        def agent_event_loop():
            self._agent.setup()
            while True:
                msg = self._input_queue.get()
                if msg["type"] == "control" and msg["payload"] == "reset":
                    self._agent.reset()
                elif msg["type"] == "obs":
                    obs = msg["payload"]
                    action = self._agent.act_with_adaptation(obs)
                    self._action_queue.put(action)
                else:
                    raise NotImplementedError(
                        f'RemoteAgent doesn\'t understand "{msg}"'
                    )

        self._agent_proc = Process(target=agent_event_loop)
        self._agent_proc.daemon = True
        self._agent_proc.start()

    def terminate(self):
        if self._agent_proc:
            self._agent_proc.terminate()
            self._agent_proc = None


class HiWayEnv(gym.Env):
    metadata = {"render.modes": ["human"]}

    def __init__(
        self,
        scenarios: Sequence[str],
        agents,
        visdom=False,
        headless=True,  # This is to toggle Panda3D's visualization
        envision=True,  # This is to toggle our envision visualization
        timestep_sec=0.1,
        seed=42,
    ):
        self._log = logging.getLogger(self.__class__.__name__)
        smarts.core.seed(seed)

        self._visdom_obs_queue = None
        if visdom:
            self._log.info("Running with visdom")
            self._visdom_obs_queue = build_visdom_watcher_queue()

        self._agents = agents
        social_agent_infos = Scenario.discover_social_agents(scenarios[0])
        social_agents = {
            agent_id: make_social_agent(
                locator=missions_and_locator[1],
                ## Overload the prefab here
            )
            for d in social_agent_infos
            for agent_id, missions_and_locator in d.items()
        }

        # social agents
        self._remote_social_agents = {
            agent_id: RemoteAgent(social_agent)
            for agent_id, social_agent in social_agents.items()
        }

        for remote_social_agent in self._remote_social_agents.values():
            remote_social_agent.start()

        self._scenarios_iterator = Scenario.scenario_variations(
            scenarios, list(agents.keys()),
        )

        agent_interfaces = {
            agent_id: agent.interface for agent_id, agent in agents.items()
        }

        social_agent_interfaces = {
            agent_id: agent.interface for agent_id, agent in social_agents.items()
        }

        self._smarts = SMARTS(
            agent_interfaces=agent_interfaces,
            social_agent_interfaces=social_agent_interfaces,
            traffic_sim=SumoTrafficSimulation(
                headless=True, time_resolution=timestep_sec
            ),
            headless=headless,
            envision=envision,
            timestep_sec=timestep_sec,
        )

    @property
    def scenario(self):
        return self._smarts.scenario

    @property
    def timestep_sec(self):
        return self._smarts.timestep_sec

    def step(self, agent_actions):
        agent_actions = {
            agent_id: self._agents[agent_id].action_adapter(action)
            for agent_id, action in agent_actions.items()
        }
        social_agent_actions = {
            agent_id: remote_agent.recv_action(timeout=5)
            for agent_id, remote_agent in self._remote_social_agents.items()
        }
        all_agent_actions = {**agent_actions, **social_agent_actions}

        observations, rewards, scores, agent_dones = self._smarts.step(
            all_agent_actions
        )

        for agent_id, remote_agent in self._remote_social_agents.items():
            obs = observations[agent_id]
            remote_agent.send_observation(obs)

        self._remove_social_agents_from_env_output(observations)
        self._remove_social_agents_from_env_output(rewards)
        self._remove_social_agents_from_env_output(agent_dones)  # unnecessary?
        self._remove_social_agents_from_env_output(scores)

        # Important to teardown done agents after we've filtered out the
        # social agents from dones. We do not want to teardown social agents
        # because we are prioritizing simulation cohesion over social agent
        # behaviour stability.
        self._teardown_done_agent_vehicles(agent_dones)

        # XXX: Is this still a good approach for visualization of image-based observations?
        self._try_emit_visdom_obs(observations)

        infos = {key: {"score": value} for key, value in scores.items()}

        for agent_id in observations:
            agent = self._agents[agent_id]
            observation = observations[agent_id]
            reward = rewards[agent_id]

            rewards[agent_id] = agent.reward_adapter(observation, reward)
            observations[agent_id] = agent.observation_adapter(observation)

        agent_dones["__all__"] = all(agent_dones.values())

        return observations, rewards, agent_dones, infos

    def reset(self):
        scenario = next(self._scenarios_iterator)
        env_observations = self._smarts.reset(scenario)

        for agent_id, remote_agent in self._remote_social_agents.items():
            remote_agent.send_reset()
            remote_agent.send_observation(env_observations[agent_id])

        self._remove_social_agents_from_env_output(env_observations)

        # XXX: Is this still a good approach for visualization of image-based observations?
        self._try_emit_visdom_obs(env_observations)

        observations = {
            agent_id: self._agents[agent_id].observation_adapter(obs)
            for agent_id, obs in env_observations.items()
        }

        return observations

    def render(self, mode="human"):
        pass

    def close(self):
        if self._smarts is not None:
            self._smarts.destroy()

        for remote_agent in self._remote_social_agents.values():
            remote_agent.terminate()

    def _remove_social_agents_from_env_output(self, output):
        # TODO: we need a more robust way of making sure social agents don't leak out of the env
        for social_agent_id in self._remote_social_agents:
            del output[social_agent_id]

    def _teardown_done_agent_vehicles(self, agent_dones):
        for agent_id, is_done in agent_dones.items():
            if is_done:
                self._smarts.teardown_agent_vehicle(agent_id)

    def _try_emit_visdom_obs(self, obs):
        try:
            if self._visdom_obs_queue:
                self._visdom_obs_queue.put(obs, block=False)
        except Exception:
            self._log.debug("Dropped visdom frame instead of blocking")
