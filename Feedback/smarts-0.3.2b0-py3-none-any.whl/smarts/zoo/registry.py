from smarts.core.utils.class_factory import ClassRegister

agent_registry = ClassRegister()


def register(locator: str, entry_point, **kwargs):
    agent_registry.register(locator=locator, entry_point=entry_point, **kwargs)


def make(locator: str, **kwargs):
    return agent_registry.make(locator, **kwargs)
