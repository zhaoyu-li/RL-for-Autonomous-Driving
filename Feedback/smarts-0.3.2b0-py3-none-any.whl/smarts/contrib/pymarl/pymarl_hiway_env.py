import numpy as np
from gym.spaces import Box, Discrete

import smarts
from smarts.env.visualization import build_visdom_watcher_queue
from smarts.core.agent_interface import AgentInterface, AgentType
from smarts.core.scenario import Scenario
from smarts.core.smarts import SMARTS
from smarts.core.sumo_traffic_simulation import SumoTrafficSimulation
from .adapters.action_adapter import (
    DEFAULT_ACTION_SPACE,
    N_ACTIONS,
    default_action_adapter,
)
from .adapters.observation_adapter import (
    DEFAULT_OBSERVATION_SPACE,
    default_obs_adapter,
)
from .adapters.reward_adapter import default_reward_adapter
from .adapters.state_adapter import (
    DEFAULT_STATE_SPACE,
    default_state_adapter,
)


class PyMARLHiWayEnv:
    """This class adheres to the PyMARL MultiAgentEnv so it can be run by PyMARL.
    See: https://git.io/JvMb9
    """

    def __init__(self, config):
        self._config = config

        # XXX: These are intentionally left public at PyMARL's request
        self.n_agents = config.get("n_agents", 1)
        self.episode_limit = config.get("episode_limit", 1000)
        self.observation_space = config.get(
            "observation_space", DEFAULT_OBSERVATION_SPACE
        )
        self.action_space = config.get("action_space", DEFAULT_ACTION_SPACE)
        self.state_space = config.get("state_space", DEFAULT_STATE_SPACE)

        self._agent_ids = ["Agent %i" % i for i in range(self.n_agents)]

        self._reward_adapter = config.get("reward_adapter", default_reward_adapter)
        self._observation_adapter = config.get(
            "observation_adapter", default_obs_adapter
        )
        self._action_adapter = config.get("action_adapter", default_action_adapter)
        self._done_adapter = config.get(
            "done_adapter", lambda dones: list(dones.values())
        )
        self._state_adapter = config.get("state_adapter", default_state_adapter)

        self._headless = config.get("headless", False)
        self._timestep_sec = config.get("timestep_sec", 0.01)
        self._observations = None
        self._state = None
        self._steps = 0

        seed = self._config.get("seed", 42)
        smarts.core.seed(seed)

        self._scenarios_iterator = Scenario.scenario_variations(
            config["scenarios"], self._agent_ids
        )

        agent_interfaces = {
            agent_id: AgentInterface.from_type(
                config.get("agent_type", AgentType.Laner),
                max_episode_steps=self.episode_limit,
                debug=config.get("debug", False),
            )
            for i, agent_id, in enumerate(self._agent_ids)
        }

        self._visdom_obs_queue = None
        if self._config.get("visdom", False):
            self._visdom_obs_queue = build_visdom_watcher_queue()

        self._smarts = SMARTS(
            agent_interfaces=agent_interfaces,
            traffic_sim=SumoTrafficSimulation(
                headless=True, time_resolution=self._timestep_sec
            ),
            headless=self._headless,
            timestep_sec=self._timestep_sec,
        )

    def get_obs(self):
        return self._observations

    def get_obs_agent(self, agent_id):
        return self._observations[agent_id]

    def get_obs_size(self):
        obs_size = 0
        for obs in self.observation_space.spaces.values():
            if type(obs) is Box:
                obs_size += np.prod(obs.shape)
            elif type(obs) is Discrete:
                obs_size += obs.n
        return obs_size

    def get_state(self):
        return np.concatenate(self._observations)

    def get_state_size(self):
        return self.get_obs_size() * self.n_agents

    def get_avail_actions(self):
        return [np.ones((N_ACTIONS,)) for _ in range(self.n_agents)]

    def get_avail_agent_actions(self, agent_id):
        return np.ones((N_ACTIONS,))

    def get_total_actions(self):
        return N_ACTIONS

    def render(self):
        pass

    def seed(self):
        # TODO: This is an unusual API
        smarts.core.seed(self._config.get("seed", 42))

    def save_replay(self):
        pass

    def step(self, agent_actions):
        agent_actions = {
            agent_id: self._action_adapter(action)
            for agent_id, action in zip(self._agent_ids, agent_actions)
        }
        observations, rewards, scores, dones = self._smarts.step(agent_actions)

        infos = {id_ + "_score": score for id_, score in scores.items()}

        # Ensure all contain the same agent_ids as keys
        assert agent_actions.keys() == observations.keys() == rewards.keys()
        self._observations = np.asarray(
            [
                np.concatenate(list(self._observation_adapter(obs).values()))
                for obs in observations.values()
            ]
        )
        rewards = [
            self._reward_adapter(obs, rew)
            for obs, rew in zip(observations.values(), rewards.values())
        ]

        infos["rewards_list"] = rewards

        self._steps += 1
        infos["dones_list"] = list(dones.values())
        dones = np.all(infos["dones_list"])
        if self._steps >= self.episode_limit:
            infos["episode_steps"] = self._steps
            dones = True

        return np.mean(rewards), dones, infos

    def reset(self):
        self._steps = 0

        scenario = next(self._scenarios_iterator)
        observations = self._smarts.reset(scenario)
        self._observations = np.asarray(
            [
                np.concatenate(list(self._observation_adapter(obs).values()))
                for obs in observations.values()
            ]
        )
        return self._observations

    def close(self):
        if self._smarts is not None:
            self._smarts.destroy()

    def get_env_info(self):
        return {
            "state_shape": self.get_state_size(),
            "obs_shape": self.get_obs_size(),
            "n_actions": self.get_total_actions(),
            "n_agents": self.n_agents,
            "episode_limit": self.episode_limit,
        }
