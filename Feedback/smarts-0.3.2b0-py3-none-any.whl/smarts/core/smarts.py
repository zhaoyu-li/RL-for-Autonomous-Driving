import os
import math
import logging
import importlib.resources as pkg_resources
from collections import defaultdict, namedtuple

import numpy
from direct.showbase.ShowBase import ShowBase
from panda3d.core import (
    ClockObject,
    loadPrcFileData,
    BoundingBox as P3DBoundingBox,
    NodePath,
    LineSegs,
    AmbientLight,
    DirectionalLight,
    Geom,
    GeomNode,
    GeomPoints,
    GeomTristrips,
    GeomVertexData,
    GeomVertexFormat,
    GeomVertexWriter,
    TransparencyAttrib,
)

import gltf
import pybullet
import pybullet_utils.bullet_client as bc
from sklearn.metrics.pairwise import euclidean_distances

from . import models
from .agent_state import AgentState
from .vehicle import Vehicle
from .social_vehicle import SocialVehicle
from .masks import RenderMasks
from .lidar import LidarRenderer
from .sensors import Sensors
from .scenario import Scenario
from .controllers import Controllers
from .units import Heading
from .utils.bullet_client import BulletClient
from .mission_planner import MissionPlanner, Mission
from .render_helpers import Panda3DVizLayer
from envision import Client as Envision
from envision import types as envision_types

# disable vsync otherwise we are limited to refresh-rate of screen
loadPrcFileData("", "sync-video false")
loadPrcFileData("", "model-path %s" % os.getcwd())

# https://www.panda3d.org/manual/?title=Multithreaded_Render_Pipeline
# loadPrcFileData('', 'threading-model Cull/Draw')

# have makeTextureBuffer create a visible window
# loadPrcFileData('', 'show-buffers true')

# TODO: consider moving collision detection to sensors.py
"""
If the collision was with another agent then the ID is the agent ID, otherwise
it's a SocialVehicle ID.
"""
Collision = namedtuple("Collision", ["collided_with_agent", "collidee_id"])


class SMARTSNotSetupError(Exception):
    pass


class SMARTS(ShowBase):
    def __init__(
        self,
        agent_interfaces,
        traffic_sim,
        social_agent_interfaces={},
        headless=True,
        envision=True,
        timestep_sec=0.1,
        fixed_viewport=True,
    ):
        window_type = "offscreen" if headless else "onscreen"
        super().__init__(self, windowType=window_type)

        gltf.patch_loader(self.loader)

        self._scenario = None
        self._headless = headless
        self._envision = Envision() if envision else None
        self._timestep_sec = timestep_sec
        self._is_setup = False

        # global clock always proceeds by a fixed dt on each tick
        self.taskMgr.clock.setMode(ClockObject.M_non_real_time)
        self.taskMgr.clock.setDt(timestep_sec)

        self._log = logging.getLogger(self.__class__.__name__)

        self.setBackgroundColor(0, 0, 0, 1)

        # displayed framerate is misleading since we
        # are not using a realtime clock
        self.setFrameRateMeter(False)

        self._agent_states = {}
        for agent_id, agent_interface in agent_interfaces.items():
            self._agent_states[agent_id] = AgentState(agent_interface, trainable=True)

        for agent_id, agent_interface in social_agent_interfaces.items():
            self._agent_states[agent_id] = AgentState(agent_interface, trainable=False)

        self._traffic_sim = traffic_sim
        self._fixed_viewport = fixed_viewport

        self._root_np = None
        self._traffic_lights_np = None
        self._vehicles_np = None  # TODO: Rename to `agent_vehicles_np`?
        self._traffic_np = None
        self._road_network_np = None

        self._ground_bullet_id = None

        self._active_agent_vehicles = {}
        self._mission_planners = {}
        self._agent_collisions = defaultdict(list)  # list of `Collision` instances
        self._social_vehicles = {}

        # For macOS GUI. See our `BulletClient` docstring for details.
        # self._bullet_client = BulletClient(pybullet.GUI)
        self._bullet_client = bc.BulletClient(pybullet.DIRECT)

        self._viz_layer = None

    @property
    def timestep_sec(self):
        return self._timestep_sec

    def step(self, action_msg):
        if not self._is_setup:
            raise SMARTSNotSetupError("Must call reset() or setup() before stepping")

        try:
            return self._step(action_msg)
        except KeyboardInterrupt:
            # ensure we clean-up if the user exits the simulation
            self._log.info("Simulation was interrupted by the user")
            self.destroy()
            raise  # re-raise the KeyboardInterrupt
        except Exception as e:
            self._log.error(
                "Simulation crashed with exception." "Attempting to cleanly shutdown."
            )
            self._log.exception(e)
            self.destroy()
            raise  # re-raise

    def _step(self, action_msg):
        """Steps through the simulation while applying the given agent actions.
        Returns the observations, rewards, and done signals.
        """

        # Due to a limitation of our traffic simulator(SUMO) interface(TRACI), we can
        # only observe traffic state of the previous simulation step.
        #
        # To compensate for this, we:
        #
        # 1. Step the traffic simulation
        # 2. Run rendering pipeline
        # 3. Perform agent actions
        # 4. Calculate resulting reward/observations
        # 5. Step the physics simulation
        # 6. Perform visualization
        #
        # In this way, observations and reward are computed with data that is
        # consistently with one step of latencey and the agent will observe consistent
        # data.
        dt = self.taskMgr.clock.get_dt()

        # 1. Step traffic simulation
        self._step_traffic(dt)

        # 2. Render and the other panda internal stuff.
        # It's important we call this here because we rely on the the render pipeline
        # for some of the observation/reward calculations.
        self.taskMgr.mgr.poll()

        self._after_frame()

        # 3. Perform agent action
        self._perform_agent_actions(action_msg)
        self._increment_agent_step()

        # 4. Calculate observation and reward
        observations, dones = self._observation()
        rewards = self._reward()
        scores = self._score()

        # 5. Step the physics simulation
        self._step_physics()

        # 6. Perform visualization
        if not self._headless and not self._fixed_viewport:
            self._look_at_np(self._vehicles_np)

        self._try_emit_envision_state(observations)

        return observations, rewards, scores, dones

    def reset(self, scenario):
        self.teardown()
        self.setup(scenario)
        return self._observation()[0]

    def setup(self, scenario):
        self._scenario = scenario
        self._root_np = NodePath("sim")

        self._setup_bullet_client(self._bullet_client)
        self._root_np.reparentTo(self.render)

        self._vehicles_np = self._root_np.attachNewNode("vehicles")
        self._traffic_np = self._root_np.attachNewNode("traffic")
        self._viz_layer = Panda3DVizLayer(self._root_np)

        self._setup_lighting()

        # Must be called after sim setup which adds our agents
        social_vehicle_state, traffic_lights_state = self._traffic_sim.setup(
            self._scenario
        )

        self._setup_scenario(self._scenario)

        self._traffic_sim.sync(
            managed_vehicles={
                agent_id: (agent_vehicle.position, agent_vehicle.heading)
                for agent_id, agent_vehicle in self._active_agent_vehicles.items()
            }
        )

        self._sync_traffic_vehicles(social_vehicle_state)
        self._viz_layer.render_traffic_lights(traffic_lights_state)

        target_np = self._road_network_np if self._fixed_viewport else self._root_np
        self._look_at_np(target_np)

        self._is_setup = True

    def _setup_scenario(self, scenario):
        self._add_road_network_from_egg(scenario.map_egg_filepath)

        for agent_id, agent_state in self._agent_states.items():
            mission = scenario.mission(agent_id)

            self._add_agent(agent_id, agent_state, mission)

    def _setup_bullet_client(self, client):
        client.resetSimulation()

        if not self._headless:
            client.configureDebugVisualizer(pybullet.COV_ENABLE_GUI, 0)

        # PyBullet defaults the timestep to 240Hz. Several parameters are tuned with
        # this value in mind. For example the number of solver iterations and the error
        # reduction parameters (erp) for contact, friction and non-contact joints.
        # Attempting to get around this we set the number of substeps so that
        # timestep * substeps = 240Hz. Bullet (C++) does something to this effect as
        # well (https://git.io/Jvf0M), but PyBullet does not expose it.
        client.setPhysicsEngineParameter(
            fixedTimeStep=self._timestep_sec,
            numSubSteps=math.ceil(self._timestep_sec / (1 / 240)),
        )

        client.setGravity(0, 0, -9.8)

        plane_path = self._scenario.plane_filepath
        if os.path.exists(plane_path):
            self._ground_bullet_id = client.loadURDF(plane_path, useFixedBase=True)
        else:
            with pkg_resources.path(models, "plane.urdf") as path:
                self._ground_bullet_id = client.loadURDF(
                    str(path.absolute()), useFixedBase=True
                )

    def teardown(self):
        for agent_state in self._agent_states.values():
            agent_state.teardown()

        for agent_id, agent_vehicle in self._active_agent_vehicles.items():
            agent_vehicle.teardown()

        self._active_agent_vehicles = {}
        self._mission_planners = {}
        self._agent_collisions = defaultdict(list)
        self._social_vehicles = {}

        self._bullet_client.resetSimulation()
        self._traffic_sim.teardown()

        if self._root_np:
            self._root_np.clearLight()
            self._root_np.removeNode()

        self._vehicles_np = None
        self._traffic_lights_np = None
        self._ground_bullet_id = None
        self._road_network_np = None
        self._is_setup = False

    def destroy(self):
        self.teardown()

        if self._envision:
            self._envision.teardown()

        self._bullet_client.disconnect()

        super().destroy()

    def _after_frame(self):
        self._viz_layer.reset_node_path()

    @property
    def scenario(self):
        return self._scenario

    @property
    def traffic_sim(self):
        return self._traffic_sim

    @property
    def waypoints(self):
        """Convenience property to access the `Waypoints` object."""
        return self._traffic_sim.waypoints

    @property
    def np(self):
        return self._root_np

    def render_lidar(self, point_cloud, hits, rays):
        if self._headless:
            return

        self._viz_layer.render_lidar(point_cloud, hits, rays)

    def render_path(self, path, color=(1, 1, 1)):
        if self._headless:
            return

        self._viz_layer.render_path(path, color=color)

    def render_waypoint_paths(self, paths):
        if self._headless:
            return

        # color paths to show ordering (red -> blue => right -> left)
        for i, path in enumerate(paths):
            p = (i + 1) / len(paths)
            path = [wp.pos for wp in path]
            self._viz_layer.render_path(path, color=(1.0 - p, 0.0, p, 1.0))

    def render_mission(self, agent_id):
        if self._headless:
            return

        planner = self._mission_planners[agent_id]
        mission = planner.mission
        if not mission.is_endless:
            self._viz_layer.render_mission_route(planner.route)
            self._viz_layer.render_mission_goal(mission.goal)

    def _look_at_np(self, np, h_offset=100):
        # Don't waste compute on camera following if we're in headless mode.
        if self._headless:
            return

        bounds = P3DBoundingBox(*np.getTightBounds())
        center = bounds.getApproxCenter()

        # Approximately get all vehicles in view
        z = max(max(bounds.max - bounds.min) * 1.5, 100)
        self.cam.setPos(center[0], center[1], z)
        self.cam.lookAt(center)

        self._bullet_client.resetDebugVisualizerCamera(
            cameraTargetPosition=center,
            cameraDistance=15,
            cameraYaw=0,
            cameraPitch=-89.999,
        )

    def _step_traffic(self, dt):
        # we must calculate the state of the non-traffic vehicles *before* we
        # step the world so that the traffic simulation and the Bullet
        # simulation remain in lock step.
        # (otherwise, traffic sim will see state that is  one frame ahead)
        agent_vehicle_states = {
            agent_id: (agent_vehicle.position, agent_vehicle.heading)
            for agent_id, agent_vehicle in self._active_agent_vehicles.items()
        }

        # XXX: It's important that we sync managed vehicles before we step the SUMO
        #      simulation because the `managed_vehicles` represents the state of
        #      these vehicles at start of frame. If we were to sync after we step
        #      SUMO, sumo would see these managed vehicles with a 1 step delay.
        self._traffic_sim.sync(agent_vehicle_states)
        social_vehicle_state, traffic_lights_state = self._traffic_sim.step(dt)

        self._sync_traffic_vehicles(social_vehicle_state)

        self._viz_layer.render_traffic_lights(traffic_lights_state)

    def _sync_traffic_vehicles(self, social_vehicle_state):
        previous_vehicle_ids = set(self._social_vehicles.keys())
        current_vehicle_ids = {v.vehicle_id for v in social_vehicle_state}

        exited_vehicles = previous_vehicle_ids - current_vehicle_ids
        new_vehicles = current_vehicle_ids - previous_vehicle_ids

        for v_id in exited_vehicles:
            social_vehicle = self._social_vehicles[v_id]
            social_vehicle.teardown()
            del self._social_vehicles[v_id]

        for v_id in new_vehicles:
            social_vehicle = SocialVehicle(v_id, self, self._bullet_client)
            self._social_vehicles[v_id] = social_vehicle
            social_vehicle.np.reparentTo(self._root_np)

        for v in social_vehicle_state:
            assert v.vehicle_id in self._social_vehicles
            self._social_vehicles[v.vehicle_id].update_from_traffic_sim(v)

    def _step_physics(self):
        self._bullet_client.stepSimulation()

        for _, agent_vehicle in self._active_agent_vehicles.items():
            # This is inspired by Panda3D's `doPhysics` which has a `sync_p2b` and
            # `sync_b2p` (for Panda3D <--> Bullet3 syncing). We'll likely want to
            # move this code to a seperate BulletPhysicsSim-type class.
            agent_vehicle.sync_physics()

        self._process_collisions()

    def neighborhood_vehicles_around_agent(self, agent_id, radius=None):
        other_states = [v for v in self._vehicle_states if v.id != agent_id]
        if radius is None:
            return other_states

        agent_position = self._active_agent_vehicles[agent_id].position
        other_positions = [state.position for state in other_states]
        if not other_positions:
            print(" ~~~ EMPTY ~~~ ")
            return []

        distances = euclidean_distances(other_positions, [agent_position]).reshape(-1,)
        indices = numpy.argwhere(distances <= radius).flatten()
        return [other_states[i] for i in indices]

    def _reward(self):
        # TODO: eliminate reward; we should instead return only score.
        agent_rewards = {}
        for agent_id in self._active_agent_vehicles:
            agent_state = self._agent_states[agent_id]
            agent_rewards[agent_id] = Sensors.score_increment(self, agent_state)

        return agent_rewards

    def _score(self):
        agent_scores = {}
        for agent_id in self._active_agent_vehicles:
            agent_state = self._agent_states[agent_id]
            agent_scores[agent_id] = agent_state.sensor_state.distance_travelled

        return agent_scores

    def _observation(self):
        # We pre-compute vehicle_states here because we *think* the users will
        # want these during their observation/reward computations.
        # This is a hack to give us some short term perf wins. Longer term we
        # need to expose better support for batched computations
        self._vehicle_states = self._compute_vehicle_states()

        observations = {}

        # On setup, we create a corresponding vehicle for each agent interface.
        # If the vehicle that corresponds to an agent_interface is removed at
        # runtime, then that agent is considered done.
        dones = {
            agent_id: True
            for agent_id in self._agent_states
            if agent_id not in self._active_agent_vehicles
        }

        for agent_id in self._active_agent_vehicles:
            agent_state = self._agent_states[agent_id]
            vehicle = self._active_agent_vehicles[agent_id]
            observations[agent_id], dones[agent_id] = Sensors.observe(
                self, agent_id, agent_state, vehicle
            )

        return observations, dones

    def _add_road_network_from_egg(self, egg_path):
        if self._road_network_np:
            self._log.debug(
                "road_network={} already exists. Removing and adding a new "
                "one from egg_path={}".format(self._road_network_np, egg_path)
            )

        np = self._root_np.attachNewNode("road_network")
        model_np = self.loader.loadModel(egg_path)
        model_np.reparent_to(np)
        np.hide(RenderMasks.OCCUPANCY_HIDE)
        self._road_network_np = np
        return np

    def _add_agent(self, agent_id, agent_state: AgentState, mission: Mission):
        assert agent_id not in self._active_agent_vehicles
        assert isinstance(agent_id, str)  # SUMO expects strings identifiers

        planner = MissionPlanner(
            self._traffic_sim.waypoints, self._traffic_sim.road_network
        )
        planned_mission = planner.plan(mission)

        # HACK: Somehow our hiway.units.Heading float wrapper is getting removed by rllib
        #       when it serializes the environment config and comunicates via IPC as a
        #       temporary workaround, we just add the Heading wrapper if it's missing here
        if isinstance(planned_mission.start.heading, Heading):
            heading = planned_mission.start.heading
        else:
            heading = Heading(planned_mission.start.heading)

        agent_vehicle = self._build_vehicle(
            (*planned_mission.start.position, 0.0), heading, agent_state
        )

        agent_state.setup(self, agent_id, agent_vehicle)
        self._active_agent_vehicles[agent_id] = agent_vehicle
        self._mission_planners[agent_id] = planner

    def agent_reached_goal(self, agent_id):
        agent_vehicle = self._active_agent_vehicles[agent_id]

        goal = self._mission_planners[agent_id].mission.goal
        return goal.did_reach(agent_vehicle)

    def agent_is_off_road(self, agent_id):
        agent_vehicle = self._active_agent_vehicles[agent_id]
        vehicle_pos = agent_vehicle.position

        dist_to_nearest_wp = self._traffic_sim.waypoints.closest_waypoint(
            vehicle_pos
        ).dist_to(vehicle_pos)

        is_off_road = dist_to_nearest_wp > 3.0
        return is_off_road

    def agent_did_collide(self, agent_id):
        return len(self._agent_collisions[agent_id]) > 0

    def agent_collisions(self, agent_id):
        return self._agent_collisions[agent_id]

    def mission_planner(self, agent_id):
        return self._mission_planners[agent_id]

    def teardown_agent_vehicle(self, agent_id):
        if agent_id not in self._active_agent_vehicles:
            # Nothing to teardown
            return

        self._active_agent_vehicles[agent_id].teardown()
        del self._active_agent_vehicles[agent_id]

    def _increment_agent_step(self):
        # XXX: not sure we should be tracking the steps per agent at all.
        for agent_id in self._active_agent_vehicles:
            agent_state = self._agent_states[agent_id]
            Sensors.step(self, agent_state)

    def _perform_agent_actions(self, agent_actions):
        for agent_id, action in agent_actions.items():
            agent_state = self._agent_states[agent_id]

            if agent_id not in self._active_agent_vehicles:
                self._log.warning(
                    f"{agent_id} doesn't have a vehicle, is the agent done? (dropping action)"
                )
            else:
                agent_vehicle = self._active_agent_vehicles[agent_id]
                Controllers.perform_action(
                    self, agent_id, agent_state, agent_vehicle, action
                )

    def _build_vehicle(self, pos, heading: Heading, agent_state: AgentState):
        assert isinstance(heading, Heading)

        track_path = (not self._headless) or self._envision
        vehicle_color = (1.0, 0.2, 0.2, 1) if agent_state.trainable else (1, 0.6, 0, 1)
        vehicle = Vehicle(
            pos,
            heading,
            self._root_np,
            self,
            self._bullet_client,
            track_path=track_path,
            color=vehicle_color,
        )
        vehicle.np.reparentTo(self._vehicles_np)

        if agent_state.ogm_subscribed:
            vehicle.init_observation_ogm(
                agent_state.ogm_subscription.width,
                agent_state.ogm_subscription.height,
                agent_state.ogm_subscription.resolution,
            )
        if agent_state.rgb_subscribed:
            vehicle.init_observation_rgb(
                agent_state.rgb_subscription.width,
                agent_state.rgb_subscription.height,
                agent_state.rgb_subscription.resolution,
            )
        if agent_state.lidar_subscribed:
            vehicle.init_observation_lidar(agent_state.lidar_subscription.sensor_params)

        return vehicle

    def _compute_vehicle_states(self):
        vehicles = []
        for vehicle in self._social_vehicles.values():
            vehicles.append(vehicle)

        for agent_id, vehicle in self._active_agent_vehicles.items():
            vehicles.append(
                SocialVehicle.from_agent_vehicle(
                    agent_id, vehicle, self, self._bullet_client
                )
            )

        wps = self._traffic_sim.waypoints.closest_waypoint_batched(
            [v.position for v in vehicles]
        )

        vehicle_states = [
            v.state(wp.lane_id, wp.lane_index) for v, wp in zip(vehicles, wps)
        ]

        return vehicle_states

    def _process_collisions(self):
        self._agent_collisions = defaultdict(list)  # list of `Collision` instances

        for agent_id, vehicle in self._active_agent_vehicles.items():
            # We are only concerned with vehicle-vehicle collisions
            collidee_bullet_ids = set([p.bullet_id for p in vehicle.contact_points])
            collidee_bullet_ids.discard(self._ground_bullet_id)

            if not collidee_bullet_ids:
                continue

            for bullet_id in collidee_bullet_ids:
                collidee = self._bullet_id_to_vehicle(bullet_id)
                collision = self._node_to_collision(collidee.np.node())
                self._agent_collisions[agent_id].append(collision)

    def _bullet_id_to_vehicle(self, bullet_id):
        # TODO: Temporary solution, implement something less blind/invasive.
        for agent_vehicle in self._active_agent_vehicles.values():
            if bullet_id == agent_vehicle.bullet_id:
                return agent_vehicle

        for social_vehicle in self._social_vehicles.values():
            if bullet_id == social_vehicle.bullet_id:
                return social_vehicle

        assert False, "Only collisions with agent or social vehicles is supported"

    def _node_to_collision(self, node):
        for agent_id, agent_vehicle in self._active_agent_vehicles.items():
            if node == agent_vehicle.np.node():
                return Collision(collided_with_agent=True, collidee_id=agent_id)

        # Collidee wasn't an agent, must be a social vehicle
        for social_id, social_vehicle in self._social_vehicles.items():
            if node == social_vehicle.np.node():
                return Collision(collided_with_agent=False, collidee_id=social_id)

        assert False, "Only collisions with agent or social vehicles is supported"

    def _try_emit_envision_state(self, obs):
        if not self._envision:
            return

        traffic = {}
        for id_, vehicle in self._active_agent_vehicles.items():
            actor_type = envision_types.TrafficActorType.SocialAgent
            if self._agent_states[id_].trainable:
                actor_type = envision_types.TrafficActorType.Agent

            point_cloud = obs[id_].lidar_point_cloud or []
            # TODO: Convert to `namedtuple` or only return point cloud
            if len(point_cloud) == 3:  # points, hits, rays
                point_cloud = point_cloud[0]

            traffic[id_] = envision_types.TrafficActorState(
                actor_type=actor_type,
                position=list(vehicle.position),
                heading=vehicle.heading,
                waypoint_paths=obs[id_].waypoint_paths,
                point_cloud=point_cloud,
                driven_path=vehicle.driven_path,
            )

        for id_, vehicle in self._social_vehicles.items():
            traffic[id_] = envision_types.TrafficActorState(
                actor_type=envision_types.TrafficActorType.SocialVehicle,
                position=list(vehicle.position),
                heading=vehicle.heading,
            )

        geom_road_id = self._scenario.name
        state = envision_types.State(traffic=traffic, geom_road_id=geom_road_id)
        self._envision.send_state(state)

    def _setup_lighting(self):
        alight = AmbientLight("ambient_light")
        alight.setColor((0.1, 0.1, 0.1, 1))
        alight_np = self._root_np.attachNewNode(alight)
        self._root_np.setLight(alight_np)

        dlight = DirectionalLight("directional_light")
        dlight_np = self._root_np.attachNewNode(dlight)
        dlight_np.setHpr(0, -45, 0)
        self._root_np.setLight(dlight_np)
