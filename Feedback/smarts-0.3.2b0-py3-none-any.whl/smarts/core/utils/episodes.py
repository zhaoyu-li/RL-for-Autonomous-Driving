import os
import sys
import time
from collections import defaultdict
from contextlib import contextmanager

import tableprint as tp


class EpisodeLog:
    def __init__(self, idx):
        self._idx = idx
        self._start_time = time.time()
        self._rewards = defaultdict(lambda: 0)
        self._iteration = 0

    @property
    def index(self):
        return self._idx

    @property
    def elapsed_time(self):
        return time.time() - self._start_time

    @property
    def rewards(self):
        return self._rewards

    @property
    def iteration(self):
        return self._iteration

    def record_iteration(self, accumulate_reward=None):
        if accumulate_reward:
            self._accumulate_reward(accumulate_reward)

        self._iteration += 1

    def _accumulate_reward(self, rewards):
        for agent, reward in rewards.items():
            self._rewards[agent] += reward


def episodes(env, n):
    row_width = 20
    with tp.TableContext(
        [
            "Episode",
            "World/Sim Duration",
            "Total Iterations",
            "Iterations/Sec",
            "Scenario Map",
            "Scenario Routes",
            "Mission (Hash)",
            "Rewards",
        ],
        width=row_width,
        style="round",
    ) as table:
        for i in range(n):
            e = EpisodeLog(i)
            yield e

            row = (
                f"{e.index}/{n}",
                f"{e.elapsed_time:.1f}s / {e.iteration * env.timestep_sec:.1f}s",
                e.iteration,
                f"{e.iteration / e.elapsed_time:.4f}",
                (env.scenario.name or "")[:row_width],
                (env.scenario.route or "")[:row_width],
                # "Good enough" to show if the missions are changing
                str(hash(frozenset(env.scenario.missions.items())))[:row_width],
            )

            reward_summaries = [
                f"{reward:.2f} ({agent})" for agent, reward in e.rewards.items()
            ]

            if len(reward_summaries) == 0:
                table(row + ("",))
                continue

            table(row + (reward_summaries[0],))
            if len(reward_summaries) > 1:
                for s in reward_summaries[1:]:
                    table(("", "", "", "", "", "", "", s))
