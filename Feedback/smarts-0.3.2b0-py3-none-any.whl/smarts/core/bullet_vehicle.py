import math
import logging
from collections import namedtuple
import importlib.resources as pkg_resources

import numpy as np
import pybullet
import pybullet_utils.bullet_client as bc

from . import models
from .units import Heading

JointInfo = namedtuple(
    "JointInfo",
    ["index", "type", "lower_limit", "upper_limit", "max_force", "max_velocity"],
)

JointState = namedtuple("JointState", ["position", "velocity"])

ContactPoint = namedtuple(
    "ContactPoint", ["bullet_id", "contact_point", "contact_point_other"]
)


class BulletVehicle:
    def __init__(self, pos, heading: Heading, bullet_client: bc.BulletClient):
        assert isinstance(heading, Heading)
        self._log = logging.getLogger(self.__class__.__name__)

        # XXX: Parameterize these vehicle properties?
        self._client = bullet_client
        self._max_throttle_velocity_gain = 100  # leads to approx. 95 km/h
        self._chassis_aero_force_gain = 0.63
        self._max_brake_gain = 10000
        # This value was found emperically. It causes the wheel steer joints to
        # reach their maximum. We use this value to map to the -1, 1 steering range.
        # If it were larger we'd cap out our turning radius before we hit -1, or 1.
        # If it were smaller we'd never reach the tightest turning radius we could.
        self._max_turn_radius = 2.2
        self._wheel_radius = 0.31265
        self._max_torque = 500
        self._max_btorque = 500
        self._max_steering = 460 * (3.14 / 180)
        self._steering_gear_ratio = 17.4

        # XXX: We add 90 deg. b/c the URDF is pointing +x, but ideally is
        #      pointing north. Here we compensate.
        self._rot_offset = math.pi * 0.5

        orientation = self._client.getQuaternionFromEuler(
            [0, 0, heading.as_bullet + self._rot_offset]
        )

        with pkg_resources.path(models, "vehicle.urdf") as path:
            self._bullet_id = self._client.loadURDF(
                str(path.absolute()),
                pos,
                orientation,
                useFixedBase=False,
                # We use cylinders for wheels, If we don't provide this flag, bullet
                # will subdivide the cylinder resulting in bouncy ride
                flags=pybullet.URDF_USE_IMPLICIT_CYLINDER
                | pybullet.URDF_ENABLE_CACHED_GRAPHICS_SHAPES,
            )

        for _id in range(len(self._load_joints(self._bullet_id)) + 1):
            self._client.changeDynamics(
                self._bullet_id,
                _id - 1,
                linearDamping=0,
                angularDamping=0.00001,
                maxJointVelocity=300,  # This is a limit after which the pybullet interfer with the dynamics to ensure the bound.
            )

        length, width, height = np.array(
            self._client.getCollisionShapeData(self._bullet_id, 0)[0][3]
        )
        self._chassis_dimensions = [width, length, height]
        self._origin_offset = np.array(
            self._client.getVisualShapeData(self._bullet_id, 0)[0][5]
        )

        self._joints = self._load_joints(self._bullet_id)

        # distance between front wheels
        link_states = self._client.getLinkStates(self._bullet_id, [3, 4, 5, 6])
        link_positions = [np.array(state[0]) for state in link_states]
        front_left_wheel_pos = link_positions[0]
        front_right_wheel_pos = link_positions[1]
        back_left_wheel_pos = link_positions[2]
        back_right_wheel_pos = link_positions[3]
        self._front_track_width = np.linalg.norm(
            front_left_wheel_pos - front_right_wheel_pos
        )

        # distance between axles
        front_axle_pos = (front_left_wheel_pos + front_right_wheel_pos) / 2
        back_axle_pos = (back_left_wheel_pos + back_right_wheel_pos) / 2
        self._wheel_base_length = np.linalg.norm(front_axle_pos - back_axle_pos)
        self._clear_joint_forces()

    @property
    def position_and_heading(self):
        _, orn = self._client.getBasePositionAndOrientation(self._bullet_id)
        # `getLinkState` gets us the URDF link frame in world coordinates which
        # we then offset by the origin offset (specified in the URDF as well).
        pos = self._client.getLinkState(self._bullet_id, 0)[4]
        pos = np.array(pos) + self._origin_offset

        _roll, _pitch, yaw = self._client.getEulerFromQuaternion(orn)
        # XXX: We subtract 90 deg. b/c URDF was constructed pointing +x.
        heading = Heading.from_bullet(yaw - self._rot_offset)
        return pos, heading

    @property
    def steering(self):
        """Current steering value in degrees."""
        steering_radians = np.mean(
            [
                joint.position
                for joint in self._joint_states(
                    ["front_left_steer_joint", "front_right_steer_joint"]
                )
            ]
        )

        # Joint rotations from pybullet are read back in radians and rotating
        # counter-clockwise, we transform this coordinate system here by:
        # 1. converting to degrees
        # 2. convert to clockwise rotation to be consistent with our action
        #    space where 1 is a right turn and -1 is a left turn. We'd expect
        #    an action with a positive steering activation to result in
        #    positive steering values read back from the vehicle.
        return -math.degrees(steering_radians)

    @property
    def speed(self):
        """Returns speed in km/h."""
        velocity, _ = np.array(self._client.getBaseVelocity(self._bullet_id))
        speed = math.sqrt(velocity.dot(velocity))
        return speed * 3.6

    @property
    def approx_max_speed(self):
        """This is the scientifically discovered maximum speed of this vehicle model"""
        return 95

    @property
    def contact_points(self):
        contact_points = self._client.getContactPoints(self._bullet_id)
        return [
            ContactPoint(bullet_id=p[2], contact_point=p[5], contact_point_other=p[6])
            for p in contact_points
        ]

    @property
    def chassis_dimensions(self):
        return self._chassis_dimensions

    def teardown(self):
        self._client.removeBody(self._bullet_id)
        self._bullet_id = None

    def update(self, throttle, brake, steering):
        """Apply throttle [0, 1], brake [0, 1], and steering [-1, 1] values for this
        timestep.
        """
        assert 0 <= throttle <= 1, f"throttle ({throttle}) must be in [0, 1]"
        assert 0 <= brake <= 1, f"brake ({brake}) must be in [0, 1]"
        assert -1 <= steering <= 1, f"steering ({steering}) must be in [-1, 1]"

        self._apply_throttle(throttle)
        self._apply_brake(brake)
        self._apply_steering(steering)

        # XXX: Needs to be more thorougly tested before using.
        # self._apply_drag(self._chassis_aero_force_gain)

        # XXX: There appears to be a bug where sometimes one of the front wheels
        #      has a significantly higher velocity than the other.
        # self._log_states()

    def _apply_throttle(self, throttle):
        self._client.setJointMotorControlArray(
            self._bullet_id,
            [
                self._joints[name].index
                for name in [
                    "front_left_wheel_joint",
                    "front_right_wheel_joint",
                    "rear_left_wheel_joint",
                    "rear_right_wheel_joint",
                ]
            ],
            pybullet.TORQUE_CONTROL,
            forces=[throttle * self._max_torque] * 4,
        )

    def _apply_brake(self, brake):
        # If we apply brake at low speed using reverse torque
        # the vehicle strats to rollback, we need to apply a condition
        # on brake such that, the reverse torque is only applied after
        # a threshold is passed for vehicle velocity.
        #
        # Thus, brake is applied if: vehicle speed > 0.1 (km/h)=1/36 (m/s)
        if self.speed < 0.1:
            brake = 0
        self._client.setJointMotorControlArray(
            self._bullet_id,
            [
                self._joints[name].index
                for name in [
                    "front_left_wheel_joint",
                    "front_right_wheel_joint",
                    "rear_left_wheel_joint",
                    "rear_right_wheel_joint",
                ]
            ],
            pybullet.TORQUE_CONTROL,
            forces=[
                -brake * self._max_btorque,
                -brake * self._max_btorque,
                -brake * self._max_btorque,
                -brake * self._max_btorque,
            ],
        )

    def _apply_steering(self, steering):
        # Apply steering (following Ackermann steering geometry)
        # See http://datagenetics.com/blog/december12016/index.html

        self._client.setJointMotorControlArray(
            self._bullet_id,
            [
                self._joints[name].index
                for name in ["front_left_steer_joint", "front_right_steer_joint",]
            ],
            pybullet.POSITION_CONTROL,
            targetPositions=[
                -steering * self._max_steering * (1 / self._steering_gear_ratio),
                -steering * self._max_steering * (1 / self._steering_gear_ratio),
            ],
        )

    def _apply_drag(self, force_gain):
        # Compute aero-dynamic drag on chassis
        chassis_link_index = 0
        velocity = np.array(
            self._client.getLinkState(
                self._bullet_id, chassis_link_index, computeLinkVelocity=True
            )[6]
        )

        speed_squared = velocity.dot(velocity)
        if speed_squared > 0:
            unit_velocity = velocity / math.sqrt(speed_squared)
            drag_force = -force_gain * speed_squared * unit_velocity
            self._client.applyExternalTorque(
                self._bullet_id, chassis_link_index, drag_force, pybullet.WORLD_FRAME
            )

    def _log_states(self):
        wheel_joint_states = self._joint_states(
            [
                "front_left_wheel_joint",
                "front_right_wheel_joint",
                "rear_left_wheel_joint",
                "rear_right_wheel_joint",
            ]
        )
        state_summary = "\t|\t".join(
            "{:.2f}".format(s.velocity) for s in wheel_joint_states
        )
        self._log.debug(
            f"wheel_states: {state_summary}\t vehicle speed: {self.speed:.2f}",
            end="\r",
        )

    def _load_joints(self, bullet_id):
        joints = {}
        for i in range(self._client.getNumJoints(self._bullet_id)):
            info = self._client.getJointInfo(self._bullet_id, i)
            name = info[1].decode()
            joints[name] = JointInfo(
                index=info[0],
                type=info[2],
                lower_limit=info[8],
                upper_limit=info[9],
                max_force=info[10],
                max_velocity=info[11],
            )
        return joints

    def _joint_states(self, names):
        joint_indices = [self._joints[name].index for name in names]
        joint_states = self._client.getJointStates(self._bullet_id, joint_indices)
        joint_states = [JointState(position=s[0], velocity=s[1]) for s in joint_states]
        return joint_states

    def _clear_joint_forces(self):

        self._client.setJointMotorControlArray(
            self._bullet_id,
            [
                self._joints[name].index
                for name in [
                    "front_left_wheel_joint",
                    "front_right_wheel_joint",
                    "rear_left_wheel_joint",
                    "rear_right_wheel_joint",
                ]
            ],
            pybullet.TORQUE_CONTROL,
            forces=[0] * 4,
        )
