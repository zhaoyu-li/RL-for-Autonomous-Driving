import time
import uuid
import logging
from typing import NamedTuple
from functools import partial
from collections import namedtuple
import importlib.resources as pkg_resources

import numpy
import pybullet_utils.bullet_client as bc
from direct.showbase.ShowBase import ShowBase
from panda3d.core import (
    FrameBufferProperties,
    GraphicsOutput,
    GraphicsPipe,
    OrthographicLens,
    Texture,
    Material,
    WindowProperties,
    NodePath,
)

from . import models
from .bullet_vehicle import BulletVehicle
from .lidar import Lidar
from .lidar_sensor_params import SensorParams
from .masks import RenderMasks
from .utils import squared_dist
from .units import Heading


class OffscreenCamera(NamedTuple):
    camera_np: NodePath
    buffer: GraphicsOutput
    tex: Texture

    def teardown(self):
        self.camera_np.removeNode()
        region = self.buffer.getDisplayRegion(0)
        region.window.clearRenderTextures()
        self.buffer.removeAllDisplayRegions()
        base.graphicsEngine.removeWindow(self.buffer)


OccupancyGridMap = namedtuple("OccupancyGridMap", ["metadata", "data"])

OccupancyGridMetadata = namedtuple(
    "OccupancyGridMetadata",
    [
        # time at which the map was loaded
        "created_at",
        # map resolution in world-space-distance/cell
        "resolution",
        # map width in # of cells
        "width",
        # map height in # of cells
        "height",
    ],
)

VehicleState = namedtuple(
    "VehicleState",
    ["heading", "speed", "throttle", "brake", "steering", "position", "bounding_box"],
)

BoundingBox = namedtuple("BoundingBox", ["width", "length", "height"])


class _Activations:
    def __init__(self):
        self.throttle = None
        self.brake = None
        self.steering = None

    def __repr__(self):
        return f"""_Activations(
  throttle={self.throttle},
  brake={self.brake},
  steering={self.steering},
)"""


class Vehicle:
    def __init__(
        self,
        pos,
        heading: Heading,
        scene_np,
        showbase: ShowBase,
        bullet_client: bc.BulletClient,
        # Useful for debugging to track the historical path the vehicle has gone.
        track_path=False,
        color=(1, 1, 1, 1),
        vehicle_filepath="",
    ):
        assert isinstance(
            heading, Heading
        ), "Heading must be an instance of hiway.units.Heading"

        self._log = logging.getLogger(self.__class__.__name__)
        self._id = uuid.uuid4()

        self._start_pos = pos
        self._start_heading = heading
        self._bullet_client = bullet_client  # TODO: Remove this post-lidar dep. inj.
        self._showbase = showbase
        self._scene_np = scene_np
        self._ogm = None
        self._rgb = None
        self._lidar = None
        self._lidar_offset = numpy.array([0, 0, 0])
        self._color = color
        self._pending_activations = _Activations()

        self._track_path = track_path
        self._driven_path = []

        self._build_model(pos, heading, showbase, bullet_client, vehicle_filepath)

    def _build_model(
        self, pos, heading: Heading, showbase, bullet_client, vehicle_filepath
    ):
        with pkg_resources.path(models, "muscle_car.glb") as path:
            self._np = showbase.loader.loadModel(str(path.absolute()))

        self._np.setPosHpr(*pos, heading.as_panda3d, 0, 0)

        # Material information can be lost during Blender export->glb->SMARTS import
        # Safer to directly create new material in SMARTS and override all loaded materials
        new_material = Material()
        new_material.setBaseColor(self._color)

        # When metallic is set to 1, diffuse is turned off to (0, 0, 0, 0) for metals
        # Set the alpha value back to 1 to prevent the object from disappearing
        if new_material.getMetallic() > 0:
            new_material.setDiffuse((0, 0, 0, 1))

        # Create one if no material exists, otherwise override existing materials
        self._np.setMaterial(new_material, 1)

        # Bullet Vehicle
        self._bullet_vehicle = BulletVehicle(
            pos, heading, bullet_client, vehicle_filepath
        )

    @property
    def length(self):
        return self._bullet_vehicle.chassis_dimensions[0]

    @property
    def width(self):
        return self._bullet_vehicle.chassis_dimensions[1]

    @property
    def height(self):
        return self._bullet_vehicle.chassis_dimensions[2]

    # TODO: We should remove this, and not be exposing bullet_id
    @property
    def bullet_id(self):
        return self._bullet_vehicle._bullet_id

    @property
    def driven_path(self):
        return self._driven_path

    def teardown(self):
        self._pending_activations = _Activations()
        self._driven_path = []

        # Clear tasks
        self._showbase.taskMgr.remove(f"{self._id}-ogm-camera-follow")
        self._showbase.taskMgr.remove(f"{self._id}-rgb-camera-follow")
        self._showbase.taskMgr.remove(f"{self._id}-lidar-follow")

        if self._ogm:
            self._ogm.teardown()

        if self._rgb:
            self._rgb.teardown()

        self._bullet_vehicle.teardown()
        self._np.removeNode()

    def init_observation_ogm(self, width, height, resolution):
        assert self._ogm is None, "OGM has already been initialized"
        self._ogm = self._build_offscreen_camera(
            "ogm", RenderMasks.OCCUPANCY_HIDE, width, height, resolution
        )

        task = partial(self._camera_follow_vehicle, camera_np=self._ogm.camera_np)
        self._showbase.taskMgr.add(
            task, f"{self._id}-ogm-camera-follow", sort=0, priority=100
        )

    def init_observation_rgb(self, width, height, resolution):
        assert self._rgb is None, "RGB has already been initialized"
        self._rgb = self._build_offscreen_camera(
            "rgb", RenderMasks.RGB_HIDE, width, height, resolution
        )

        task = partial(self._camera_follow_vehicle, camera_np=self._rgb.camera_np)
        self._showbase.taskMgr.add(
            task, f"{self._id}-rgb-camera-follow", sort=0, priority=100
        )

    def init_observation_lidar(
        self, sensor_params: SensorParams = None, lidar_offset=(0, 0, 1)
    ):
        self._lidar_offset = numpy.array(lidar_offset)
        assert self._lidar is None, "Lidar has already been initialized"

        self._lidar = Lidar(
            self.position + self._lidar_offset, sensor_params, self._bullet_client
        )
        self._showbase.taskMgr.add(
            self._lidar_follow_vehicle, f"{self._id}-lidar-follow", sort=0, priority=100
        )

    def calc_observation_ogm(self):
        assert self._ogm is not None, "OGM has not been initialized"

        ram_image = self._wait_for_ram_image(self._ogm, format="A")
        mem_view = memoryview(ram_image)
        grid = numpy.frombuffer(mem_view, numpy.uint8)
        grid.shape = (self._ogm.tex.getYSize(), self._ogm.tex.getXSize(), 1)
        grid = numpy.flipud(grid)
        grid = grid.clip(min=0, max=1).astype(numpy.int8)
        grid *= 100  # full confidence on known cells

        lens = self._ogm.camera_np.node().getLens(0)
        resolution = round(lens.getFilmSize().x / grid.shape[0], 5)

        metadata = OccupancyGridMetadata(
            created_at=int(time.time()),
            resolution=resolution,
            width=grid.shape[0],
            height=grid.shape[1],
        )
        return OccupancyGridMap(data=grid, metadata=metadata)

    def calc_observation_rgb(self):
        assert self._rgb is not None, "RGB has not been initialized"

        ram_image = self._wait_for_ram_image(self._rgb, format="RGB")
        mem_view = memoryview(ram_image)
        image = numpy.frombuffer(mem_view, numpy.uint8)
        image.shape = (self._rgb.tex.getYSize(), self._rgb.tex.getXSize(), 3)

        image = numpy.flipud(image)
        return image

    def calc_observation_lidar(self):
        return self._lidar.compute_point_cloud()

    def _wait_for_ram_image(self, cam: OffscreenCamera, format, retries=100):
        # Rarely, we see dropped frames where an image is not available
        # for our observation calculations.
        #
        # We've seen this happen fairly reliable when we are initializing
        # a multi-agent + multi-instance simulation.
        #
        # To deal with this, we can try to force a render and block until
        # we are fairly certain we have an image in ram to return to the user
        for i in range(retries):
            if cam.tex.mightHaveRamImage():
                break
            self._log.debug(
                f"No image available (attempt {i}/{retries}), forcing a render"
            )
            region = cam.buffer.getDisplayRegion(0)
            region.window.engine.renderFrame()

        assert cam.tex.mightHaveRamImage()
        ram_image = cam.tex.getRamImageAs(format)
        assert ram_image is not None
        return ram_image

    def _build_offscreen_camera(self, name, mask, width, height, resolution):
        # setup buffer
        win_props = WindowProperties.size(width, height)
        fb_props = FrameBufferProperties()
        fb_props.setRgbColor(True)
        fb_props.setRgbaBits(8, 8, 8, 1)
        fb_props.setDepthBits(0)

        buffer = self._showbase.win.engine.makeOutput(
            self._showbase.pipe,
            "{}-buffer".format(name),
            -100,
            fb_props,
            win_props,
            GraphicsPipe.BFRefuseWindow,
            self._showbase.win.getGsg(),
            self._showbase.win,
        )

        # setup texture
        tex = Texture()
        region = buffer.getDisplayRegion(0)
        region.window.addRenderTexture(
            tex, GraphicsOutput.RTM_copy_ram, GraphicsOutput.RTP_color
        )

        # setup camera
        lens = OrthographicLens()
        lens.setFilmSize(width * resolution, height * resolution)

        camera_np = self._showbase.makeCamera(
            buffer, camName=name, scene=self._scene_np, lens=lens
        )
        camera_np.reparentTo(self._scene_np)

        # mask is set to make undesireable objects invisible to this camera
        camera_np.node().setCameraMask(camera_np.node().getCameraMask() & mask)

        return OffscreenCamera(camera_np, buffer, tex)

    # TODO: Determine if the vehicle follow code is async and could go out of sync.
    def _camera_follow_vehicle(self, task, camera_np):
        largest_dim = max(self._bullet_vehicle.chassis_dimensions[0:2])

        center = self.position
        camera_np.setPos(center[0], center[1], 20 * largest_dim)
        camera_np.lookAt(*center)
        camera_np.setH(self._np.getH())

        return task.cont

    def _lidar_follow_vehicle(self, task):
        self._lidar.origin = self.position + self._lidar_offset
        return task.cont

    @property
    def np(self):
        return self._np

    @property
    def bullet_vehicle(self):
        return self._bullet_vehicle

    def state(self):
        return VehicleState(
            heading=self.heading,
            speed=self._bullet_vehicle.speed,
            throttle=self.throttle,
            brake=self.brake,
            steering=self.steering,
            position=self.position,
            bounding_box=BoundingBox(
                width=self.width, length=self.length, height=self.height
            ),
        )

    @property
    def speed(self):
        return self._bullet_vehicle.speed

    @property
    def yaw_rate(self):
        return self._bullet_vehicle.yaw_rate

    @property
    def longitudinal_lateral_speed(self):
        return self._bullet_vehicle.longitudinal_lateral_speed

    @property
    def approx_max_speed(self):
        return self._bullet_vehicle.approx_max_speed

    @property
    def heading(self) -> Heading:
        _, heading = self._bullet_vehicle.position_and_heading
        return heading

    @property
    def position(self):
        pos, _ = self._bullet_vehicle.position_and_heading
        return pos

    @property
    def brake(self):
        return self._pending_activations.brake

    @property
    def throttle(self):
        return self._pending_activations.throttle

    @property
    def steering(self):
        return self._bullet_vehicle.steering

    @property
    def contact_points(self):
        return self._bullet_vehicle.contact_points

    def activate(self, throttle=None, brake=None, steering=None):
        if throttle is not None:
            self._pending_activations.throttle = throttle

        if brake is not None:
            self._pending_activations.brake = brake

        if steering is not None:
            self._pending_activations.steering = steering

    def sync_physics(self):
        self._bullet_vehicle.update(
            throttle=self._pending_activations.throttle or 0,
            brake=self._pending_activations.brake or 0,
            steering=self._pending_activations.steering or 0,
        )
        self._pending_activations = _Activations()

        pos, heading = self._bullet_vehicle.position_and_heading
        self._np.setPosHpr(*pos, heading.as_panda3d, 0, 0)

        self._append_driven_path(pos[:2])

    def _append_driven_path(self, pos):
        if not self._track_path:
            return

        if len(self._driven_path) > 0:
            if numpy.linalg.norm(self._driven_path[-1] - pos) > 3:
                self._driven_path += [pos]
        else:
            self._driven_path += [pos]
