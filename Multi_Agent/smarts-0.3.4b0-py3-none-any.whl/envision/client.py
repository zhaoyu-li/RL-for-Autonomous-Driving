import time
import uuid
import json
import logging
import threading
from queue import Queue
from typing import Union
from pathlib import Path

import websocket
import numpy as np

from smarts.core.utils import unpack
from . import types


class JSONEncoder(json.JSONEncoder):
    """This custom encoder is to support serializing more complex data from SMARTS
    including numpy arrays, NaNs, and Infinity which don't have standarized handling
    according to the JSON spec.
    """

    def default(self, obj):
        if isinstance(obj, float):
            if np.isposinf(obj):
                obj = "Infinity"
            elif np.isneginf(obj):
                obj = "-Infinity"
            elif np.isnan(obj):
                obj = "NaN"
            return obj
        elif isinstance(obj, list):
            return [self.default(x) for x in obj]
        elif isinstance(obj, np.bool_):
            return super().encode(bool(obj))
        elif isinstance(obj, np.ndarray):
            return self.default(obj.tolist())

        return super().default(obj)


class Client:
    """Used to push state from SMARTS to Envision server while the simulation is
    running.
    """

    class QueueDone:
        pass

    def __init__(self, endpoint: str = None, output_dir: str = None):
        self._log = logging.getLogger(self.__class__.__name__)
        client_id = str(uuid.uuid4())[:8]

        if endpoint is None:
            endpoint = "ws://localhost:8081"

        path = None
        if output_dir:
            output_dir = Path(f"{output_dir}/{int(time.time())}")
            output_dir.mkdir(parents=True, exist_ok=True)
            path = (output_dir / client_id).with_suffix(".jsonl")

        self._state_queue = Queue()
        self._thread = self._connect(
            endpoint=f"{endpoint}/simulations/{client_id}/broadcast",
            path=path,
            queue=self._state_queue,
        )
        self._thread.start()

    @staticmethod
    def read_and_send(
        path: str, endpoint: str = "ws://localhost:8081", timestep_sec: float = 0.1,
    ):
        client = Client(endpoint=endpoint)
        with open(path, "r") as f:
            for line in f:
                line = line.rstrip("\n")
                time.sleep(timestep_sec)
                client._send_raw(line)

            client.teardown()
            logging.info("Finished Envision data replay")

    def _connect(self, endpoint, path, queue):
        def optionally_serialize_and_write(state: Union[types.State, str], ws, file_):
            # if not already serialized
            if not isinstance(state, str):
                state = unpack(state)
                state = json.dumps(state, cls=JSONEncoder)

            ws.send(state)

            if file_:
                file_.write(f"{state}\n")

        def on_close(ws):
            self._log.debug("Connection to Envision closed")

        def on_error(ws, error):
            self._log.info("Unable to connect to Envision")

        def on_open(ws):
            self._log.debug("Connection to Envision opened")

            file_ = path.open("w", encoding="utf-8") if path else None

            try:
                while True:
                    state = queue.get()
                    if type(state) is Client.QueueDone:
                        ws.close()
                        break

                    optionally_serialize_and_write(state, ws, file_)
            finally:
                if file_:
                    file_.close()

        def run_socket(endpoint):
            ws = websocket.WebSocketApp(
                endpoint, on_error=on_error, on_close=on_close, on_open=on_open
            )
            ws.run_forever()

        return threading.Thread(
            target=run_socket,
            args=(endpoint,),
            daemon=True,  # If False, the proc will not terminate until this thread stops
        )

    def send(self, state: types.State):
        self._state_queue.put(state)

    def _send_raw(self, state: str):
        """Skip serialization if we already have serialized data. This is useful if
        we are reading from file and forwarding through the websocket.
        """
        self._state_queue.put(state)

    def teardown(self):
        if not self._thread:
            return

        self._state_queue.put(Client.QueueDone())
        self._thread.join()
        self._thread = None
