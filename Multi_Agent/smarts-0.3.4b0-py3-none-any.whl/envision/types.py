from enum import Enum
from typing import NamedTuple, Dict, Sequence, Tuple, Optional

from smarts.core.waypoints import Waypoint


class TrafficActorType(str, Enum):
    SocialVehicle = "social_vehicle"
    SocialAgent = "social_agent"
    Agent = "agent"


class VehicleType(str, Enum):
    Truck = "truck"
    Car = "car"


class TrafficActorState(NamedTuple):
    actor_type: TrafficActorType
    vehicle_type: VehicleType
    position: Tuple[float, float, float]
    heading: float
    waypoint_paths: Sequence = []
    driven_path: Sequence = []
    point_cloud: Sequence = []
    start_pos: Tuple[float, float, float] = None
    end_pos: Tuple[float, float, float] = None
    end_waypoint: Waypoint = None


class State(NamedTuple):
    traffic: Dict[str, TrafficActorState]
    geom_road_id: str
    # sequence of x, y coordinates
    bubbles: Sequence[Sequence[Tuple[float, float]]]
    scores: Dict[str, float]
    road_network_bounding_box: Tuple[float, float, float, float]
