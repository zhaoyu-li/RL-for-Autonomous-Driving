# Based heavily on gym/envs/registration.py (MIT licensed)
#   but more generic
import re
import importlib

# gym's name constraints
name_constraint_regex = re.compile(r"^(?:[\w:-]+\/)?([\w:.-]+)-v(\d+)$")


def find_attribute_spec(name):
    """ Finds the attribute specification from a reachable module.

    name: The module and attribute name (i.e. smarts.core.lidar:Lidar, ...)
    """
    module_name, attribute_name = name.split(":")
    module = importlib.import_module(module_name)
    attribute_spec = getattr(module, attribute_name)
    return attribute_spec


class ClassFactory:
    def __init__(self, locator, entry_point=None, **kwargs):
        self.locator = locator
        self.entry_point = entry_point
        self._kwargs = kwargs

        if self.entry_point is None:
            raise EnvironmentError(
                f"Entry-point is empty for: '{self.locator}'. Provide an entry-point"
            )

        reg_match = name_constraint_regex.search(locator)
        if not reg_match:
            raise ValueError(
                f"Cannot register improper key name: {locator}. Use form {name_constraint_regex.pattern}"
            )

    def make(self, **kwargs):
        if self.entry_point is None:
            raise AttributeError(
                f"Entry-point does not exist for name `{self.locator}`"
            )
        _kwargs = self._kwargs.copy()
        _kwargs.update(kwargs)
        if callable(self.entry_point):
            instance = self.entry_point(**_kwargs)
        else:
            type_spec = find_attribute_spec(self.entry_point)
            instance = type_spec(**_kwargs)

        return instance

    def __repr__(self):
        return f"(n:{self.locator}|ep:{self.entry_point}|kwargs:{self._kwargs})"


class ClassRegister:
    def __init__(self):
        self.index = {}

    def register(self, locator, entry_point=None, **kwargs):
        if locator not in self.index:
            self.index[locator] = ClassFactory(locator, entry_point, **kwargs)

    def find_factory(self, path):
        if ":" in path:
            mod_name, locator = path.split(":")
            try:
                importlib.import_module(mod_name)
            except ImportError:
                raise ImportError(
                    f"A module `{mod_name}` was specified for the name `{locator}` but was not found"
                )
        else:
            locator = path

        reg_match = name_constraint_regex.search(locator)
        if not reg_match:
            raise ValueError(
                f"Improper attribute name: `{locator}`. Use form: {name_constraint_regex.pattern}"
            )
        try:
            return self.index[locator]
        except KeyError:
            raise NameError(f"Target locator not registered in lookup: {locator}")

    def make(self, locator, **kwargs):
        factory = self.find_factory(locator)
        instance = factory.make(**kwargs)
        return instance

    def all(self):
        return self.index.values()
