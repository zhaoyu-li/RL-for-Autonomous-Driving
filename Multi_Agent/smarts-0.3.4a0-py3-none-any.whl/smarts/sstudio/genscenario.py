"""
This script provides a Python interface to generate scenario artifacts. This includes
route files (sumo *.rou.xml), missions, and bubbles.
"""

import os
import pickle
import logging
from typing import Sequence, Tuple, Any
from dataclasses import replace

import sh

from . import types
from .generators import TrafficGenerator

logger = logging.getLogger(__file__)


def gen_traffic(
    scenario: str,
    traffic: types.Traffic,
    name: str = None,
    output_dir: str = None,
    seed: int = 42,
    overwrite: bool = False,
):
    """
    Generates the traffic routes for the given scenario. If the output directory is not
    provided, the scenario directory is used. If name is not provided the default is
    "routes".
    """
    assert name != "missions", "The name 'missions' is reserved for missions!"

    output_dir = os.path.join(output_dir or scenario, "traffic")
    os.makedirs(output_dir, exist_ok=True)

    generator = TrafficGenerator(scenario, overwrite=overwrite)
    saved_path = generator.plan_and_save(traffic, name, output_dir, seed=seed)

    if saved_path:
        logger.debug(f"Generated traffic for scenario={scenario}")


def gen_social_agent_missions(
    scenario: str,
    missions: Sequence,
    social_agent_actor: types.SocialAgentActor,
    name: str,
    seed: int = 42,
    overwrite: bool = False,
):
    """Generates the social agent missions for the given scenario."""

    output_dir = os.path.join(scenario, "social_agents")
    saved = _gen_missions(
        scenario=scenario,
        missions=missions,
        actor=social_agent_actor,
        name=name,
        output_dir=output_dir,
        seed=seed,
        overwrite=overwrite,
    )

    if saved:
        logger.debug(f"Generated social agent missions for scenario={scenario}")


def gen_missions(
    scenario: str, missions: Sequence, seed: int = 42, overwrite: bool = False,
):
    """Generates the ego agent missions for the given scenario."""

    saved = _gen_missions(
        scenario=scenario,
        missions=missions,
        actor=types.TrafficActor(name="car"),
        name="missions",
        output_dir=scenario,
        seed=seed,
        overwrite=overwrite,
    )

    if saved:
        logger.debug(f"Generated missions for scenario={scenario}")


def gen_group_laps(
    scenario: str,
    begin: Tuple[str, int, Any],
    end: Tuple[str, int, Any],
    grid_offset: int,
    used_lanes: int,
    vehicle_count: int,
    name: str,
    num_laps: int = 3,
    output_dir: str = None,
    seed: int = 42,
):
    """ Generates missions that start with a grid offset at the startline and do a number
    of laps until finishing.

    begin: the edge and offset of the first vehicle
    end: the edge and offset of the finishline
    grid_offset: the F1 starting line staggered offset disadvantage imposed per vehicle
    used_lanes: the number of lanes used for start from the innermost lane
    vehicle_count: the number of vehicles to use
    num_laps: the amount of laps before finishing
    """

    start_edge_id, start_lane, start_offset = begin
    end_edge_id, end_lane, end_offset = end

    missions = []
    for i in range(vehicle_count):

        s_lane = (start_lane + i) % used_lanes
        missions.append(
            types.LapMission(
                types.Route(
                    begin=(start_edge_id, s_lane, start_offset - grid_offset * i,),
                    end=(end_edge_id, (end_lane + i) % used_lanes, end_offset),
                ),
                num_laps=num_laps,
                # route_length=route_length,
            )
        )

    saved = gen_missions(scenario=scenario, missions=missions, seed=seed,)


def _gen_missions(
    scenario: str,
    missions: Sequence,
    actor: types.Actor,
    name: str,
    output_dir: str,
    seed: int = 42,
    overwrite: bool = False,
):
    """Generates a route file to represent missions (a route per mission). Will create
    the output_dir if it doesn't exist already.
    """

    generator = TrafficGenerator(scenario)

    def resolve_mission(mission):
        route = getattr(mission, "route", None)
        if route:
            route = generator.resolve_route(route)
            mission = replace(mission, route=route)

        return mission

    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, name + ".pkl")

    if os.path.exists(output_path) and not overwrite:
        return False

    missions = [
        types._ActorAndMission(actor=actor, mission=resolve_mission(mission))
        for mission in missions
    ]
    with open(output_path, "wb") as f:
        pickle.dump(missions, f)


def gen_bubbles(scenario: str, bubbles: Sequence[types.Bubble]):
    output_path = os.path.join(scenario, "bubbles.pkl")
    with open(output_path, "wb") as f:
        pickle.dump(bubbles, f)
