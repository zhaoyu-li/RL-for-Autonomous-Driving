import re
import uuid
import random
import itertools
import collections
from dataclasses import dataclass, field
from typing import Sequence, Tuple, Dict, Any, Union

import numpy as np
from shapely.geometry import Polygon, MultiPolygon
from shapely.ops import unary_union, cascaded_union
from yattag import Doc, indent

from smarts.core.waypoints import Waypoint, Waypoints
from smarts.core.sumo_road_network import SumoRoadNetwork


class _SumoParams(collections.Mapping):
    """For some Sumo params (e.x. LaneChangingModel) the arguments are in title case
    with a given prefix. Subclassing this class allows for an automatic way to map
    between PEP8-compatible naming and Sumo's.
    """

    def __init__(self, prefix, whitelist=[], **kwargs):
        def snake_to_title(word):
            return "".join(x.capitalize() or "_" for x in word.split("_"))

        # XXX: On rare occasions sumo doesn't respect their own conventions
        #      (e.x. junction model's impatience).
        self._params = {key: kwargs.pop(key) for key in whitelist if key in kwargs}

        for key, value in kwargs.items():
            self._params[f"{prefix}{snake_to_title(key)}"] = value

    def __iter__(self):
        return iter(self._params)

    def __getitem__(self, key):
        return self._params[key]

    def __len__(self):
        return len(self._params)

    def __hash__(self):
        return hash(frozenset(self._params.items()))

    def __eq__(self, other):
        return self.__class__ == other.__class__ and hash(self) == hash(other)


class LaneChangingModel(_SumoParams):
    """Models how the actor acts with respect to lane changes."""

    def __init__(self, **kwargs):
        super().__init__("lc", **kwargs)


class JunctionModel(_SumoParams):
    """Models how the actor acts with respect to waiting at junctions."""

    def __init__(self, **kwargs):
        super().__init__("jm", whitelist=["impatience"], **kwargs)


@dataclass(frozen=True)
class Distribution:
    """A gaussian distribution used for randomized parameters."""

    mean: float
    sigma: float

    def sample(self):
        """The next sample from the distribution."""
        return random.gauss(self.mean, self.sigma)


@dataclass(frozen=True)
class Actor:
    pass


@dataclass(frozen=True, unsafe_hash=True)
class TrafficActor(Actor):
    """Used as a description/spec for traffic actors (e.x. Vehicles, Pedestrians,
    etc). The defaults provided are for a car, but the name is not set to make it
    explicit that you actually want a car.
    """

    name: str
    accel: float = 2.6
    decel: float = 4.5
    speed: Distribution = Distribution(mean=1.0, sigma=0.1)
    imperfection: Distribution = Distribution(mean=0.5, sigma=0)
    min_gap: Distribution = Distribution(mean=2.5, sigma=0)
    vehicle_type: str = "passenger"
    lane_changing_model: LaneChangingModel = field(
        default_factory=LaneChangingModel, hash=False
    )
    junction_model: JunctionModel = field(default_factory=JunctionModel, hash=False)

    @property
    def id(self) -> str:
        """The identifier tag of the traffic actor."""

        return "actor-{}-{}".format(self.name, hash(self))


@dataclass(frozen=True)
class SocialAgentActor(Actor):
    """Used as a description/spec for zoo traffic actors. These actors use a
    pre-trained model to understand how to act in the environment.
    """

    name: str
    # A pre-registered zoo identifying tag you provide to help SMARTS identify the
    # prefab of a social agent.
    agent_locator: str


@dataclass(frozen=True)
class AgentActor(Actor):
    pass


@dataclass(frozen=True)
class Route:
    """A route is represented by begin and end edge IDs, with an optional list of
    itermediary edge IDs. When an intermediary is not specified the router will
    decide what it should be.
    """

    ## edge, lane index, offset
    begin: Tuple[str, int, Any]
    ## edge, lane index, offset
    end: Tuple[str, int, Any]

    # Edges we want to make sure this route includes
    intermediaries: Tuple[str, ...] = field(default_factory=tuple)

    @property
    def id(self) -> str:
        return "route-{}-{}-{}".format(
            "_".join(map(str, self.begin)), "_".join(map(str, self.end)), hash(self),
        )

    @property
    def edges(self):
        return (self.begin[0],) + self.intermediaries + (self.end[0],)


@dataclass(frozen=True)
class RandomRoute:
    """An alternative to types.Route which specifies to sstudio to generate a random
    route.
    """

    id: str = field(default_factory=lambda: f"random-route-{uuid.uuid4()}")


@dataclass(frozen=True)
class Flow:
    """A route with an actor type emitted at a given rate."""

    route: Route
    rate: float  # vehicles/hour
    begin: float = 0
    # XXX: Defaults to 1 hour of traffic. We may want to change this to be "continual
    #      traffic", effectively an infinite end.
    end: float = 1 * 60 * 60  # seconds
    actors: Dict[TrafficActor, float] = field(default_factory=dict)

    @property
    def id(self) -> str:
        return "flow-{}-{}".format(
            self.route.id, str(hash(frozenset(self.actors.items()))),
        )

    def __hash__(self):
        # Custom hash since self.actors is not hashable, here we first convert to a
        # frozenset.
        return hash((self.route, self.rate, frozenset(self.actors.items())))

    def __eq__(self, other):
        return self.__class__ == other.__class__ and hash(self) == hash(other)


@dataclass(frozen=True)
class Traffic:
    flows: Sequence[Flow]


@dataclass(frozen=True)
class Mission:
    route: Route


@dataclass(frozen=True)
class EndlessMission:
    begin: Tuple[str, int, float]


@dataclass(frozen=True)
class LapMission:
    route: Route
    num_laps: int


@dataclass(frozen=True)
class Zone:
    def to_geometry(self, road_network: SumoRoadNetwork) -> Polygon:
        raise NotImplementedError


@dataclass(frozen=True)
class MapZone(Zone):
    start: Tuple[str, int, float]
    length: float
    n_lanes: 2

    def to_geometry(self, road_network: SumoRoadNetwork) -> Polygon:
        lane_shapes = []
        edge_id, lane_idx, offset = self.start
        edge = road_network.edge_by_id(edge_id)
        for lane_idx in range(lane_idx, lane_idx + self.n_lanes):
            lane = edge.getLanes()[lane_idx]
            lane_shape = SumoRoadNetwork.buffered_lane_or_edge(lane, width=3.5)
            lane_shape = road_network.split_lane_shape_at_offset(
                Polygon(lane_shape), lane, offset
            )[1]
            lane_shape = road_network.split_lane_shape_at_offset(
                lane_shape, lane, offset + self.length
            )[0]
            lane_shapes.append(lane_shape)

        geom = cascaded_union(MultiPolygon(lane_shapes))
        return geom


@dataclass(frozen=True)
class PositionalZone(Zone):
    # center point
    pos: Tuple[float, float]
    size: Tuple[float, float]

    def to_geometry(self, road_network: SumoRoadNetwork) -> Polygon:
        w, h = self.size
        p0 = (self.pos[0] - w / 2, self.pos[1] - h / 2)  # min
        p1 = (self.pos[0] + w / 2, self.pos[1] + h / 2)  # max
        return Polygon([p0, (p0[0], p1[1]), p1, (p1[0], p0[1])])


@dataclass(frozen=True)
class Bubble:
    zone: Zone
    # TODO: Generalize to any `Actor`
    actor: SocialAgentActor
    margin: float = 0  # used for "airlocking"


@dataclass(frozen=True)
class _ActorAndMission:
    actor: Actor
    mission: Union[Mission, EndlessMission, LapMission]
