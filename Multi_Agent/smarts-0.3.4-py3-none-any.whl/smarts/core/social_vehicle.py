import math
from collections import namedtuple
from dataclasses import dataclass
import importlib.resources as pkg_resources

import numpy
import pybullet
import pybullet_utils.bullet_client as bc
from direct.showbase.ShowBase import ShowBase
from panda3d.core import Material

from . import models
from .sumo_traffic_simulation import TrafficSimVehicle
from .units import Heading
from .utils import fast_quaternion_from_angle
from .vehicle import Vehicle


SocialVehicleState = namedtuple(
    "SocialVehicleState",
    ["id", "heading", "speed", "position", "lane_id", "lane_index", "bounding_box",],
)

BoundingBox = namedtuple("BoundingBox", ["width", "length", "height"])


@dataclass
class VehicleConfig:
    vehicle_type: str
    color: tuple
    dimension: tuple
    glb_model: str


# A mapping of sumo vehicle class and vehicle config
# dimension should match with the object dimensions in the corresponding blender file
vehicle_configs = {
    "passenger": VehicleConfig(
        "car", (1, 1, 0.2, 1), (1.47, 3.68, 1.0), "simple_car.glb"
    ),
    "truck": VehicleConfig("truck", (0.2, 1, 0.2, 1), (1.91, 4.33, 1.89), "truck.glb"),
}


class BulletBoxShape:
    def __init__(self, bbox, bullet_client):
        self._client = bullet_client

        width, length, height = bbox
        collision_box = bullet_client.createCollisionShape(
            shapeType=pybullet.GEOM_BOX,
            halfExtents=(width * 0.5, length * 0.5, height * 0.5),
        )

        self._bullet_id = bullet_client.createMultiBody(1, collision_box)

    def reset_position_heading(self, position, heading: Heading):
        assert isinstance(heading, Heading)
        orientation = fast_quaternion_from_angle(heading.as_bullet)
        self._client.resetBasePositionAndOrientation(
            self._bullet_id, position, orientation
        )

    def teardown(self):
        self._client.removeBody(self._bullet_id)
        self._bullet_id = None


class SocialVehicle:
    def __init__(
        self,
        vehicle_id,
        showbase: ShowBase,
        bullet_client: bc.BulletClient,
        speed=0.0,
        np=None,
        bullet_body=None,
        vehicle_type="passenger",
    ):
        config = vehicle_configs[vehicle_type]

        assert vehicle_id is not None
        self._id = vehicle_id
        self._speed = speed

        self._dim = config.dimension
        self._sumo_pos = None
        self._np = np

        self._vehicle_type = config.vehicle_type
        if not self._np:
            with pkg_resources.path(models, config.glb_model) as path:
                self._np = showbase.loader.loadModel(str(path.absolute()))
            self._np.setName("vehicle-%s" % vehicle_id)

            # Material information can be lost during Blender export->glb->SMARTS import
            # Safer to directly create new material in SMARTS and override all loaded materials
            new_material = Material()
            new_material.setBaseColor(config.color)

            # When metallic is set to 1, diffuse is turned off to (0, 0, 0, 0) for metals
            # Set the alpha value back to 1 to prevent the object from disappearing
            if new_material.getMetallic() > 0:
                new_material.setDiffuse((0, 0, 0, 1))

            # Create one if no material exists, otherwise override existing materials
            self._np.setMaterial(new_material, 1)

        self._bullet_body = bullet_body or BulletBoxShape(self._dim, bullet_client)

    def __repr__(self):
        return f"""SocialVehicle({self.id},
  position={self.position},
  heading={self.heading},
  speed={self.speed},
  type={self.vehicle_type},
  w={self.width},
  l={self.length},
  h={self.height}
)"""

    @property
    def id(self):
        return self._id

    # TODO: We should remove this, and not be exposing bullet_id
    @property
    def bullet_id(self):
        return self._bullet_body._bullet_id

    @property
    def np(self):
        return self._np

    @property
    def width(self):
        return self._dim[0]

    @property
    def length(self):
        return self._dim[1]

    @property
    def height(self):
        return self._dim[2]

    @property
    def position(self):
        if self._sumo_pos is not None:
            return self._sumo_pos
        else:
            x, y, _z = self._np.getBounds().getCenter()
            return numpy.array([x, y, 0])

    @property
    def heading(self) -> Heading:
        return Heading.from_panda3d(self._np.getH())

    @property
    def speed(self):
        return self._speed

    @property
    def bounding_box(self):
        return BoundingBox(width=self.width, length=self.length, height=self.height)

    @property
    def vehicle_type(self):
        return self._vehicle_type

    def state(self, lane_id, lane_index):
        return SocialVehicleState(
            id=self.id,
            heading=self.heading,
            speed=self.speed,
            position=self.position,
            lane_id=lane_id,
            lane_index=lane_index,
            bounding_box=self.bounding_box,
        )

    def teardown(self):
        self.np.removeNode()
        self._bullet_body.teardown()

    def update_from_traffic_sim(self, sumo_vehicle: TrafficSimVehicle):
        assert sumo_vehicle.vehicle_id == self._id

        heading = sumo_vehicle.heading
        x, y = sumo_vehicle.position
        self._sumo_pos = numpy.array([x, y, self._dim[2] * 0.5])

        # TODO: Sumo's position is front bumper, which is not the same as Panda's.
        #       Here we need to do a conversion.
        self._np.setPosHpr(*self._sumo_pos, heading.as_panda3d, 0, 0)
        self._bullet_body.reset_position_heading(self._sumo_pos, heading)
        self._speed = sumo_vehicle.speed
