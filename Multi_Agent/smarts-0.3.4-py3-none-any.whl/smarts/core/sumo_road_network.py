import sys
import os
import math
import logging
import re
import random
import typing
from collections import namedtuple

import numpy as np
from panda3d.core import CS_zup_right, Point3D, Triangulator3
from panda3d.egg import EggVertexPool, EggVertex, EggData, EggPolygon
from shapely import ops
from shapely.geometry import (
    Polygon,
    LineString,
    CAP_STYLE,
    JOIN_STYLE,
)

import trimesh
from trimesh.exchange import gltf

from .utils.math import vec_to_degrees, rotate_around_point
from .utils.sumo import sumolib
from sumolib.net.lane import Lane
from sumolib.net.edge import Edge


LaneData = namedtuple("LaneData", ["sumo_lane", "lane_speed"])


class GLBData:
    def __init__(self, bytes_):
        self._bytes = bytes_

    def write_glb(self, output_path):
        with open(output_path, "wb") as f:
            f.write(self._bytes)


class SumoRoadNetwork:
    def __init__(self, graph):
        self._log = logging.getLogger(self.__class__.__name__)
        self._graph = graph

    @classmethod
    def from_file(cls, net_file):
        # Connections to internal lanes are implicit. If `withInternal=True` is
        # set internal junctions and the connections from internal lanes are
        # loaded into the network graph.
        G = sumolib.net.readNet(net_file, withInternal=True)
        return SumoRoadNetwork(G)

    @property
    def graph(self):
        return self._graph

    def _compute_road_polygons(self, scale):
        lines = []
        for edge in self._graph.getEdges():
            for lane in edge.getLanes():
                lane_hwidth = lane.getWidth() * 0.5
                lane_line = lane.getShape()
                line = LineString(lane_line).buffer(
                    lane_hwidth * 0.95,  # Scale down to see spacing
                    cap_style=CAP_STYLE.square,
                    join_style=JOIN_STYLE.mitre,
                )

                lines.append(line)

        polys = list(ops.polygonize(lines))

        for node in self._graph.getNodes():
            line = node.getShape()
            if len(line) <= 2:
                self._log.debug(
                    "Skipping {}-type node with <= 2 vertices".format(node.getType())
                )
                continue

            polys.append(Polygon(line))

        return polys

    def _make_egg_from_polys(self, polygons):
        egg = EggData()
        egg.set_coordinate_system(CS_zup_right)

        vertex_pool = EggVertexPool("road_network_vpool")
        for poly in polygons:
            egg_poly = EggPolygon()

            # shapely gives us points in the wrong direction,
            # we reverse so that geometry is visible
            for x, y in reversed(poly.exterior.coords):
                new_egg_vertex = EggVertex()
                new_egg_vertex.set_pos(Point3D(x, y, 0.0))

                # only add this new vertex to the pool if there
                # doesn't exist one that matches this one
                egg_vertex = vertex_pool.create_unique_vertex(new_egg_vertex)
                egg_poly.add_vertex(egg_vertex)

            egg_poly.triangulate_into(egg, convex_also=True)

        egg.add_child(vertex_pool)
        return egg

    def _make_glb_from_polys(self, polygons):
        scene = trimesh.Scene()
        for poly in polygons:
            triangulator = Triangulator3()

            for x, y in reversed(poly.exterior.coords):
                vertex = (x, y, 0)
                idx = triangulator.addVertex(vertex)
                triangulator.addPolygonVertex(idx)

            triangulator.triangulate()

            vertices = []
            # Trimesh's API require a list of vertices and a list of faces, where each
            # face contains three indexes into the vertices list. Ideally, the vertices
            # are all unique and the faces list references the same indexes as needed.
            # However, Panda3D's API does not provide this sort of access, so we duplicate
            # the vertices as necessary to have the faces be a consecutive list of unique
            # indexes (e.g. [[0, 1, 2], [3, 4, 5], ...]). We could workaround this, but
            # the additional memory overhead is fine for now.
            for i in range(triangulator.getNumTriangles()):
                triangle_vertices = [
                    tuple(triangulator.getVertex(triangulator.getTriangleV0(i))),
                    tuple(triangulator.getVertex(triangulator.getTriangleV1(i))),
                    tuple(triangulator.getVertex(triangulator.getTriangleV2(i))),
                ]

                vertices.extend(triangle_vertices)

            faces = [
                (idx, idx + 1, idx + 2)
                for idx in range(0, triangulator.getNumTriangles() * 3, 3)
            ]

            if not (vertices and faces):
                # TODO: Figure out why we can get here.
                continue

            mesh = trimesh.Trimesh(vertices=vertices, faces=faces,)

            # https://github.com/mikedh/trimesh/issues/523
            mesh.visual = trimesh.visual.TextureVisuals(
                material=trimesh.visual.material.PBRMaterial()
            )

            # Internals of trimesh (https://git.io/JvbFH) divide by the data type's max
            mesh.visual.material.baseColorFactor = np.array(
                [180, 180, 180, 255], dtype=np.uint8
            )

            # TODO: Use one mesh to describe all road geometry
            scene.add_geometry(mesh)

        # Trimesh doesn't support a coordinate-system="z-up" configuration, so we
        # have to apply the transformation manually.
        scene.apply_transform(
            trimesh.transformations.rotation_matrix(math.pi / 2, [-1, 0, 0])
        )
        scene.apply_transform(
            trimesh.transformations.rotation_matrix(math.pi / 2, [0, -1, 0])
        )
        return GLBData(gltf.export_glb(scene, include_normals=True))

    def build_egg(self, scale=1) -> EggData:
        polys = self._compute_road_polygons(scale)
        return self._make_egg_from_polys(polys)

    def build_glb(self, scale=1) -> GLBData:
        polys = self._compute_road_polygons(scale)
        return self._make_glb_from_polys(polys)

    def edge_by_id(self, edge_id):
        return self._graph.getEdge(edge_id)

    def lane_by_id(self, lane_id):
        return self._graph.getLane(lane_id)

    def lane_vector_at_offset(self, lane: Lane, start_offset: float) -> np.ndarray:
        """Computes the lane direction vector at the given offset into the road."""

        add_offset = 1
        end_offset = start_offset + add_offset  # a little further down the lane
        lane_length = lane.getLength()

        if end_offset > lane_length + add_offset:
            raise ValueError(
                "Offset %s goes out farther than end of lane: %s, %s"
                % (end_offset, lane_length, lane)
            )

        p1 = self.world_coord_from_offset(lane, start_offset)
        p2 = self.world_coord_from_offset(lane, end_offset)

        return p2 - p1

    @staticmethod
    def buffered_lane_or_edge(
        lane_or_edge: typing.Union[Edge, Lane], width: float = 1.0
    ):
        left_side = sumolib.geomhelper.move2side(lane_or_edge.getShape(), -width / 2)
        right_side = sumolib.geomhelper.move2side(lane_or_edge.getShape(), width / 2)

        # convert to counter-clockwise
        buffered_shape = [left_side[0]] + right_side + left_side[::-1][:-1]
        return buffered_shape

    def lane_data_for_lane(self, lane):
        lane_speed = lane.getSpeed() * 3.6  # m/s -> km/h
        return LaneData(sumo_lane=lane, lane_speed=lane_speed)

    def nearest_lane(self, point, radius=10) -> Lane:
        """
        Args:
          point: (x, y) find the nearest lane to this coordinate
          radius: max distance to search around point for a lane
        """

        x, y = point
        candidate_lanes = self._graph.getNeighboringLanes(
            x, y, r=radius, includeJunctions=True, allowFallback=False
        )

        if len(candidate_lanes) == 0:
            return None

        candidate_lanes.sort(key=lambda lane_dist_tup: lane_dist_tup[1])

        # we've checked that we have at least one
        return candidate_lanes[0][0]

    def lane_center_at_point(self, lane: Lane, point) -> np.ndarray:
        lane_offset = self.offset_into_lane(lane, point)
        lane_center_at_offset = self.world_coord_from_offset(lane, lane_offset)
        return lane_center_at_offset

    def world_to_lane_coord(self, lane: Lane, point) -> np.ndarray:
        """
        Maps a world coordinate to a lane local coordinate

        Args:
          lane: sumo lane object
          point: (x, y) world space coordinate

        Returns:
          np.array([u, v]) where
              u is meters into the lane,
              v is signed distance from center (right of center is negative)
        """

        u = self.offset_into_lane(lane, point)
        lane_vector = self.lane_vector_at_offset(lane, u)
        lane_normal = np.array([-lane_vector[1], lane_vector[0]])

        lane_center_at_u = self.world_coord_from_offset(lane, u)
        offcenter_vector = np.array(point) - lane_center_at_u

        v_sign = np.sign(np.dot(offcenter_vector, lane_normal))
        v = np.linalg.norm(offcenter_vector) * v_sign

        return np.array([u, v])

    def offset_into_lane(self, lane, point):
        """
        Calculate how far (in meters) into the lane the given point is

        Args:
          point: (x, y) find the position on the lane to this coordinate
          lane: sumo network lane

        Returns:
          offset_into_lane: meters from start of lane
        """
        lane_shape = lane.getShape(True)

        offset_into_lane = sumolib.geomhelper.polygonOffsetWithMinimumDistanceToPoint(
            point, lane_shape, perpendicular=True
        )

        return offset_into_lane

    def split_lane_shape_at_offset(
        self, lane_shape: Polygon, lane: Lane, offset: float
    ):
        width_2 = lane.getWidth()
        point = self.world_coord_from_offset(lane, offset)
        lane_vec = self.lane_vector_at_offset(lane, offset)

        perp_vec_right = rotate_around_point(lane_vec, np.pi / 2, origin=(0, 0))
        perp_vec_right = (
            perp_vec_right / np.linalg.norm(perp_vec_right) * width_2 + point
        )

        perp_vec_left = rotate_around_point(lane_vec, -np.pi / 2, origin=(0, 0))
        perp_vec_left = perp_vec_left / np.linalg.norm(perp_vec_left) * width_2 + point

        split_line = LineString([perp_vec_left, perp_vec_right])
        return ops.split(lane_shape, split_line)

    def world_coord_from_offset(self, lane: Lane, offset) -> np.ndarray:
        """
        Convert offset into lane to world coordinates

        Args:
          offset: meters into the lane
          lane: sumo network lane

        Returns:
          np.array([x, y]): coordinates in world space
        """
        lane_shape = lane.getShape(False)

        position_on_lane = sumolib.geomhelper.positionAtShapeOffset(lane_shape, offset)

        return np.array(position_on_lane)

    def road_nodes_with_triggers(self):
        """
        Scan the road network for any nodes with ID's that match the form:

            .*=trigger[<spawn_node_id_1>@<spawn_node_id_2>@...]

        A node with an ID with this pattern signals to the simulator that
        when an agent comes within some radius of this node, we should spawn
        social vehicles at the listed spawn nodes

        Returns:
          [(trigger_node, [spawn_nodes])]: list of all trigger nodes and their
                                           spawn nodes in the network.
        """
        nodes = self._graph.getNodes()
        nodes_with_triggers = []
        for node in nodes:
            # example node id with trigger:
            #  'gneJ2=trigger[source1@source2@source3]'
            matches = re.match(r".*=trigger\[(.*)\]", node.getID())
            if matches is None:
                continue

            spawn_node_ids = matches.group(1).split("@")

            for spawn_node_id in spawn_node_ids:
                # verify that these spawn nodes exist
                assert self._graph.hasNode(spawn_node_id)

            spawn_nodes = [self._graph.getNode(s) for s in spawn_node_ids]
            nodes_with_triggers.append((node, spawn_nodes))

        return nodes_with_triggers

    def random_route_starting_at_edge(self, edge, max_route_len=10):
        route = []
        curr_edge = edge
        while len(route) < max_route_len:
            route.append(curr_edge.getID())

            next_edges = list(curr_edge.getOutgoing().keys())
            if not next_edges:
                break

            curr_edge = random.choice(next_edges)

        return route

    def random_route_starting_at_node(self, node, max_route_len=10):
        route = []

        if not node.getOutgoing():
            # this node is terminating
            return route

        edge = random.choice(node.getOutgoing())
        return self.random_route_starting_at_edge(edge, max_route_len)

    def random_route(self, max_route_len=10):
        edge = random.choice(self._graph.getEdges(False))
        return self.random_route_starting_at_edge(edge, max_route_len)

    def shortest_route(self, from_edge, to_edge):
        route, _ = self._graph.getShortestPath(from_edge, to_edge)
        if not route:
            return []

        edges = []
        for curr_edge, next_edge in zip(route, route[1:] + (None,)):
            edges.append(curr_edge)

            if next_edge is None:
                # We're at the end of the route
                return edges

            connections = curr_edge.getOutgoing()[next_edge]

            if connections:
                # XXX: This may not be the best connection to take. There may be a
                #      faster one, or an unobstructed one!
                connection = connections[0]
                edge = self.lane_by_id(connection.getViaLaneID()).getEdge()
                edges.append(edge)

        return edges
