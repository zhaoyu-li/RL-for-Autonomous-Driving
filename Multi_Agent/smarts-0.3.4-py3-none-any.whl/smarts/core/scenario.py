import os
import math
import glob
import pickle
import random
import logging
import uuid

import numpy as np

from functools import lru_cache
from itertools import cycle, product
from dataclasses import dataclass
from typing import Dict, Sequence, Tuple, Any

from .sumo_road_network import SumoRoadNetwork
from .waypoints import Waypoints
from .units import Heading
from .utils import vec_to_degrees
from .utils.sumo import sumolib
from smarts.sstudio import types as sstudio_types
from smarts.zoo.registry import make as make_social_agent


@dataclass(frozen=True)
class Start:
    position: Tuple[int, int]
    heading: Heading


@dataclass(frozen=True)
class Goal:
    def is_endless(self):
        return True

    def is_reached(self, vehicle):
        return False


@dataclass(frozen=True)
class EndlessGoal(Goal):
    pass


@dataclass(frozen=True)
class PositionalGoal(Goal):
    position: Tuple[int, int]
    # target_heading: Heading
    radius: float

    def is_endless(self):
        return False

    def is_reached(self, vehicle):
        a = vehicle.position
        b = self.position
        dist = math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2)
        return dist <= self.radius


@dataclass(frozen=True)
class Mission:
    start: Start
    goal: Goal

    @property
    def is_endless(self):
        return self.goal.is_endless()

    def is_complete(self, vehicle, distance_travelled):
        return self.goal.is_reached(vehicle)


@dataclass(frozen=True)
class LapMission:
    start: Start
    goal: Goal
    num_laps: int
    route_length: float

    @property
    def is_endless(self):
        return True

    def is_complete(self, vehicle, distance_travelled):
        return (
            self.goal.is_reached(vehicle)
            and distance_travelled > self.route_length * self.num_laps
        )


class Scenario:
    """
    The purpose of the Scenario is to provide an aggregate of all
    code/configuration/assets that is specialized to a scenario using SUMO.

    Scenario is `pickle`able, this is important for use with frameworks like Ray/rllib.

    >>> import pickle
    >>> scenario = Scenario("scenarios/loop")
    >>> unpickled_scenario = pickle.loads(pickle.dumps(scenario))
    >>> scenario.root_filepath == unpickled_scenario.root_filepath
    True
    """

    def __init__(
        self,
        scenario_root: str,
        route: str = None,
        missions: Dict[str, Mission] = None,
        log_dir: str = "/tmp/smarts/_sumo_run_logs",
    ):
        """
        scenario_root: The scenario asset folder ie. './scenarios/trigger'.
        route: The social vehicle traffic spec.
        missions: agent_id to mission mapping.
        """

        self._logger = logging.getLogger(self.__class__.__name__)
        self._root = scenario_root
        self._route = route
        self._missions = missions or {}
        self._log_dir = os.path.abspath(log_dir)
        self._log_id = uuid.uuid4()

        self._validate_assets_exist()

    def __repr__(self):
        return f"""Scenario(
  _root={self._root},
  _route={self._route},
  _missions={self._missions},
)"""

    @staticmethod
    def scenario_variations(
        scenarios_or_scenarios_dirs: Sequence[str], agents_to_be_briefed: Sequence[str],
    ):
        """
        scenarios_or_scenarios_dirs:
            A sequence of either the scenario to run (see scenarios/ for some samples you
            can use) OR a directory of scenarios to sample from.
        agents_to_be_briefed:
            Agent IDs that will be assigned a mission ("briefed" on a mission).
        """
        scenario_roots = []
        for root in scenarios_or_scenarios_dirs:
            if Scenario.is_valid_scenario(root):
                # This is the single scenario mode, only training against a single scenario
                scenario_roots.append(root)
            else:
                scenario_roots.extend(Scenario.discover_scenarios(root))

        return cycle(
            Scenario.variations_for_all_scenario_roots(
                scenario_roots, agents_to_be_briefed
            )
        )

    @staticmethod
    def variations_for_all_scenario_roots(scenario_roots, agents_to_be_briefed):
        for scenario_root in scenario_roots:
            agent_missions = Scenario.discover_agent_missions(
                scenario_root, agents_to_be_briefed
            )
            social_missions = []
            social_agent_infos = Scenario.discover_social_agents_info(scenario_root)
            for social_agents_missions in social_agent_infos:
                social_missions.append(
                    {
                        agent_id: mission
                        for agent_id, (
                            mission,
                            agent_locator,
                        ) in social_agents_missions.items()
                    }
                )

            if len(social_missions) == 0:
                missions = agent_missions
            elif len(agent_missions) == 0:
                missions = social_missions
            else:
                missions = [
                    {**agent, **social}
                    for agent, social in product(agent_missions, social_missions)
                ]

            # `or [None]` so that product(...) will not return an empty result
            # but insted a [(..., `None`), ...].
            missions = missions or [None]
            routes = Scenario.discover_routes(scenario_root) or [None]

            roll_routes = random.randint(0, len(routes))
            roll_missions = random.randint(0, len(missions))

            for concrete_route, concrete_agent_missions in product(
                np.roll(routes, roll_routes, 0), np.roll(missions, roll_missions, 0)
            ):
                yield Scenario(
                    scenario_root,
                    route=concrete_route,
                    missions=concrete_agent_missions,
                )

    @staticmethod
    def discover_agent_missions(scenario_root, agents_to_be_briefed):
        """
        Returns a sequence of {agent_id: mission} mappings. If no missions are
        discovered we generate random ones. If there is only one agent to be briefed
        we return a list of `{agent_id: mission}` cycling through each mission. If
        there are multiple agents to be briefed we assume that each one is intended
        to get its own mission and that `len(agents_to_be_briefed) == len(missions)`.
        In this case a list of one dictionary is returned.
        """

        net_file = os.path.join(scenario_root, "map.net.xml")
        road_network = SumoRoadNetwork.from_file(net_file)

        missions = []
        missions_file = os.path.join(scenario_root, "missions.pkl")
        if os.path.exists(missions_file):
            with open(missions_file, "rb") as f:
                missions = pickle.load(f)

            missions = [
                Scenario._hydrate_mission(mission, road_network) for mission in missions
            ]

        if not missions:
            missions = [None for _ in range(len(agents_to_be_briefed))]
        if len(agents_to_be_briefed) == 0:
            return []
        elif len(agents_to_be_briefed) == 1:
            # single-agent, so we cycle through all missions individually.
            return [{agents_to_be_briefed[0]: mission} for mission in missions]
        else:
            # multi-agent, so we assume missions "drive" the agents (i.e. one
            # mission per agent) and we will not be cycling through missions.
            assert not missions or len(missions) == len(agents_to_be_briefed), (
                "You must either provide an equal number of missions ({}) to "
                "agents ({}) or provide no missions at all so they can be "
                "randomly generated.".format(len(missions), len(agents_to_be_briefed))
            )

        return [dict(zip(agents_to_be_briefed, missions))]

    @staticmethod
    @lru_cache(maxsize=10)
    def discover_social_agents_info(
        scenario,
    ) -> Sequence[Dict[str, Tuple[Mission, str]]]:  # id: (mission, locator)
        scenario_root = (
            scenario.root_filepath if isinstance(scenario, Scenario) else scenario
        )
        net_file = os.path.join(scenario_root, "map.net.xml")
        road_network = SumoRoadNetwork.from_file(net_file)

        social_agents_path = os.path.join(scenario_root, "social_agents")
        if not os.path.exists(social_agents_path):
            return []

        # [ ( missions_file, agent_locator, Mission ) ]
        agent_bucketer = []

        # like dict.setdefault
        def setdefault(l: Sequence[Any], index: int, default):
            while len(l) < index + 1:
                l.append([])
            return l[index]

        file_match = os.path.join(social_agents_path, "*.pkl")
        for missions_file_path in glob.glob(file_match):
            with open(missions_file_path, "rb") as missions_file:
                count = 0
                missions = pickle.load(missions_file)
                missions_file_name = missions_file.name

            for mission in missions:
                assert isinstance(mission.actor, sstudio_types.SocialAgentActor)

                locator = mission.actor.agent_locator
                mission = Scenario._hydrate_mission(mission, road_network)

                setdefault(agent_bucketer, count, []).append(
                    (missions_file.name, locator, mission)
                )
                count += 1

        output = []
        for l in agent_bucketer:
            output.append(
                {agent_id: (mission, locator) for agent_id, locator, mission in l}
            )
        return output

    @classmethod
    def discover_social_agents(cls, scenario_path: str):
        social_agent_infos = cls.discover_social_agents_info(scenario_path)
        social_agents = {
            agent_id: make_social_agent(locator=locator)
            for d in social_agent_infos
            for agent_id, (_, locator) in d.items()
        }

        return social_agents

    @staticmethod
    def discover_scenarios(scenario_or_scenarios_dir):
        if Scenario.is_valid_scenario(scenario_or_scenarios_dir):
            # This is the single scenario mode, only training against a single scenario
            scenario = scenario_or_scenarios_dir
            discovered_scenarios = [scenario]
        else:
            # Find all valid scenarios in the given scenarios directory
            discovered_scenarios = []
            for scenario_file in os.listdir(scenario_or_scenarios_dir):
                scenario_root = os.path.join(scenario_or_scenarios_dir, scenario_file)
                if Scenario.is_valid_scenario(scenario_root):
                    discovered_scenarios.append(scenario_root)
        assert (
            len(discovered_scenarios) > 0
        ), f"No valid scenarios found in {scenario_or_scenarios_dir}"

        return discovered_scenarios

    @staticmethod
    def discover_routes(scenario_root):
        """
        >>> Scenario.discover_routes("scenarios/intersections/2lane")
        ['all.rou.xml', 'horizontal.rou.xml', 'turns.rou.xml', 'unprotected_left.rou.xml', 'vertical.rou.xml']
        >>> Scenario.discover_routes("scenarios/loop") # loop does not have any routes
        ['basic.rou.xml']
        """
        return sorted(
            [
                os.path.basename(r)
                for r in glob.glob(os.path.join(scenario_root, "traffic", "*.rou.xml"))
            ]
        )

    @staticmethod
    def discover_bubbles(scenario_root):
        path = os.path.join(scenario_root, "bubbles.pkl")
        if not os.path.exists(path):
            return []

        with open(path, "rb") as f:
            bubbles = pickle.load(f)
            return bubbles

    @staticmethod
    def _hydrate_mission(mission, road_network):
        """Takes a sstudio.types.(Mission, EndlessMission, etc.) and converts it to
        the corresponding SMARTS mission types.
        """

        def resolve_offset(offset, lane_length):
            if offset == "base":
                return 0
            elif offset == "max":
                return lane_length
            elif offset == "random":
                return random.uniform(0, lane_length)
            else:
                return float(offset)

        def to_position_and_heading(edge_id, lane_index, offset, road_network):
            edge = road_network.edge_by_id(edge_id)
            lane = edge.getLanes()[lane_index]
            offset = resolve_offset(offset, lane.getLength())
            position = road_network.world_coord_from_offset(lane, offset)
            lane_vector = road_network.lane_vector_at_offset(lane, offset)
            heading = vec_to_degrees(lane_vector)
            return tuple(position), Heading(heading)

        mission = mission.mission
        # For now we discard the route and just take the start and end to form our
        # missions.
        if isinstance(mission, sstudio_types.Mission):
            position, heading = to_position_and_heading(
                *mission.route.begin, road_network,
            )
            start = Start(position, heading)

            position, _ = to_position_and_heading(*mission.route.end, road_network,)
            goal = PositionalGoal(position, radius=2)

            return Mission(start=start, goal=goal)
        elif isinstance(mission, sstudio_types.EndlessMission):
            position, heading = to_position_and_heading(*mission.begin, road_network,)
            start = Start(position, heading)

            return Mission(start=start, goal=EndlessGoal())
        elif isinstance(mission, sstudio_types.LapMission):
            start_edge_id, start_lane, start_edge_offset = mission.route.begin
            end_edge_id, end_lane, end_edge_offset = mission.route.end

            travel_edge = road_network.edge_by_id(start_edge_id)
            if start_edge_id == end_edge_id:
                travel_edge = list(travel_edge.getOutgoing())[0]

            end_edge = road_network.edge_by_id(end_edge_id)
            route = road_network.shortest_route(travel_edge, end_edge)

            route_length = 0
            for edge in route:
                route_length += edge.getLanes()[start_lane].getLength()

            position, heading = to_position_and_heading(
                *mission.route.begin, road_network,
            )
            start = Start(position, heading)

            position, _ = to_position_and_heading(*mission.route.end, road_network,)
            goal = PositionalGoal(position, radius=2)

            return LapMission(
                start=start,
                goal=goal,
                num_laps=mission.num_laps,
                route_length=route_length,
            )

        raise RuntimeError(
            f"sstudio mission={mission} is an invalid type={type(mission)}"
        )

    @staticmethod
    def is_valid_scenario(scenario_root):
        """Checks if the scenario_root directory matches our expected scenario structure

        >>> Scenario.is_valid_scenario("scenarios/loop")
        True
        >>> Scenario.is_valid_scenario("scenarios/non_existant")
        False
        """
        paths = [
            os.path.join(scenario_root, "map.net.xml"),
            os.path.join(scenario_root, "map.egg"),
        ]

        for f in paths:
            if not os.path.exists(f):
                return False

        # make sure we can load the sumo network
        net_file = os.path.join(scenario_root, "map.net.xml")
        net = SumoRoadNetwork.from_file(net_file)
        if net is None:
            return False

        return True

    @staticmethod
    def next(scenario_iterator, log_id=""):
        """ Utility to override specific attributes from a scenario iterator
        """

        scenario = next(scenario_iterator)
        scenario._log_id = log_id
        return scenario

    @property
    def name(self):
        return os.path.basename(os.path.normpath(self._root))

    @property
    def root_filepath(self):
        return self._root

    @property
    def net_filepath(self):
        return os.path.join(self._root, "map.net.xml")

    @property
    def plane_filepath(self):
        return os.path.join(self._root, "plane.urdf")

    @property
    def vehicle_filepath(self):
        return os.path.join(self._root, "vehicle.urdf")

    @property
    def route(self):
        return self._route

    @property
    def route_files_enabled(self):
        return bool(self._route)

    @property
    def route_filepath(self):
        return os.path.join(self._root, "traffic", self._route)

    @property
    def map_egg_filepath(self):
        return os.path.join(self._root, "map.egg")

    @property
    def sumo_log_dir(self):
        return os.path.join(self._log_dir, f"sumo-{self._log_id}")

    @property
    def missions(self):
        return self._missions

    def mission(self, agent_id):
        return self._missions.get(agent_id, None)

    def _validate_assets_exist(self):
        assert Scenario.is_valid_scenario(self._root)

        if not os.path.exists(self._log_dir):
            os.makedirs(self._log_dir)
