import math


class Heading(float):
    """In this space we use degrees, 0 is facing north, and turn counter-clockwise.
    """

    @classmethod
    def from_bullet(cls, bullet_heading):
        """Bullet's space is in degrees, 0 faces north, and we turn
        counter-clockwise.
        """
        heading = math.degrees(bullet_heading) % 360
        h = Heading(heading)
        h.source = "bullet"
        return h

    @classmethod
    def from_panda3d(cls, p3d_heading):
        """Panda3D's space is the same has SMARTS': It's in degrees, 0 faces north,
        and we turn counter-clockwise.
        """
        h = Heading(p3d_heading % 360)
        h.source = "p3d"
        return h

    @classmethod
    def from_sumo(cls, sumo_heading):
        """Sumo's space uses degrees, 0 faces north, and we turn clockwise."""
        heading = Heading._flip_clockwise(sumo_heading)
        h = Heading(heading)
        h.source = "sumo"
        return h

    @property
    def as_panda3d(self):
        return self

    @property
    def as_bullet(self):
        return math.radians(self)

    @property
    def as_sumo(self):
        return Heading._flip_clockwise(self)

    @staticmethod
    def _flip_clockwise(x):
        """Converts clockwise to counter-clockwise, and vice-versa."""
        return (360 - x) % 360

    def __repr__(self):
        return f"Heading({super().__repr__()})"
