import logging
from typing import Sequence

import gym

import smarts
from smarts.core.smarts import SMARTS
from smarts.core.sumo_traffic_simulation import SumoTrafficSimulation
from smarts.core.scenario import Scenario

from .visualization import build_visdom_watcher_queue
from .agent import Agent


class HiWayEnv(gym.Env):
    metadata = {"render.modes": ["human"]}

    def __init__(
        self,
        scenarios: Sequence[str],
        agents,
        visdom=False,
        headless=False,
        timestep_sec=0.1,
        seed=42,
        envision_endpoint=None,
        envision_record_data_replay_path=None,
    ):
        self._log = logging.getLogger(self.__class__.__name__)
        smarts.core.seed(seed)

        self._visdom_obs_queue = None
        if visdom:
            self._log.debug("Running with visdom")
            self._visdom_obs_queue = build_visdom_watcher_queue()

        self._agents = agents

        self._scenarios_iterator = Scenario.scenario_variations(
            scenarios, list(agents.keys()),
        )

        agent_interfaces = {
            agent_id: agent.interface for agent_id, agent in agents.items()
        }

        self._smarts = SMARTS(
            agent_interfaces=agent_interfaces,
            traffic_sim=SumoTrafficSimulation(
                headless=True, time_resolution=timestep_sec
            ),
            headless=headless,
            timestep_sec=timestep_sec,
            envision_endpoint=envision_endpoint,
            envision_record_data_replay_path=envision_record_data_replay_path,
        )

    @property
    def scenario_log(self):
        scenario = self._smarts.scenario
        return {
            "timestep_sec": self._smarts.timestep_sec,
            "scenario_map": scenario.name,
            "scenario_routes": scenario.route or "",
            "mission_hash": str(hash(frozenset(scenario.missions.items()))),
        }

    def step(self, agent_actions):
        agent_actions = {
            agent_id: self._agents[agent_id].action_adapter(action)
            for agent_id, action in agent_actions.items()
        }

        observations, rewards, scores, agent_dones = self._smarts.step(agent_actions)

        # XXX: Is this still a good approach for visualization of image-based
        #      observations?
        self._try_emit_visdom_obs(observations)

        infos = {
            agent_id: {"score": value, "env_obs": observations[agent_id]}
            for agent_id, value in scores.items()
        }

        for agent_id in observations:
            agent = self._agents[agent_id]
            observation = observations[agent_id]
            reward = rewards[agent_id]
            info = infos[agent_id]

            rewards[agent_id] = agent.reward_adapter(observation, reward)
            observations[agent_id] = agent.observation_adapter(observation)
            infos[agent_id] = agent.info_adapter(observation, reward, info)

        agent_dones["__all__"] = all(agent_dones.values())

        return observations, rewards, agent_dones, infos

    def reset(self):
        scenario = next(self._scenarios_iterator)

        env_observations = self._smarts.reset(scenario)

        # XXX: Is this still a good approach for visualization of image-based observations?
        self._try_emit_visdom_obs(env_observations)

        observations = {
            agent_id: self._agents[agent_id].observation_adapter(obs)
            for agent_id, obs in env_observations.items()
        }

        return observations

    def render(self, mode="human"):
        pass

    def close(self):
        if self._smarts is not None:
            self._smarts.destroy()

    def _try_emit_visdom_obs(self, obs):
        try:
            if self._visdom_obs_queue:
                self._visdom_obs_queue.put(obs, block=False)
        except Exception:
            self._log.debug("Dropped visdom frame instead of blocking")
